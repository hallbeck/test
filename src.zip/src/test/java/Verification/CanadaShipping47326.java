package Verification;

import Automation.TestBase;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class CanadaShipping47326 extends TestBase {


    //change the Strings below to change the tests
    String testNumber = "47326";
    String typeOfTest = "VERIFICATION";
    String typeOfCust = "NI";
    String typeOfPayment = "Credit";
    String searchAllBrand = "Acuvue";
    String searchAllBrand2 = "Toric";
    String brandToClickOn = "AcuvueAdvance";
    String brandToClickOn2 = "VertexToricXR";
    String brandVerifyPDP = "Acuvue Advance";
    String brandVerifyPDP2 = "Vertex Toric XR";
    String rPower = "--";
    String lPower = "--";
    String rPower2 = "++";
    String lPower2 = "+++";
    String rPowerDesktop = "0.50";
    String lPowerDesktop = "0.75";
    String rPowerDesktop2 = "0.25";
    String lPowerDesktop2 = "0.75";
    String rBC = "8";
    String lBC = "8";
    String rBC2 = "8";
    String lBC2 = "8";
    String rDia = "11";
    String lDia = "11";
    String rDia2 = "11";
    String lDia2 = "11";
    String rColor = "V";
    String lColor = "B";
    String rColor2 = "";
    String lColor2 = "";
    String rAdd;
    String lAdd;
    String rAdd2;
    String lAdd2;
    String rCyl = "--";
    String lCyl = "---";
    String rCyl2 = "--";
    String lCyl2 = "--";
    String rAxis = "11";
    String rAxis2 = "111";
    String lAxis = "111";
    String lAxis2 = "11";
    String rBoxes = "8";
    String rBoxes2 = "1";
    String lBoxes = "8";
    String lBoxes2 = "1";
    String PatientFNameCart = "test";
    String PatientLNameCart = "testacct";
    String PatientFNameCart2 = "test";
    String PatientLNameCart2 = "testacct";
    String ShippingCart = "c";
    //String FullPatientName = (PatientFNameCart + " " + PatientLNameCart);
    String pricePerBox = "107.99";
    String priceREye = "107.99";
    String priceLEye = "107.99";
    String pricePerBox2 = "49.99";
    String priceREye2 = "49.99";
    String priceLEye2 = "149.97";
    String priceTotal = "235.97";
    String rsTotal = "230.77";
    String rsTotalAfterRebate = "147.92";
    String rsTax = "14.79";
    String rsRebate = "";
    String rsShipping = "FREE" ;
    String shippingFName = "test";
    String shippingLName = "testacct";
    String country = "CANADA";
    String state = "ontario";
    String city = "Ottawa";
    String zip = "K1A 0G9";
    String emailPrefix = "test";
    String password = "password";
    String drName = "test";
    String drState = "UT";
    String creditCard = "4012000077777777";
    String ccName = "test testacct";
    String ccExpMo = "03";
    String ccExpYear = "2014";
    String shippingVerify = "Canada";
    String printTestName = typeOfTest + " | " + testNumber + " | " + typeOfCust + " | " + searchAllBrand + " | " + typeOfPayment + " | " + shippingVerify;
    String screenshotTestName =  testNumber + "_" + typeOfTest + "_" + typeOfCust + "_" + searchAllBrand + "_" + typeOfPayment + "_" + shippingVerify;


    @Test (singleThreaded = true)
    @Parameters(value="number")
    public void phoneTest(int number) {
        openWebPage(mobileURL);
        printTestNumber(printTestName + number);
        takeScreenshot(screenshotTestName, "Interstitial");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        clickSignOut();
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        //click on brand
        clickPhoneBrand(brandToClickOn);
        verifyPDP(brandVerifyPDP2);
        clickRPower(rPower);
        clickLPower(lPower);
        clickRCyl(rCyl);
        clickLCyl(lCyl);
        clickRAxis(rAxis);
        clickLAxis(lAxis);
        clickRboxes(rBoxes);
        clickLboxes(lBoxes);
        //enter patient name first then last
        typePatientName(PatientFNameCart,PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP3");
        //Add to cart
        clickAddToCart();
        //cart page
        //change shipping option
        //selectShippingCart(ShippingCart);
        //cart page
        takeScreenshot(screenshotTestName, "Cart");
        assertCart(brandVerifyPDP, PatientFNameCart + " " + PatientLNameCart, pricePerBox, priceREye, priceLEye, priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName,shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
        clickNewAddress_Continue();
        //Find then select Doctor by name and state
        typeDoctorSearch(drName);
        typeDoctorStateAndFind(drState);
        takeScreenshot(screenshotTestName, "DoctorSearch");
        selectDoctor();
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo, ccExpYear);
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        //submit
        clickBottomSubmitButton();
        //ThankYou
        assertThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
    @Test (singleThreaded = true)
    @Parameters(value="number")
    public void desktopTest(int number) {
        openWebPage(desktopBaseUrl);
        printTestNumber(printTestName + number);
        takeScreenshot(screenshotTestName, "HomePage");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        clickSignOut();
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        //click on brand
        clickPhoneBrand(brandToClickOn);
        verifyPDP(brandVerifyPDP);
        clickRPower(rPowerDesktop);
        clickLPower(lPowerDesktop);
        clickRBC(rBC);
        clickLBC(lBC);
        clickRboxes(rBoxes);
        clickLboxes(lBoxes);
        //enter patient name first then last
        typePatientName(PatientFNameCart,PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP3");
        //Add to cart
        clickAddToCart();
        //cart page
        //change shipping option
        selectShippingCart(ShippingCart);
        //cart page
        takeScreenshot(screenshotTestName, "Cart");
        assertCart(brandVerifyPDP, PatientFNameCart + " " + PatientLNameCart, pricePerBox, priceREye, priceLEye, priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName,shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
        clickNewAddress_Continue();
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo, ccExpYear);
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        //submit
        clickBottomSubmitButton();
        //ThankYou
        assertThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
    @Test (singleThreaded = true)
    @Parameters(value="number")
    public void tabletTest(int number) {
        openWebPage(tabletURL);
        printTestNumber(printTestName + number);
        takeScreenshot(screenshotTestName, "Interstitial");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        clickSignOut();
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand2);
        //click on brand
        clickPhoneBrand(brandToClickOn2);
        verifyPDP(brandVerifyPDP2);
        clickRPower(rPower2);
        clickLPower(lPower2);
        clickRCyl(rCyl2);
        clickLCyl(lCyl2);
        clickRAxis(rAxis2);
        clickLAxis(lAxis2);
        clickRboxes(rBoxes2);
        clickLboxes(lBoxes2);
        //enter patient name first then last
        typePatientName(PatientFNameCart,PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP3");
        //Add to cart
        clickAddToCart();
        //cart page
        //change shipping option
        selectShippingCart(ShippingCart);
        //cart page
        takeScreenshot(screenshotTestName, "Cart");
        assertCart(brandVerifyPDP, PatientFNameCart + " " + PatientLNameCart, pricePerBox, priceREye, priceLEye, priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName,shippingLName);
        //clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
        clickNewAddress_Continue();
        //Find then select Doctor by name and state
        typeDoctorSearch(drName);
        typeDoctorStateAndFind(drState);
        takeScreenshot(screenshotTestName, "DoctorSearch");
        selectDoctor();
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo, ccExpYear);
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        //submit
        clickBottomSubmitButton();
        //ThankYou
        assertThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
}
