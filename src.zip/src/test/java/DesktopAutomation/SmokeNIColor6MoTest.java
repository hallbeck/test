package DesktopAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeNIColor6MoTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void desktopTest(String ffprofile) {

      openWebPage(desktop);
    // click on New to 1800contacts Find your brand
    printTestNumber("SMOKE 44030 NI Color 6 mo CC");
    clickFindBrand();

      //search for lenses
      searchAllBrand("Color");

    //click on brand
    clickPhoneBrand("FreshLookColors");

    //Product Detail page Enter Power
    clickRPower("hard coded");
    clickLPower("hard coded");

    //color
    clickRColor("V");
    clickLColor("V");

      //number of boxes  6 months = 4 boxes total
    clickRboxes("2");
    clickLboxes("2");

    //enter patient name first then last
    typePatientName("PatientFirst", "PatientLast");

    //Add to cart
    clickAddToCart();

    //cart page
      selectShippingCart("e");
      //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
      verifyCart("FreshLook Colors","PatientFirst PatientLast","49.99","99.98","99.98","199.96");
    //click continue
    clickCart_Continue();

    //Enter Address Information

    //names
    typeShippingName("shipfirst", "shiplast");

    //country
    clickCountry("USA");
    //address
    typeShippingAddress();
    //city
    typeShippingCity("slc");
    typeShippingState("UT");
    typeShippingZip("84121");
    //phone
    typeShippingPhone();
    typeShippingEmail("test");
    typePassword_newcust("password");
    clickNewAddress_Continue();

    //Find then select Doctor by name and state
    typeDoctorSearch("test");
    typeDoctorStateAndFind("Utah");
    selectDoctor();

    //Enter Billing
    typeCreditCard("4012000077777777");
    typeCreditCardName("Blah");
    pickCreditCardExpDate("03","2015");

    //submit
    clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage();
    //Close the browser
    driver.quit();
  }
}
