package MobileAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRIColorToricTest extends TestBase {

 // @DataProvider
  //static Object[][] userAgents() {
  //  return new Object[][]{
   //   {
   //       "Mozilla/5.0 (iPhone; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5355d Safari/8536.25"
   //   },
  //  };
 // }
    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void phoneTest(String ffprofile) {
      openWebPage(mobileDevice);

      //click on interstitial for now
      clickNoThanksButton();
      // click on New to 1800contacts Find your brand
      printTestNumber("SMOKE 44045 RI Diff Rx Color Toric CC");

      // DOES NOT WORK
      // clickReorderPhoneMainPage();
      //Go Directly to Sign In Page this is a fudge.
      goToSignInPage();
      // Login as returning customer

      typeReturningPhoneEmail("test_1366904654462@invalid.com");
      typeReturningPhonePassword("password");

      clickSignIn();
      clickCartEdit();
      //Product Detail page Enter Power
      //mobile
      //Product Detail page Enter Power
      clickRPower("---");
      clickLPower("--");

      //cyl
      clickRCyl("--");
      clickLCyl("--");

      //axis
      clickRAxis("11");
      clickLAxis("1");

      //color
      clickRColor("B");
      clickLColor("B");

      //number of boxes  6 months = 4 boxes total
      clickRboxes("4");
      clickLboxes("4");


      //enter patient name first then last
      typePatientName("PatientFirstnew", "PatientLast");

      //Add to cart
      clickUpdateCart();

      //cart page
      //click continue
      clickCart_Continue();

      //submit
      clickBottomSubmitButton();
      //ThankYou
      verifyThankYouPage("standard");
      //Close the browser
      driver.quit();
  }
}
