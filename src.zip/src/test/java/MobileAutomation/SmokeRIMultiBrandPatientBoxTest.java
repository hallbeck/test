package MobileAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRIMultiBrandPatientBoxTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void phoneTest(String ffprofile) {
      openWebPage(mobileDevice);

      //click on interstitial for now
      clickNoThanksButton();
    // click on New to 1800contacts Find your brand
    printTestNumber("SMOKE 44056 RI Multi Brand Multi patient Change Boxes CC");

      // DOES NOT WORK
      // clickReorderPhoneMainPage();
      //Go Directly to Sign In Page this is a fudge.
      goToSignInPage();
      // Login as returning customer

      typeReturningPhoneEmail("test_1366904909534@invalid.com");
      typeReturningPhonePassword("password");

      clickSignIn();
      checkReorderCheckboxTwo();
      clickReorderTheseRxButton();
      //cart page
      clickCartEdit();
      clickRboxes("3");
      clickRboxes("1");
      clickUpdateCart();
      //click continue
      clickCart_Continue();

      //submit
      clickBottomSubmitButton();
      //ThankYou
      verifyThankYouPage("standard");
      //Close the browser
      driver.quit();
  }
}
