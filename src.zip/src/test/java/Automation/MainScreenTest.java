package Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class MainScreenTest extends TestBase {

  @Test
  public void initialTest() {

    // And now use this to visit the home page
    driver.get("http://www.1800contactstest.com");
    // Alternatively the same thing can be done like this
    // driver.navigate().to("http://www.google.com");
    System.out.println("Page title is: " + driver.getTitle());

    //click on interstitial for now
    //driver.findElement(By.xpath("//img[contains(@alt,'No Thanks')]")).click();
    //System.out.println("Page title is: " + driver.getTitle());

    // click on New to 1800contacts Find your brand
    clickMainPage_NewButton();

    //click on Acuvue2
    System.out.println("Page title is: " + driver.getTitle());
    clickBrand("Biofinity");
    //       driver.findElement(By.xpath("//a[contains(@id,'BrandText_Biofinity')]")).click();

    //Product Detail page Enter Power
    System.out.println("Page title is: " + driver.getTitle());
    //right
    //mobile
    // driver.findElement(By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.SphericalPower')]")).click();
    //driver.findElement(By.xpath("//option[contains(@value,'-1.00')]")).click();
    //left
    //driver.findElement(By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.SphericalPower')]")).click();
    //driver.findElement(By.xpath("//option[contains(@value,'-0.50')]")).click();
    //Enter BC
    //right
    // driver.findElement(By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.BaseCurve')]")).click();
    //driver.findElement(By.xpath("//option[contains(@value,'8.70')]")).click();
    //left
    //driver.findElement(By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.BaseCurve')]")).click();
    //driver.findElement(By.xpath("//option[contains(@value,'8.70')]")).click();

    //desktop
    //right
    driver.findElement(By.xpath("//input[contains(@id,'RightPowerPicker')]")).click();
    Wait(2);
    driver.findElement(By.xpath("//a[contains(@id,'Right_-1.00')]")).click();
    Wait(2);
    //left
    driver.findElement(By.xpath("//input[contains(@id,'LeftPowerPicker')]")).click();
    Wait(2);
    driver.findElement(By.xpath("//a[contains(@id,'Left_-1.00')]")).click();
    Wait(2);

    //BC NOTHING


    //enter patient name first then last
    driver.findElement(By.xpath("//input[contains(@id,'firstNameInput')]")).sendKeys("PatientFirst");
    driver.findElement(By.xpath("//input[contains(@id,'lastNameInput')]")).sendKeys("PatientLast");

    //Add to cart
    driver.findElement(By.xpath("//input[contains(@value,'Submit')]")).click();
    Wait(4);

    //cart page
    //click continue
    driver.findElement(By.xpath("//img[contains(@src,'/img/ui3/btn/orange_btn_continue.png')]")).click();
    Wait(4);

    //Enter Address Information
    System.out.println("Page title is: " + driver.getTitle());
    //fname
//        driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.FirstName')]")).sendKeys("ShippingFirst");
    //lname
//        driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.LastName')]")).sendKeys("ShippingLast");
    //country
    driver.findElement(By.xpath("//select[contains(@name,'ShippingAddress.Country')]")).click();
    driver.findElement(By.xpath("//option[contains(@value,'USA')]")).click();
    //address
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.AddressLine1')]")).sendKeys("ship address " + new Date().getTime());
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.AddressLine2')]")).sendKeys("3456767777");
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.AddressLine2')]")).sendKeys(Keys.CONTROL + "a");
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.AddressLine2')]")).sendKeys(Keys.CONTROL + "x");
    //city
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.City')]")).sendKeys("slc");
    //state
    driver.findElement(By.xpath("//select[contains(@id,'ShippingAddress_StateProvinceOrRegion')]")).sendKeys("UT");
    //zip
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.ZipOrPostalCode')]")).sendKeys("84121");
    //phone
    driver.findElement(By.xpath("//input[contains(@name,'Phone')]")).sendKeys(Keys.CONTROL + "v");
    //email
    driver.findElement(By.xpath("//input[contains(@name,'EmailAddress')]")).sendKeys("brandhere" + new Date().getTime() + "@invalid.com");
    //password and confirm password
    driver.findElement(By.xpath("//input[contains(@id,'a41-checkout-password')]")).sendKeys("password");
    driver.findElement(By.xpath("//input[contains(@id,'a41-checkout-confirm-password')]")).sendKeys("password");
    //Click Continue
    driver.findElement(By.xpath("//input[contains(@value,'continue')]")).click();
    Wait(4);

    //Find then select Doctor by name and state
    driver.findElement(By.xpath("//input[contains(@name,'DoctorSearchOptionsViewModel.DoctorOrClinic')]")).sendKeys("afttyg");
    Wait(4);
    //driver.findElement(By.xpath("//select[contains(@id='DoctorSearchOptionsViewModel_State')]")).sendKeys("Utah");
    new Select(driver.findElement(By.xpath("//select[contains(@id,'DoctorSearchOptionsViewModel_State')]"))).selectByVisibleText("Utah");        //find then select doctor by phone number
    //driver.findElement(By.xpath("//input[contains(@id,'a41-search-by-phone')]")).click();
    //driver.findElement(By.xpath("//input[contains(@id,'PhoneNumber')]")).sendKeys("5555554444");
    System.out.println("Page title is: " + driver.getTitle());
    //search
    driver.findElement(By.xpath("//img[contains(@src,'DoctorSearch/search-orange.png')]")).click();
    Wait(6);
    //select doctor  this will just take the first result
    driver.findElement(By.xpath("//img[contains(@src,'/img/UI3/DoctorSearch/bttn-select.png')]")).click();
    Wait(6);

    //review and submit page
    //enter credit card

    driver.findElement(By.xpath("//input[contains(@id,'CreditCardName')]")).sendKeys("4012000077777777");
    driver.findElement(By.xpath("//input[contains(@id,'CreditCardName')]")).sendKeys(Keys.CONTROL + "a");
    driver.findElement(By.xpath("//input[contains(@id,'CreditCardName')]")).sendKeys(Keys.CONTROL + "x");
    driver.findElement(By.xpath("//input[contains(@id,'CreditCardNumber')]")).sendKeys(Keys.CONTROL + "v");
    driver.findElement(By.xpath("//select[contains(@id,'CreditCardExpirationMonth')]")).click();
    driver.findElement(By.xpath("//option[contains(@value,'03')]")).click();
    driver.findElement(By.xpath("//select[contains(@id,'CreditCardExpirationYear')]")).click();
    driver.findElement(By.xpath("//option[contains(@value,'2015')]")).click();
    driver.findElement(By.xpath("//input[contains(@id,'CreditCardName')]")).sendKeys("CreditName");
    System.out.println("Page title is: " + driver.getTitle());
    //Place My Order top button
    driver.findElement(By.xpath("//input[contains(@id,'PlaceMyOrderButton')]")).click();
    //Wait(6);
    //Place My Order Bottom button
    //driver.findElement(By.xpath("//input[contains(@id,'ReviewAndSubmit_BottomButton')]"));

    //Processing
    driver.findElement(By.xpath("//div[contains(@id,'CreditCardProcessingDiv')]"));
    Wait(6);
    System.out.println("Page title is: " + driver.getTitle());
    //ThankYou page
    driver.findElement(By.xpath("//h1[contains(.,'Thank you for your order!')]"));
    driver.findElement(By.xpath("//p[contains(.,'A confirmation of this order has been sent to:')]"));
    System.out.println("Page title is: " + driver.getTitle());
    //go to my account
    driver.findElement(By.xpath("//a[contains(@title,'My Account')]")).click();
    System.out.println("Page title is: " + driver.getTitle());
    //view daashboard
    driver.findElement(By.xpath("//img[contains(@alt,'Welcome to your personal contact lens dashboard.')]"));
    //click on and view order history
    Wait(6);
    driver.findElement(By.xpath("//a[contains(@id,'orderStatusAndHistoryForm')]")).click();
    driver.findElement(By.xpath("//img[contains(@src,'/images/AccountHub/OrderStatusAndHistory/statusForOrderNumber.png')]"));
    printPageTitle();
    //view addresses
    driver.findElement(By.xpath("//a[contains(@id,'shippingBillingForm')]")).click();
    driver.findElement(By.xpath("//img[contains(@src,'/images/AccountHub/myBillingAddress.png')]"));
    printPageTitle();
    //view account settings and password
    driver.findElement(By.xpath("//a[contains(@id,'accountSettingsAndPasswordForm')]")).click();
    driver.findElement(By.xpath("//img[contains(@alt,'Account Settings & Password')]"));
    printPageTitle();

    // Now submit the form. WebDriver will find the form for us from the element
    //element.submit();

    // Check the title of the page
    //System.out.println("Page title is: " + driver.getTitle());

    // Google's search is rendered dynamically with JavaScript.
    // Wait for the page to load, timeout after 10 seconds
    //(new WebDriverWait(driver, 10)).until(new ExpectedCondition<Boolean>() {
    //    public Boolean apply(WebDriver d) {
    //        return d.getTitle().toLowerCase().startsWith("cheese!");
    //    }
    //});

    // Should see: "cheese! - Google Search"
    printPageTitle();

    //Close the browser
    driver.quit();
  }

 // @DataProvider
  //static Object[][] userAgents() {
  //  return new Object[][]{
   //   {
   //       "Mozilla/5.0 (iPhone; CPU OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A5355d Safari/8536.25"
   //   },
  //  };
 // }
    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphone"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void phoneTest(String ffprofile) {
    //profile.setPreference("general.useragent.override", useragent);
      // get().manage().window().setSize(new Dimension(width, height));
      //driver.manage().window().setPosition(new Point(0,0));
      // java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
      //Dimension screenSize = new Dimension(1136, 640);
      //Dimension dim = new Dimension((int) screenSize.getWidth(), (int) screenSize.getHeight());
      //resolutions

    //driver.manage().window().setSize(new Dimension(320, 568));

      //WebDriver.Window set_window_size(1080,800);

    // And now use this to visit the home page
    //driver.get("https://osta.1800contactstest.com/?stop_mobi=yes");
      //Wait(5);
      //zoomOut();
      driver.get("https://ww1.1800contactstest.com/?responsive=yes");
      Wait(5);
    // Alternatively the same thing can be done like this
    // driver.navigate().to("http://www.google.com");
    //click on interstitial for now
//        driver.findElement(By.xpath("//img[contains(@alt,'No Thanks')]")).click();

    // click on New to 1800contacts Find your brand
      printTestNumber("SMOKE BLAH");
      //clickPhoneMainPage_NewButton();
      clickFindBrand();

    //click on Acuvue2
    Wait(5);
    clickPhoneBrand("Acuvue2");

    //Product Detail page Enter Power
    //mobile
    clickRPower("++");
    clickLPower("++");

    //bc
    clickRBC("8");
    clickLBC("8");


    //enter patient name first then last
    typePatientName("PatientFirst", "PatientLast");

    //Add to cart
    clickAddToCart();

    //cart page
    //click continue
    clickCart_Continue();

    //Enter Address Information
    //names
    typeShippingName("shipfirst", "shiplast");

    //country
    clickCountry("USA");
    //address
    typeShippingAddress();
    //city
    typeShippingCity("slc");
    typeShippingState("UT");
    typeShippingZip("84121");
    //phone
    typeShippingPhone();
   // typeShippingEmail("test");
    typePassword_newcust("password");
    clickNewAddress_Continue();

    //Find then select Doctor by name and state
    typeDoctorSearch("test");
    typeDoctorStateAndFind("Utah");
    selectDoctor();

    //Enter Billing
    typeCreditCard("4012000077777777");
    typeCreditCardName("Blah");
    pickCreditCardExpDate("03","2015");

    //submit
    clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage("blah");
    //Close the browser
    driver.quit();
  }
}
