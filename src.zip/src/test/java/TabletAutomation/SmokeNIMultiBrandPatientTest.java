package TabletAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeNIMultiBrandPatientTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void tabletTest(String ffprofile) {
      openWebPage(tabletDevice);

      // click on New to 1800contacts Find your brand
    printTestNumber("SMOKE 44041 NI Multi Brand Multi patient CC");
    //clickPhoneMainPage_NewButton();
    clickFindBrand();

      //search for lenses
      searchAllBrand("Color");

    //click on brand
    clickPhoneBrand("FreshLookColors");

    //Product Detail page Enter Power
    //mobile
    clickRPower("--");
    clickLPower("--");

    //color
    clickRColor("V");
    clickLColor("V");

      //number of boxes
    clickRboxes("2");
    clickLboxes("4");

    //enter patient name first then last
    typePatientName("PatOneFirst", "PatientLast");

      //click Add Rx
      clickAddRx();
      //search for lenses
      searchAllBrand("Toric");

      //click on brand
      clickPhoneBrand("VertexToricXR");

      //Product Detail page Enter Power
      printPageTitle();
      //mobile
      clickRPower("++");
      clickLPower("+++");

      //cyl
      clickRCyl("--");
      clickLCyl("--");

      //axis
      clickRAxis("111");
      clickLAxis("11");

      //enter patient name first then last
      typePatientName("PatTwoFirst", "PatientLast");

    //Add to cart
    clickAddToCart();

    //cart page
      selectShippingCart("n");
      //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
      verifyCart("FreshLook Colors","PatOneFirst PatientLast","49.99","99.98","199.96","1,163.86");
    //click continue
    clickCart_Continue();

    //Enter Address Information
    //names
    typeShippingName("shipfirst", "shiplast");

    //country
    clickCountry("united states");
    //address
    typeShippingAddress();
    //city
    typeShippingCity("slc");
    typeShippingState("UT");
    typeShippingZip("84121");
    //phone
    typeShippingPhone();
    typeShippingEmail("test");
    typePassword_newcust("password");
    clickNewAddress_Continue();

    //Find then select Doctor by name and state
    typeDoctorSearch("test");
    typeDoctorStateAndFind("Utah");
    selectDoctor();

    //Enter Billing
    typeCreditCard("4012000077777777");
    typeCreditCardName("Blah");
    pickCreditCardExpDate("03","2015");

    //submit
    clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage();
    //Close the browser
    driver.quit();
  }
}
