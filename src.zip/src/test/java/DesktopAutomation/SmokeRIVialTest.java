package DesktopAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRIVialTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

    @Test(dataProvider = "ffprofile", singleThreaded = true)
    public void desktopTest(String ffprofile) {
    // And now use this to visit the home page
      openWebPage(desktop);
      printTestNumber("SMOKE 44046 RI Vial CC");
      goToSignInPage();
     // Login as returning customer

      typeReturningPhoneEmail("test_1365802343449@invalid.com");
      typeReturningPhonePassword("password");

      clickSignIn();
      clickCartEdit();
      //Product Detail page

      clickRboxes("1");
      clickLboxes("1");

      //enter patient name first then last
      typePatientName("PatientFirstnew", "PatientLast");

      //Add to cart
      clickUpdateCart();
      clickCart_Continue();

    //submit
    clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage();
    //Close the browser
    driver.quit();
  }
}
