package DesktopAutomation;

import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRIMultiBrandPatientTest extends TestBase {
    String testNumber = "44055";
    String testNumberDependentOn = "44041";
    String typeOfTest = "SMOKE";
    String typeOfCust = "RI";
    String typeOfPayment = "Credit";
    String searchAllBrand = "progressive";
    String brandToClickOn = "FocusDAILIESProgressives30pack";
    String brandVerifyPDP = "Focus DAILIES Progressives 30 pack";
    String rPower = "---";
    String lPower = "--";
    String rPowerDesktop = "-0.50";
    String lPowerDesktop = "-1.75";
    String rBC = "8";
    String lBC = "8";
    String rDia = "1";
    String lDia = "1";
    String rBoxes = "5";
    String rBoxes2 = "3";
    String lBoxes = "2";
    String lBoxes2 = "2";
    String rAdd;
    String lAdd;
    String rCyl;
    String lCyl;
    String PatientFNameCart = "PatFirstNew";
    String PatientLNameCart = "PatientLast";
    String ShippingCart = "e";
    //String FullPatientName = (PatientFNameCart + " " + PatientLNameCart);
    String pricePerBox = "39.99";
    String priceREye = "199.95";
    String priceLEye = "799.80";
    String priceTotal = "1,019.74";
    String shippingFName = "ShipFirst";
    String shippingLName = "ShipLast";
    String country = "united states";
    String state = "utah";
    String city = "slc";
    String zip = "84121";
    String emailPrefix = "test";
    String emailToUse = "test_1367264512594@invalid.com";
    String password = "password";
    String drName = "test";
    String drState = "UT";
    String creditCard = "4012000077777777";
    String ccName = "Blah";
    String ccExpMo = "03";
    String ccExpYear = "2014";
    String shippingVerify = "Int'l Standard";
    String printTestName = typeOfTest + " | " + testNumber + " | " + typeOfCust + " | " + searchAllBrand + " | " + typeOfPayment + " | " + shippingVerify;
    String screenshotTestName =  testNumber + "_" + typeOfTest + "_" + typeOfCust + "_" + searchAllBrand + "_" + typeOfPayment + "_" + shippingVerify;

    @Test(singleThreaded = true)
  public void desktopTest() {

      openWebPage(desktop);

    // click on New to 1800contacts Find your brand
    printTestNumber("SMOKE 44055 RI change Rx Multi Brand Multi patient CC");
      goToSignInPage();
      // Login as returning customer

      typeReturningPhoneEmail("test_1366045931991@invalid.com");
      typeReturningPhonePassword("password");

      clickSignIn();
      checkReorderCheckboxTwo();
      clickReorderTheseRxButton();
      //cart page
      clickCartEdit();
      clickRColor("G");
      clickLColor("B");
      clickUpdateCart();
      //click continue
      clickCart_Continue();

      //submit
      clickBottomSubmitButton();
      //ThankYou
      verifyThankYouPage();
      //Close the browser
      driver.quit();
  }
}
