package Automation;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRIMultiBrandPatientBoxTest extends TestBase {

    String testNumber = "44056";
    String testNumberDependentOn = "44042";
    String typeOfTest = "SMOKE";
    String typeOfCust = "RI";
    String typeOfPayment = "Credit";
    String searchAllBrand = "multifocal";
    String brandToClickOn = "PureVisionMulti-Focal";
    String brandVerifyPDP = "FreshLook Colors";
    String rPower = "++++++++++++++++";
    String lPower = "----------";
    String rPowerDesktop = "-0.50";
    String lPowerDesktop = "-1.75";
    String rBC = "8";
    String lBC = "8";
    String rDia = "1";
    String lDia = "1";
    String rBoxes = "1";
    String rBoxes2 = "3";
    String lBoxes = "1";
    String lBoxes2 = "2";
    String rAdd = "2";
    String lAdd = "2";
    String rCyl;
    String lCyl;
    String PatientFNameCart = "FirstPaFirst";
    String PatientLNameCart = "FirstPaLast";
    String ShippingCart = "s";
    //String FullPatientName = (PatientFNameCart + " " + PatientLNameCart);
    String pricePerBox = "49.99";
    String priceREye = "49.99";
    String priceLEye = "49.99";
    String priceTotal = "963.90";
    String rsTotal = "1,029.93";
    String rsTotalAfterRebate = "1,029.93";
    String rsTax = "66.03";
    String rsRebate = "";
    String rsShipping = "FREE" ;
    String shippingFName = "ShipFirst";
    String shippingLName = "ShipLast";
    String country = "united states";
    String state = "utah";
    String city = "slc";
    String zip = "84121";
    String emailPrefix = "test";
    String password = "password";
    String drName = "test";
    String drState = "UT";
    String creditCard = "4012000077777777";
    String ccName = "Blah";
    String ccExpMo = "03";
    String ccExpYear = "2014";
    String shippingVerify = "Canada Standard";
    String printTestName = typeOfTest + " | " + testNumber + " | " + typeOfCust + " | " + searchAllBrand + " | " + typeOfPayment + " | " + shippingVerify;
    String screenshotTestName =  testNumber + "_" + typeOfTest + "_" + typeOfCust + "_" + searchAllBrand + "_" + typeOfPayment + "_" + shippingVerify;


  @Test(singleThreaded = true)
  @Parameters(value="emailToUse")
  public void phoneTest(String emailToUse) {
      openWebPage(mobileURL);
      takeScreenshot(screenshotTestName, "Interstitial");
      clickNoThanksButton();
      printTestNumber(printTestName);
      goToSignInPage();
      typeReturningPhoneEmail(emailToUse);
      typeReturningPhonePassword(password);
      clickSignIn("phone");
      checkReorderCheckboxTwo();
      clickCartEdit();
      //cart page
      clickRboxes(rBoxes);
      clickLboxes(lBoxes);
      clickUpdateCart();
      takeScreenshot(screenshotTestName, "Cart");
      verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
      clickCart_Continue();
      takeScreenshot(screenshotTestName, "ReviewSubmit");
      verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
      clickBottomSubmitButton();
      verifyThankYouPage(shippingVerify);
      takeScreenshot(screenshotTestName, "ThankYou");
      driver.quit();
  }
    @Test(singleThreaded = true)
    @Parameters(value="emailToUse")
    public void desktopTest(String emailToUse) {
        openWebPage(desktopBaseUrl);
        takeScreenshot(screenshotTestName, "Interstitial");
        clickNoThanksButton();
        printTestNumber(printTestName);
        goToSignInPage();
        typeReturningPhoneEmail(emailToUse);
        typeReturningPhonePassword(password);
        clickSignIn("desktop");
        checkReorderCheckboxTwo();
        clickCartEdit();
        //cart page
        clickRboxes(rBoxes);
        clickLboxes(lBoxes);
        clickUpdateCart();
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        clickCart_Continue();
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        driver.quit();
    }
    @Test(singleThreaded = true)
    @Parameters(value="emailToUse")
    public void tabletTest(String emailToUse) {
        openWebPage(tabletURL);
        takeScreenshot(screenshotTestName, "Interstitial");
        clickNoThanksButton();
        printTestNumber(printTestName);
        goToSignInPage();
        typeReturningPhoneEmail(emailToUse);
        typeReturningPhonePassword(password);
        clickSignIn("tablet");
        checkReorderCheckboxTwo();
        clickCartEdit();
        //cart page
        clickRboxes(rBoxes);
        clickLboxes(lBoxes);
        clickUpdateCart();
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        clickCart_Continue();
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        driver.quit();
    }
}
