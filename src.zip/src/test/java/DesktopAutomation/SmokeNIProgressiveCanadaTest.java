package DesktopAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeNIProgressiveCanadaTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void desktopTest(String ffprofile) {

      openWebPage(desktop);

    // click on New to 1800contacts Find your brand
      printTestNumber("SMOKE 44035 NI Progressive International CC");
      clickFindBrand();

      //search for lenses
       searchAllBrand("progressive");
    //click on brand
    clickPhoneBrand("FocusDAILIESProgressives30pack");

    //Product Detail page
    //Power
    clickRPower("hard coded");
    clickLPower("hard coded");

      //enter patient name first then last
    typePatientName("PatientFirst", "PatientLast");

    //Add to cart
    clickAddToCart();

    //cart page
      selectShippingCart("cc");
      //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
      verifyCart("Focus DAILIES Progressives 30 pack","PatientFirst PatientLast","39.99","239.94","239.94","506.87");
    //click continue
    clickCart_Continue();

    //Enter Address Information
    //names
    typeShippingName("shipfirst", "shiplast");
    //country
    clickCountry("BOLIVIA");
    //address
    typeShippingAddress();
      typeIntShippingZip("K1A 0G9");
    //city
    typeShippingCity("whatever");
    typeIntShippingState("Newberry");
    //phone
    typeIntShippingPhone();
    typeShippingEmail("test");
    typePassword_newcust("password");
    clickNewAddress_Continue();

    //Find then select Doctor by name and state
   // typeDoctorSearch("test");
   // typeDoctorStateAndFind("Utah");
   // selectDoctor();

    //Enter Billing
    typeCreditCard("4012000077777777");
    typeCreditCardName("Blah");
    pickCreditCardExpDate("03","2015");

    //submit
    clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage();
    //Close the browser
    driver.quit();
  }
}
