package DesktopAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeNIAcuvue2PlanoCanadaTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void desktopTest(String ffprofile) {
      openWebPage(desktop);

      printTestNumber("SMOKE 44038 NI Acuvue2 Color Plano Canada CC");
      clickFindBrand();

      //search for lenses
       searchAllBrand("color");
    //click on brand
    clickPhoneBrand("Acuvue2");

    //Product Detail page
    //Power
    clickRPowerPlano("hard coded");
    clickLPowerPlano("hard coded");

      //bc
      clickRBC("8");
      clickLBC("8");

      //color
      clickRColor("E");
      clickLColor("E");

      //enter patient name first then last
    typePatientName("PatientFirst", "PatientLast");

    //Add to cart
    clickAddToCart();

    //cart page
      selectShippingCart("c");
      //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
      verifyCart("Acuvue 2 Colours","PatientFirst PatientLast","37.99","151.96","151.96","303.92");
    //click continue
    clickCart_Continue();

    //Enter Address Information
    //names
    typeShippingName("shipfirst", "shiplast");

    //country
    clickCountry("CANADA");
    //address
    typeShippingAddress();
      typeIntShippingZip("K1A 0G9");
    //city
    typeShippingCity("Ottawa");
    typeShippingState("O");
    //phone
    typeShippingPhone();
    typeShippingEmail("test");
    typePassword_newcust("password");
    clickNewAddress_Continue();

    //Find then select Doctor by name and state
   // typeDoctorSearch("test");
   // typeDoctorStateAndFind("Utah");
   // selectDoctor();

    //Enter Billing
    typeCreditCard("4012000077777777");
    typeCreditCardName("Blah");
    pickCreditCardExpDate("03","2015");

    //submit
    clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage();
    //Close the browser
    driver.quit();
  }
}
