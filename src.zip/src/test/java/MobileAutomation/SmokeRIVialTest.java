package MobileAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRIVialTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void phoneTest(String ffprofile) {
      openWebPage(mobileDevice);

      //click on interstitial for now
      clickNoThanksButton();
    // click on New to 1800contacts Find your brand
      String testNumber = "44046";
      printTestNumber("SMOKE" + testNumber + "RI Vial CC");

    // DOES NOT WORK
    // clickReorderPhoneMainPage();
      //Go Directly to Sign In Page this is a fudge.
      goToSignInPage();
    // Login as returning customer

    typeReturningPhoneEmail("test_1366905810687@invalid.com");
    typeReturningPhonePassword("password");

    clickSignIn();
    clickCartEdit();
    //Product Detail page
    //Power
    clickRPower("+++++++++++++++");
    clickLPower("+++++++++++");

    //bc
    clickRBC("8");
    clickLBC("8");

    //dia
    clickRDia("11");
    clickLDia("11");

    //enter patient name first then last
    typePatientName("PatientFirstnew", "PatientLast");

    //Add to cart
    clickUpdateCart();
    //validate cart
    verifyCart("Softcon EW","PatientFirstnew PatientLast","59.99","119.98","119.98","264.95");
    //continue through cart
    clickCart_Continue();
    //submit
    clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage("Standard");
    //Close the browser
    driver.quit();
}
        }
