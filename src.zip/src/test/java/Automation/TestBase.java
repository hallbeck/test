package Automation;

import org.apache.commons.io.FileUtils;
import org.joda.time.DateTime;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.Select;

import java.io.*;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:23 PM
 * To change this template use File | Settings | File Templates.
 */


public class TestBase {
    //change this to whatever browser you want to test on
    //choices are ie,firefox,chrome,safari         -- SAFARI DOES NOT SELECT RX VALUES WELL. DO NOT USE
    public String browser = "ie";
    //only relevant to Firefox. otherwise enter the type of device for file name.
    public String deviceProfile = "desktop";


    public String mbrowser = "firefox";
    public String tbrowser = "firefox";
    public String dbrowser = "ie";
    //change this for ff browser only
    public String deviceProfilePhone = "iphoneOS61P";
    public String deviceProfileTablet = "ipadP";
    public String deviceProfileDesktop = "desktopFF";   //choices are iphoneP, iphoneL, iphoneOS61P, iphoneOS61L, - this is for firefox profiles only


    //public String desktopBaseUrl = "https://www.1800contactstest.com/";
    public String desktopBaseUrl = "https://www.1800contactstest.com/";
    public String mobileBaseUrl = "https://www.1800contactstest.com/";
    public String mobileURL = mobileBaseUrl + "?responsive=yes";
    public String tabletBaseUrl = "https://www.1800contactstest.com/";
    public String tabletURL = tabletBaseUrl + "?responsive=yes";
    public String fileName = ("TestOut" + new Date().getTime());

    //profiles locations are stored in C:\Users\<user>\AppData\Roaming\Mozilla\Firefox
    //change this file to point to your personal profiles
     //I need to say if device is phone use device profile mobileProfile, if tablet tabletProfile, if desktop desktop

    public ChromeOptions options = new ChromeOptions();
    public DesiredCapabilities capabilities = DesiredCapabilities.chrome();

    public WebDriver driver = makeDriver(browser,deviceProfile);
    public WebDriver makeDriver(String browser, String deviceProfile) {
        ProfilesIni allProfiles = new ProfilesIni();
        FirefoxProfile profile = allProfiles.getProfile(deviceProfile);
        WebDriver driver = null;
        if (browser.equals("ie")) {
            driver = new InternetExplorerDriver();
        } else if (browser.equals("firefox")) {
            driver = new FirefoxDriver(profile);
        } else if (browser.equals("chrome")) {
            driver = new ChromeDriver();
        } else if (browser.equals("safari")) {
            driver = new SafariDriver();
        }
        return driver;
    }


    public DateTime dt = new DateTime();
    public int iToD = dt.getHourOfDay();
    public int iDay = dt.getDayOfMonth();
    public int iMoY = dt.getMonthOfYear();
    public String pathForExcel = ("c:\\test\\emailAddresses\\" + iMoY + "\\" + iDay + "\\" + deviceProfile +"\\");
    public String pathForScreenshot = ("c:\\test\\screenshots\\"  + iMoY + "\\" + iDay + "\\" + browser + "\\" + deviceProfile +"\\");



    public void takeScreenshot (String screenshotName, String page){
        try{
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File(pathForScreenshot + screenshotName + "_" + page + iToD +"oclock.jpg"));
        }
       catch(Exception e) {
            System.out.println("screenshot did not work");
       }
    }
    public void openWebPage(String url) {
        //driver.get(device);
        driver.get("https://www.google.com");
        driver.manage().deleteAllCookies();
        Wait(5);
        driver.get(url);
        Wait(2);
        setCookie();
        clickSignOut();
    }
    public void setCookie(){
        String key1 = "fsr.r";
        String value1 = "{\"d\":590,\"i\":-1\"\",\"e\":\"v\":-2,}; path=/;";
        String key = "fsr.s";
        String value = "{\"v\":-2,\"rid\":\"1366734711827_458379\",\"to\":2.4,\"pv\":4,\"lc\":{\"d590\":{\"v\":-2,\"s\":true}},\"cd\":590,\"sd\":590,\"cp\":{\"s_prop2\":\"NI\",\"s_eVar29\\\":\"Control\"},\"f\":1366734744426,\"l\":\"en\",\"i\":-1}";
        Cookie cookie = new Cookie(key, value);
        driver.manage().addCookie(cookie);
        Cookie cookie2 = new Cookie(key1, value1);
        driver.manage().addCookie(cookie2);
        // uncomment if you want to see all the cookies being set.
        //Set<Cookie> allCookies = driver.manage().getCookies();
        // for (Cookie loadedCookie : allCookies) {
        //    System.out.println(String.format("%s -> %s", loadedCookie.getName(), loadedCookie.getValue()));
       // }
    }
    public void printToFile(){
        try {
            PrintStream ps = System.out;
            System.setOut(new PrintStream(new FileOutputStream(fileName + ".txt")));
            System.out.println("foo");
            ps.println("bar");
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    public void printToExcel(String sFileName, String textToWrite){
        try
        {
            FileWriter writer = new FileWriter(sFileName);
            writer.append(textToWrite);
            writer.append('\n');
            writer.flush();
            writer.close();
            File blah = new File (sFileName);
            FileUtils.copyFile(blah, new File(pathForExcel + sFileName + "_" + iToD +"oclock.csv"));
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public void printPageTitle() {
        System.out.println("Page title is: " + driver.getTitle());
        Wait(2);
  }
    public void printText(String text) {
        System.out.println(text);
        Wait(2);
    }
    public void printTestNumber(String test) {
        System.out.println("Test Covered is: " + test + " " + deviceProfile);
        System.out.println(test);
    }

  public void Wait(long seconds) {
    try {
      Thread.sleep(seconds * 1000);
      System.out.println("Waiting");
    } catch (Exception e) {
      System.out.println("Sleep exception...its a nightmare");
    }
  }

    public void clickNoThanksButton() {
        printPageTitle();
        try{
        driver.findElement(By.xpath("//img[contains(@alt,'No Thanks')]")).click();
        System.out.println("Clicked No Thanks");
        }
            catch (Throwable e)
            {
                System.out.println("No Interstitial Page");
            }
        Wait(4);
    }
  public void clickMainPage_NewButton() {
      printPageTitle();
    driver.findElement(By.xpath("//img[contains(@alt,'New to 1-800 Contacts - Find your contact lens brand')]")).click();
      System.out.println("Clicked on New customer button");
    Wait(4);
  }

    //reorder checkboxes this uses tabs to click each. two tabs, click tab click
    public void checkReorderCheckboxOne(){
        //go to dashboard cause I can't use lightbox
        driver.get(desktopBaseUrl + "accounthub");
        Wait(2);
        printPageTitle();
        WebElement eleMyAccount = driver.findElement(By.xpath("//div[contains(@class,'rxSummaryLineItemColumn memberRecentPrescription')]"));
        eleMyAccount.click();
        System.out.println("Clicked on header or something I think");
        Wait(2);
        //tab five times then space
        System.out.println("sending tabs");
        eleMyAccount.sendKeys(Keys.chord(Keys.SHIFT, Keys.TAB),Keys.SPACE);
        Wait(2);
    }
    public void checkReorderCheckboxTwo(){
    try {   //desktop
        driver.get(desktopBaseUrl + "accounthub");
        WebElement eleMyAccount = driver.findElement(By.xpath("//a[contains(@id,'dashboardForm')]"));
        eleMyAccount.click();
        Wait(2);
        eleMyAccount.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.SPACE,Keys.TAB,Keys.SPACE);
        driver.findElement(By.xpath("//input[contains(@id,'reorderRx')]")).click();
        Wait(4);
        System.out.println("reordered");
        Wait(4);
        return;
    }
    catch (Throwable e){}
        try{  //mobile
            driver.findElement(By.xpath("//div[contains(.,'Welcome to your personal contact lens dashboard.')]"));
            driver.get(desktopBaseUrl + "accounthub");
            WebElement eleMyAccount = driver.findElement(By.xpath("//div[contains(.,'Dashboard')]"));
            eleMyAccount.click();
            Wait(2);
            eleMyAccount.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.SPACE,Keys.TAB,Keys.SPACE);
            Wait(2);
            driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-phone rd-orangeButton rd-stretchButton ')]")).click();
            Wait(4);
        }
        catch (Throwable e){}
        try{      //tablet
            driver.findElement(By.xpath("//div[contains(.,'Welcome to your personal contact lens dashboard.')]"));
            driver.get(desktopBaseUrl + "accounthub");
            WebElement eleMyAccount = driver.findElement(By.xpath("//div[contains(.,'Dashboard')]"));
            Wait(2);
            eleMyAccount.click();
            Wait(2);
            eleMyAccount.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.SPACE,Keys.TAB,Keys.SPACE);
            driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-orangeButton rd-tabletRightButton')]")).click();
            Wait(4);
        }
        catch (Throwable e){}
        System.out.println("sent tabs");
    }

    //continue button from the reorder Lightbox
    public void clickContinueFromReorder(){
        System.out.println("clicking continue");
        driver.findElement(By.xpath("//input[contains(@src,'continue.png')]")).click();
    }
    public void clickReorderTheseRxButton(){
        driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-phone rd-orangeButton rd-stretchButton ')]")).click();
    }
    public void clickFindBrand() {
        printPageTitle();
        Wait(4);
        try{  // phone
        driver.findElement(By.xpath("//a[contains(@class,'FindBrand-footer-link')]")).click();
        System.out.println("Clicked on Find Your Brand footer link");
        }
        catch (Throwable e){}
        try{  //tablet
            driver.findElement(By.xpath("//a[contains(@id,'tablet-find-brand')]")).click();
            System.out.println("Clicked on Find Your Brand footer link");
        }
        catch (Throwable e){}
        try{   //desktop
            driver.findElement(By.xpath("//a[contains(@id,'tablet-find-brand')]")).click();
            System.out.println("Clicked on Find Your Brand footer link");
        }
        catch (Throwable e){}
        Wait(4);
    }
    public void clickFindBrandDesktop() {
        printPageTitle();
        Wait(4);
        // phone
        driver.findElement(By.xpath("//img[contains(@alt,'New to 1-800 Contacts - Find your contact lens brand')]")).click();
        //driver.findElement(By.linkText("How to Order")).click();
        System.out.println("Clicked on Find your brand button");
        Wait(4);
    }
    public void clickReorderPhoneMainPage() {
        printPageTitle();
        Wait(4);
        driver.findElement(By.xpath("//a[contains(@class,'Account-footer-link')]")).click();
        System.out.println("Clicked on My Account footer link");
        Wait(4);
    }
    public void clickPhoneMainPage_NewButton() {
        printPageTitle();
        Wait(4);
        WebElement weNewCust = driver.findElement(By.partialLinkText("New"));
        System.out.println("Found" + weNewCust);
        weNewCust.click();
        System.out.println("Clicked on New customer button");
        System.out.println("Clicked" + weNewCust);
        Wait(4);
    }

    public void goToSignInPage(){
        driver.get(desktopBaseUrl + "signin.aspx");
    }
               //SignIn Email Lightbox       DOES NOT WORK with popup
       public void typeReturningPhoneEmail(String email) {
        printPageTitle();
        Wait(4);
           WebElement emailInput = driver.findElement(By.xpath("//input[(@id='ctl00_contentPlaceHolderContent_SignIn1_tbEmail_tbEmail')]"));
           emailInput.click();
           emailInput.clear();
           System.out.println("clicked and cleared");
           emailInput.sendKeys(email);
        System.out.println("Email used is: " + email);
    }
    //SignIn password Lightbox       DOES NOT WORK on popup
    public void typeReturningPhonePassword(String password) {
        Wait(4);
        WebElement passwordInput = driver.findElement(By.xpath("//input[(@id='ctl00_contentPlaceHolderContent_SignIn1_tbReturningCustomerPassword_tbPass')]"));
        passwordInput.click();
        passwordInput.clear();
        passwordInput.sendKeys(password);
        System.out.println("Password used is: " + password);
    }

    public void clickSignIn(String device) {
        printPageTitle();
        if(device =="phone"){
        try{   //phone
            driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-phone rd-stretchButton rd-orangeButton')]")).click();
            System.out.println("Clicked Sign In Phone");
            Wait(6);
        }
        catch (Throwable e){}
        }
        else if(device =="tablet"){
        try{   //tablet
            driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletRightButton rd-orangeButton')]")).click();
            System.out.println("Clicked Sign In tablet");
            Wait(6);
        }
        catch (Throwable e){}
        }
        else if(device =="desktop"){
        try{   //desktop
            driver.findElement(By.xpath("//input[contains(@class,'btnSignIn')]")).click();
            System.out.println("Clicked Sign In desktop");
            Wait(6);
        }
        catch (Throwable e){}
        }
    }
    public void clickSignOut(){
        try{
            driver.findElement(By.xpath("//a[contains(@title,'Sign Out')]")).click();
            System.out.println("Signed out");
            Wait(3);
        }
        catch (Throwable e){}
    }


     //this is not working because it is not finding the search button. it has no link associated, just js. SO...
    //once it starts working uncomment searchAllBrand and rename the used searchAllBrand to Go to all Lenses
    public void searchAllBrand(String search) {
        Wait(4);
        System.out.println("About to search for brand: " + search);
        try{
        driver.findElement(By.xpath("//a[contains(.,'Search')]")).click();
        driver.findElement(By.xpath("//input[contains(@name,'searchTerm')]")).click();
        driver.findElement(By.xpath("//input[contains(@name,'searchTerm')]")).sendKeys(search, Keys.ENTER);
        }
        catch (Throwable e){}
        try{
            driver.findElement(By.xpath("//input[contains(@name,'searchTerm')]")).click();
            driver.findElement(By.xpath("//input[contains(@name,'searchTerm')]")).clear();
            driver.findElement(By.xpath("//input[contains(@name,'searchTerm')]")).sendKeys(search, Keys.ENTER);
        }
        catch (Throwable e){}
        System.out.println("Clicked Search ");
        System.out.println("Searched for brand: " + search);
        Wait(7);
    }
     //UNKNOWN if it works
    public void clickSeeAll() {
        driver.findElement(By.xpath("//div[contains(.,'See All')]")).click();
        System.out.println("Clicked See All");
    }
  public void clickBrand(String brand) {
    String theString = "//a[contains(@id,'BrandSelectButton_" + brand + "')]";
    driver.findElement(By.xpath(theString)).click();
      System.out.println("Clicked on brand: " + brand);
  }

    public void clickPhoneBrand(String brand) {
      try {
          String theString = "//a[contains(@id,'" + brand + "')]";
      driver.findElement(By.xpath(theString)).click();
      System.out.println("Clicked on brand: " + brand);
      }
      catch (Throwable e){}
      try{
          String theString = "//a[contains(@id,'BrandSelectButton_" + brand + "')]";
          driver.findElement(By.xpath(theString)).click();
          System.out.println("Clicked on brand: " + brand);
      }
      catch (Throwable e){}
      Wait(6);
  }
   public void checkBoxLeftEye() {
       driver.findElement(By.xpath("//input[contains(@class,'LeftEyeCheckBox')]")).click();
   }

    public void checkBoxRightEye() {
        driver.findElement(By.xpath("//input[contains(@class,'RightEyeCheckBox')]")).click();
    }
  public void clickRPower(String power) {
    try{        //phone
        WebElement wePower = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.SphericalPower')]"));
      wePower.click();
      System.out.println("Power for right eye: " + power);
      wePower.sendKeys(power,Keys.ENTER);
    }
    catch (Throwable e){}
    try{  //desktop
          Wait(5);
          WebElement wePower = driver.findElement(By.xpath("//input[contains(@id,'RightPowerPicker')]"));
          wePower.click();
          WebElement wePowerNumber = driver.findElement(By.xpath("//a[contains(@id,'Right_" + power +"')]"));
          wePowerNumber.click();
          System.out.println("Power for right eye: " + power);
          Wait(5);
      }
      catch (Throwable e){}
      Wait(1);
  }
    public void clickLPower(String power) {
        try{
            WebElement wePower = driver.findElement(By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.SphericalPower')]"));
        wePower.click();
        System.out.println("Power for left eye: " + power);
        wePower.sendKeys(power,Keys.ENTER);
        }
        catch (Throwable e){}
        try{
            WebElement wePower = driver.findElement(By.xpath("//input[contains(@id,'LeftPowerPicker')]"));
            wePower.click();
            Wait(5);
            System.out.println("Power for left eye: " + power);
            WebElement wePowerNumber = driver.findElement(By.xpath("//a[contains(@id,'Left_" + power +"')]"));
            wePowerNumber.click();
        }
        catch (Throwable e){}
        Wait(1);
    }
    public void clickRPowerPlano(String power) {
        WebElement wePower = driver.findElement(By.xpath("//input[contains(@id,'RightPowerPicker')]"));
        wePower.click();
        Wait(5);
        System.out.println("Power for right eye: Plano");
        WebElement wePowerNumber = driver.findElement(By.xpath("//a[contains(@id,'Right_" + power +"')]"));
        wePowerNumber.click();
        Wait(5);
    }
    public void clickLPowerPlano(String power) {
        WebElement wePower = driver.findElement(By.xpath("//input[contains(@id,'LeftPowerPicker')]"));
        wePower.click();
        Wait(5);
        System.out.println("Power for left eye: Plano");
        WebElement wePowerNumber = driver.findElement(By.xpath("//a[contains(@id,'Left_" + power +"')]"));
        wePowerNumber.click();
        Wait(5);
    }

  public void clickRBC(String bc) {
    String thePickerString = "//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.BaseCurve')]";
      WebElement weBc = driver.findElement(By.xpath(thePickerString));
      weBc.click();
      System.out.println("BC for right eye: " + bc);
      weBc.sendKeys(bc,Keys.ENTER);
      Wait(1);
  }
    public void clickLBC(String bc) {
        String thePickerString = "//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.BaseCurve')]";
        WebElement weBc = driver.findElement(By.xpath(thePickerString));
        weBc.click();
        System.out.println("BC for left eye: " + bc);
        weBc.sendKeys(bc,Keys.ENTER);
        Wait(1);
    }
    public void clickRDia(String dia) {
        WebElement weDia = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.DiameterLength')]"));
        weDia.click();
        System.out.println("Dia for right eye: " + dia);
        weDia.sendKeys(dia,Keys.ENTER);
        Wait(1);
    }
    public void clickLDia(String dia) {
        WebElement weDia = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.DiameterLength')]"));
        weDia.click();
        System.out.println("Dia for left eye: " + dia);
        weDia.sendKeys(dia,Keys.ENTER);
        Wait(1);
    }

    public void clickRCyl(String cyl) {
        WebElement weCyl = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.CylinderPower')]"));
        weCyl.click();
        System.out.println("Cyl for right eye: " + cyl);
        weCyl.sendKeys(cyl,Keys.ENTER);
        Wait(1);
    }
    public void clickLCyl(String cyl) {
        WebElement weCyl = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.CylinderPower')]"));
        weCyl.click();
        System.out.println("Cyl for left eye: " + cyl);
        weCyl.sendKeys(cyl,Keys.ENTER);
        Wait(1);
    }
    public void clickRAxis(String axis) {
        WebElement weAxis = driver.findElement
                (By.xpath("//select[contains(@name,'PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.AxisDegree')]"));
        weAxis.click();
        System.out.println("Axis for right eye: " + axis);
        weAxis.sendKeys(axis,Keys.ENTER);
        Wait(1);
    }
    public void clickLAxis(String axis) {
        WebElement weAxis = driver.findElement
                (By.xpath("//select[contains(@name,'PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.AxisDegree')]"));
        weAxis.click();
        System.out.println("Axis for left eye: " + axis);
        weAxis.sendKeys(axis,Keys.ENTER);
        Wait(1);
    }
    public void clickRColor(String color) {
        WebElement weColor = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.ColorId')]"));
        weColor.click();
        weColor.sendKeys(color,Keys.ENTER);
        System.out.println("Color for right eye: " + color);
        Wait(1);

    }
    public void clickLColor(String color) {
        WebElement weColor = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.ColorId')]"));
        weColor.click();
        System.out.println("Color for left eye: " + color);
        weColor.sendKeys(color,Keys.ENTER);
        Wait(1);
    }
    public void clickRboxes(String box) {
        WebElement weBox = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.Quantity')]"));
        weBox.click();
        System.out.println("Boxes for right eye: " + box);
        weBox.sendKeys(box,Keys.ENTER);
        System.out.println(box + " boxes Right Eye");
        Wait(1);
    }
    public void clickLboxes(String box) {
        WebElement weBox = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.Quantity')]"));
        weBox.click();
        System.out.println("Boxes for left eye: " + box);
        weBox.sendKeys(box,Keys.ENTER);
        System.out.println(box + " boxes Left Eye");
        Wait(1);
    }

    public void clickRAdd(String add) {
        WebElement weAdd = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.AddPower')]"));
        weAdd.click();
        System.out.println("ADD for Right eye: " + add);
        weAdd.sendKeys(add,Keys.ENTER);
        Wait(1);
    }
    public void clickLAdd(String add) {
        WebElement weAdd = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.AddPower')]"));
        weAdd.click();
        System.out.println("ADD for left eye: " + add);
        weAdd.sendKeys(add,Keys.ENTER);
        Wait(1);
    }
  public void typePatientName(String first, String last) {
    WebElement firstPatientName = driver.findElement(By.xpath("//input[contains(@id,'firstNameInput')]"));
      firstPatientName.clear();
      firstPatientName.sendKeys(first);
      WebElement lastPatientName = driver.findElement(By.xpath("//input[contains(@id,'lastNameInput')]"));
      lastPatientName.clear();
      lastPatientName.sendKeys(last);
      System.out.println("Patient First Name is: " + first);
      System.out.println("Patient Last Name is: " + last);
  }

  public void clickAddRx(){ //make this a if else if
      try {
          driver.findElement(By.xpath("//span[contains(.,'Add Another Rx')]")).click();
      }
    catch (Throwable e){}
      try {
      driver.findElement(By.xpath("//a[contains(.,'Select brand for another person')]")).click();
      }
      catch (Throwable e){}
      try {
          driver.findElement(By.xpath("//a[contains(@name,'saveAndAddAnotherBrand')]")).click();
      }
      catch (Throwable e){System.out.println("DID NOT CLICK RX");}
      System.out.println("Clicked Add Rx");
  }
    public void clickUpdateCart() {
        printPageTitle();
        Wait(5);
        try{ //phone
            driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-phone rd-stretchButton rd-orangeButton')]")).click();
        }
        catch (Throwable e){}
        try{  //tablet
            driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletRightButton rd-orangeButton')]")).click();
        }
        catch (Throwable e){}
        try{  //desktop
            driver.findElement(By.xpath("//input[contains(@type,'submit')]")).click();
        }
        catch (Throwable e){}
        System.out.println("Clicked Update");
        Wait(5);
    }
  public void clickAddToCart() {
      printPageTitle();
      Wait(5);
      try{
      driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-phone rd-stretchButton rd-orangeButton rd-addToCartButton')]")).click();
      }
      catch (Throwable e){}
      try{
          driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletRightButton rd-orangeButton rd-addToCartButton')]")).click();
      }
      catch (Throwable e){}
      try{
          driver.findElement(By.xpath("//input[contains(@type,'submit')]")).click();
      }
      catch (Throwable e){System.out.println("Did not find Add to cart button");}
          System.out.println("Clicked Add To Cart");
      Wait(5);
  }
    public void clickCartEdit(){
        Wait(5);
        printPageTitle();
        driver.findElement(By.xpath("//a[contains(@id,'cartEditLink')]")).click();
        System.out.println("Clicked Edit");
        Wait(5);
    }
    //change shipping method on the cart page
    //enter the letter to type
    // s = standard
    // n = next day mail. nn = next day noon.
    // c = canada, cc= can exp.
    // e = expedited,
    // i = international, ii= international exp.
    public void selectShippingCart(String ship) {
        try{
            WebElement weShipping = driver.findElement(By.xpath("//select[contains(@id,'ShippingViewModel_SelectedShipperCode')]"));
            weShipping.click();
            weShipping.sendKeys(ship);
            Wait(1);
            driver.findElement(By.xpath("//label[contains(.,'Shipping')]")).click();
            Wait(4);
        }
        catch (Throwable e){}
        try{
            WebElement weShipping = driver.findElement(By.xpath("//select[contains(@id,'SelectedShipperCode')]"));
            weShipping.click();
            weShipping.sendKeys(ship);
            Wait(1);
            driver.findElement(By.xpath("//label[contains(.,'Shipping')]")).click();
            Wait(4);
        }
        catch (Throwable e){}
        try{
            WebElement weShipping = driver.findElement(By.xpath("//select[contains(@id,'SelectedShipperCode')]"));
            weShipping.click();
            weShipping.sendKeys(ship);
            Wait(1);
            driver.findElement(By.xpath("//label[contains(.,'Shipping')]")).click();
            Wait(4);
        }
        catch (Throwable e){}
        System.out.println("Method of shipping: " + ship);
    }
    //change shipping method on the RS page DOES NOT WORK
    //enter the letter to type
    // MAIL = standard
    // USEM = next day mail. FED1 = next day noon.
    // c = canada, cc= can exp.
    // FED2 = expedited,
    // i = international, ii= international exp.
    public void selectShippingRS(String ship) {
        WebElement weShippingRS = driver.findElement(By.xpath("//a[contains(@id,'ReviewOrderSummary_EditShippingLink')]"));

        System.out.println("Found Edit");
        weShippingRS.click();
        System.out.println("Clicked on Edit");
        Wait(3);
        String theShippingString = "//input[contains(@id,'" + ship + "')]";
        //driver.findElement(By.xpath("//input[contains(@id, ship)]")).click();
        driver.findElement(By.xpath(theShippingString)).click();
        System.out.println("Method of shipping: " + ship);
        //driver.findElement(By.xpath("//span[contains(.,'Select')]")).click();
        Wait(4);
        //weShipping.sendKeys(ship);
        Wait(1);
        //driver.findElement(By.xpath("//label[contains(.,'Shipping')]")).click();
        Wait(4);
    }

  public void clickCart_Continue() {
      printPageTitle();
      Wait(4);
      System.out.println("Find Continue");
      try{
          WebElement weCartContinue = driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-phone rd-stretchButton rd-orangeButton rd-continueButton')]"));
          System.out.println("Click Continue mobile");
          weCartContinue.click();      }
      catch (Throwable e){}
      try {
          WebElement weCartContinue = driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletRightButton rd-orangeButton rd-continueButton')]"));
          System.out.println("Click Continue tablet");
          weCartContinue.click();
      }
      catch (Throwable e){}
      try {
          WebElement weCartContinue = driver.findElement(By.xpath("//img[contains(@alt,'continue')]"));
          System.out.println("Click Continue desktop");
          weCartContinue.click();
          weCartContinue.click();
      }
      catch (Throwable e){}
      Wait(10);
  }

  public void typeShippingName(String first, String last) {
      driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.FirstName')]")).clear();
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.FirstName')]")).sendKeys(first);
      System.out.println("Shipping First Name is: " + first);
      driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.LastName')]")).clear();
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.LastName')]")).sendKeys(last);
      System.out.println("Shipping Last Name is: " + last);
  }

  public void xclickCountry(String country) {
    driver.findElement(By.xpath("//select[contains(@name,'ShippingAddress.Country')]")).click();
    String theCountryString = "//option[contains(@value,'" + country + "')]";
    driver.findElement(By.xpath(theCountryString)).click();
      System.out.println("Country is: " + country);
      Wait(3);
  }
    public void clickCountry(String country) {
        driver.findElement(By.xpath("//select[contains(@name,'ShippingAddress.Country')]")).click();
        driver.findElement(By.xpath("//select[contains(@name,'ShippingAddress.Country')]")).sendKeys(country, Keys.TAB);
        Wait(3);
        //driver.findElement(By.xpath("//select[contains(@name,'ShippingAddress.Country')]")).sendKeys(country, Keys.ENTER);
        System.out.println("Country is: " + country);
        Wait(3);
    }

  public void typeShippingAddress() {
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.AddressLine1')]")).sendKeys("ship address " + new Date().getTime());
      System.out.println("Shipping Address is: ");
      Wait(3);
  }
    public void typeShippingAddressINI(String address) {
        driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.AddressLine1')]")).sendKeys(address);
        System.out.println("Shipping Address is: " +  address);
        Wait(3);
    }

  public void typeShippingCity(String city) {
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.City')]")).sendKeys(city);
      System.out.println("City is: " + city);
      Wait(3);
  }

  public void typeShippingState(String state) {
      Wait(3);
      try {
      driver.findElement(By.xpath("//select[contains(@id,'ShippingAddress_StateProvinceOrRegion')]")).sendKeys(state,Keys.ENTER);
      System.out.println("State is: " + state);
        }
    catch (Throwable e){ }
      try {
          driver.findElement(By.xpath("//input[contains(@id,'StateProvinceOrRegion')]")).sendKeys(state,Keys.ENTER);
          System.out.println("Region is: " + state);
      }
      catch (Throwable e){ }
      try {
          driver.findElement(By.xpath("//input[contains(@id,'StateProvinceOrRegion')]")).sendKeys(state,Keys.TAB);
          System.out.println("Region is: " + state);
      }
      catch (Throwable e){ }
      try {
          driver.findElement(By.xpath("//select[contains(@id,'ShippingAddress_StateProvinceOrRegion')]")).sendKeys(state,Keys.ENTER);
          System.out.println("State is: " + state);
      }
      catch (Throwable e){
          System.out.println("State is NOT USED. FAIL");
      }
      Wait(3);
  }

  public void typeShippingZip(String zip) {
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.ZipOrPostalCode')]")).sendKeys(zip);
      System.out.println("Zip is: " + zip);
  }

    public void typeIntShippingZip(String zip) {
        Wait(4);
        driver.findElement(By.xpath("//input[contains(@id,'ShippingAddress_ZipOrPostalCode')]")).sendKeys(zip);
        System.out.println("PostalCode is: " + zip);
    }

  public void typeShippingPhone() {
      String thePhoneString = "" + new Date().getTime();
      try{
          driver.findElement(By.xpath("//input[contains(@name,'Phone')]")).click();
          driver.findElement(By.xpath("//input[contains(@name,'Phone')]")).clear();
          driver.findElement(By.xpath("//input[contains(@name,'Phone')]")).sendKeys(thePhoneString);
          System.out.println("First Phone Method");
          Wait(3);
      }
      catch (Throwable e){System.out.println("First Phone Method failed");}
      try{
          driver.findElement(By.xpath("//input[contains(@name,'Phone')]")).click();
          driver.findElement(By.xpath("//input[contains(@name,'Phone')]")).clear();
          driver.findElement(By.xpath("//input[contains(@name,'Phone')]")).sendKeys(thePhoneString);
          System.out.println("First Phone Method");
      }
      catch (Throwable e){System.out.println("Second Phone Method failed");}
      System.out.println("Phone used is: " + thePhoneString);
  }
    public void typeIntShippingPhone() {
        String thePhoneString = "" + new Date().getTime();
        driver.findElement(By.xpath("//input[contains(@id,'PhoneNumber')]")).clear();
        driver.findElement(By.xpath("//input[contains(@id,'PhoneNumber')]")).sendKeys(thePhoneString);
        System.out.println("Phone used is: " + thePhoneString);
        Wait(3);
    }
  public void typeShippingEmail(String email, String testNumber) {
    String theEmailString = email + "_" + new Date().getTime() + "@invalid.com";
    driver.findElement(By.xpath("//input[contains(@name,'EmailAddress')]")).sendKeys(theEmailString);
    System.out.println("Email used is: " + theEmailString);
      printToExcel(testNumber,theEmailString);
  }
  public void typePassword_newcust(String password) {
    driver.findElement(By.xpath("//input[contains(@id,'a41-checkout-password')]")).sendKeys(password);
    driver.findElement(By.xpath("//input[contains(@id,'a41-checkout-confirm-password')]")).sendKeys(password);
      System.out.println("Password Entered: " + password);
  }

  public void clickNewAddress_Continue() {
    driver.findElement(By.xpath("//input[contains(@value,'continue')]")).click();
      System.out.println("Clicked Continue on New Address Page");
    Wait(3);
  }

  public void typeDoctorSearch(String doctor) {
    driver.findElement(By.xpath("//input[contains(@name,'DoctorSearchOptionsViewModel.DoctorOrClinic')]")).sendKeys(doctor);
      System.out.println("input dr name for search");
    Wait(2);
  }

  public void typeDoctorStateAndFind(String state) {
        new Select(driver.findElement(By.xpath("//select[contains(@id,'DoctorSearchOptionsViewModel_State')]"))).selectByValue(state);
    Wait(2);
      try{  //phone
      driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-phone rd-stretchButton rd-orangeButton rd-searchButton')]")).click();
      }
      catch (Throwable e){}
    try{  //tablet
      driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletLeftButton rd-orangeButton  rd-searchButton')]")).click();
    }
        catch (Throwable e){}
      try{    //desktop
          driver.findElement(By.xpath("//img[contains(@alt,'search')]")).click();
      }
      catch (Throwable e){}
      System.out.println("searched for Doctor");
    Wait(2);
  }

  public void typeDoctorPhoneAndFind(String phone) {
    driver.findElement(By.xpath("//input[contains(@id,'a41-search-by-phone')]")).click();
    driver.findElement(By.xpath("//input[contains(@id,'PhoneNumber')]")).sendKeys(phone);
    Wait(2);
    driver.findElement(By.xpath("//img[contains(@src,'DoctorSearch/search-orange.png')]")).click();
      System.out.println("searched for Doctor");
    Wait(2);
  }

  //select doctor  this will just take the first result
  public void selectDoctor() {
      try{
          driver.findElement(By.xpath("//a[contains(@id,'SelectDoctorButton2696254')]")).click();

      }
      catch (Throwable e){}
      try{
          driver.findElement(By.xpath("//div[contains(@class,'a41-doctor-select')]")).click();
      }
      catch (Throwable e){}
      try{
          driver.findElement(By.xpath("//img[contains(@src,'/img/UI3/DoctorSearch/bttn-select.png')]")).click();
          System.out.println("selected Doctor with img src");
      }
      catch (Throwable e){}
      try{  //production
          driver.findElement(By.xpath("//a[contains(@id,'SelectDoctorButton3256437')]")).click();
      }
      catch (Throwable e){}
      System.out.println("selected Doctor 2696254");
    Wait(3);
  }
  public void typeCreditCard(String cardNumber) {
      Wait(4);
      driver.findElement(By.xpath("//input[contains(@id,'CreditCardNumber')]")).click();
    driver.findElement(By.xpath("//input[contains(@id,'CreditCardNumber')]")).sendKeys(cardNumber);
      System.out.println("CC Used: " + cardNumber);
  }
  public void typeCreditCardName(String creditName) {
    driver.findElement(By.xpath("//input[contains(@id,'CreditCardName')]")).sendKeys(creditName);
      System.out.println("CC Name Used: " + creditName);
  }
  public void pickCreditCardExpDate(String month, String year) {
      driver.findElement(By.xpath("//select[contains(@id,'CreditCardExpirationMonth')]")).sendKeys(month);
      driver.findElement(By.xpath("//select[contains(@id,'CreditCardExpirationYear')]")).sendKeys(year);
      System.out.println("CC exp date:" + month + " " + year);
  }
  public void clickBottomSubmitButton() {
      try{//phone
          driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-phone rd-stretchButton rd-orangeButton')]")).click();
      }
      catch (Throwable e){}
      try{   //tablet
          driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletRightButton rd-orangeButton')]")).click();
      }
      catch (Throwable e){}
      try{  //desktop
          driver.findElement(By.xpath("//input[contains(@type,'submit')]")).click();
      }
      catch (Throwable e){}
      System.out.println("Clicked the Submit button");
      Wait(20);
  }
    public void verifyExpiredCard() {
        driver.findElement(By.xpath("//ul[contains(@id,'errorMessagesUl')]"));
        System.out.println("Got the Expired Card message");
        System.out.println("Next - Change exp date to be correct");
    }
  public void verifyDeclinedCard() {
      try{  //phone
          driver.findElement(By.xpath("//img[contains(@src,'PaymentWait.gif')]"));
      }
      catch (Throwable e) {}
      try{    //desktop
          driver.findElement(By.xpath("//div[contains(@class,'errorPageHeader1')]"));
      }
      catch (Throwable e)
      {
          System.out.println("No errorPageHeader1 found");
      }
      System.out.println("Found CreditCard Error page");
  }
    //Go to cart 1 item


    public void goToCart1Item() {
        System.out.println("Next Go To Cart");
        try{  //phone
            driver.findElement(By.xpath("//a[contains(.,'Cart1')]")).click();
            Wait(2);
            driver.findElement(By.xpath("//p[contains(.,'	Please review your cart	')]"));
        }
        catch(Throwable e) {}
        try{    //desktop
            System.out.println("Next Go To Cart");
            driver.findElement(By.xpath("//a[contains(@title,'View Cart')]")).click();
            Wait(2);
            driver.findElement(By.xpath("//p[contains(.,'	Please review your cart	')]"));
        }
        catch(Throwable e) {}
        try{ //tablet
            System.out.println("Next Go To Cart");
            driver.get(desktopBaseUrl + "cart");
            Wait(2);
            driver.findElement(By.xpath("//p[contains(.,'Please review your cart')]"));
        }
        catch(Throwable e) {
            System.out.println("You did not make it to the cart");
        }
        System.out.println("You are in the cart... proceed as normal");
        Wait(6);
    }
  //this is what should be used. we shouldn't have to specify how many items in a cart.
    public void goToCart() {
        System.out.println("Next Go To Cart");
        driver.findElement(By.xpath("//a[contains(.,'Cart1')]")).click();
        Wait(2);
        driver.findElement(By.xpath("//p[contains(.,'	Please review your cart	')]"));
        System.out.println("You are in the cart... proceed as normal");
        Wait(6);
    }
    public void goToCart2Items() {
        System.out.println("Next Go To Cart");
        driver.findElement(By.xpath("//a[contains(.,'Cart2')]")).click();
        Wait(2);
        driver.findElement(By.xpath("//p[contains(.,'	Please review your cart	')]"));
        System.out.println("You are in the cart... proceed as normal");
        Wait(6);
    }
  public void verifyThankYouPage(String ship) {
      Wait(14);
      System.out.println("Page title is: " + driver.getTitle());
    driver.findElement(By.xpath("//h1[contains(.,'Thank you for your order!')]"));
      System.out.println("Thank You page says Thank you for your order! ");
    driver.findElement(By.xpath("//p[contains(.,'A confirmation of this order has been sent to:')]"));
      System.out.println("A confirmation of this order has been sent to:");
      String shippingValidationTY =  driver.findElement(By.xpath("//dt[@class='a41-shipping-time']")).getText();
      System.out.println("Shipping method is:" + shippingValidationTY);
      verifyTxtPresent("Shipping Method is: : ", ship, shippingValidationTY);
      String theFinalPrice = driver.findElement(By.xpath("//dd[contains(@id,'orderTotal')]")).getText();
      System.out.println("Total: " + theFinalPrice);
      try
      {
          String theFinalPriceAfterRebate = driver.findElement(By.xpath("//dl[contains(@class,'total')]")).getText();
          System.out.println("Total after rebate: " + theFinalPriceAfterRebate);
      }
      catch (Throwable e)
      {
          System.out.println("No Rebate line found on ty page");
      }
      String theOrderNumber = driver.findElement(By.xpath("//td[contains(@id,'orderNumber')]")).getText();
      System.out.println("Order Number: " + theOrderNumber);
  }
    public void verifyPDP(String brand) {
        Wait(14);
        System.out.println("Page title is: " + driver.getTitle());
        String verifyProdPDP =  driver.findElement(By.xpath("//h1[@class='product-heading']")).getText();
        System.out.println("Brand is:" + verifyProdPDP);
        verifyTxtPresent("Title is: ", brand, verifyProdPDP);
    }
    public void verifyTxtPresent(String identifier, String desired, String actual){
        // the pattern we want to search for
        Pattern p = Pattern.compile(desired);
        Matcher m = p.matcher(actual);
        // try to find a match
        if (m.find())
            System.out.println("VERIFIED " + identifier + "Found " + desired + " within " + actual + "." );
        else
            System.out.println("FAIL " + identifier + "NOT FOUND " + desired + " within " + actual + "." );
    }
    public void verifyCart(String brand,String patientName,String price,String totalR, String totalL, String cartTotal) {
        Wait(14);
        System.out.println("Page title is: " + driver.getTitle());
        try{   //NI
        String verifyTitleCart =  driver.findElement(By.xpath("//p[@class='']")).getText();
        verifyTxtPresent("Title is: ", "Please review your cart", verifyTitleCart);
        }
        catch (Throwable e){ }
        try{  //RI
            String verifyTitleCart =  driver.findElement(By.xpath("//p[@class='review-cart-p']")).getText();
            verifyTxtPresent("Title is: ", "Please review your cart", verifyTitleCart);
        }
        catch (Throwable e) { }
        //verify brand
        try{ //NI
            String verifyBrandCart =  driver.findElement(By.xpath("//div[@id='patientNameDiv']")).getText();
            verifyTxtPresent("Brand in Cart: ", brand, verifyBrandCart);
            verifyTxtPresent("Patient Name in Cart: ", patientName, verifyBrandCart);
        }
        catch (Throwable e) { }
        try{ //RI
            String verifyBrandCart =  driver.findElement(By.xpath("//div[@class='ri-name']")).getText();
            verifyTxtPresent("Brand in Cart: ", brand, verifyBrandCart);
            verifyTxtPresent("Patient Name in Cart: ", patientName, verifyBrandCart);
        }
        catch (Throwable e) { }
        //price
        String verifyPriceBoxCart =  driver.findElement(By.xpath("//div[@parameter='price']")).getText();
        verifyTxtPresent("Per Box Price in Cart: ", price, verifyPriceBoxCart);
        try
        {
            String verifyPriceREyeCart = driver.findElement(By.xpath("//div[@class='innerParam RightEyeViewModel.EyePrescriptionViewModel.Total']")).getText();
            verifyTxtPresent("R Eye Price in Cart: ",totalR,verifyPriceREyeCart);
        }
        catch (Throwable e)
        {
            System.out.println("No Right Eye");
        }
        try
        {
            String verifyPriceLEyeCart =  driver.findElement(By.xpath("//div[@class='innerParam LeftEyeViewModel.EyePrescriptionViewModel.Total']")).getText();
            verifyTxtPresent("L Eye Price in Cart: ",totalL,verifyPriceLEyeCart);
        }
        catch (Throwable e)
        {
            System.out.println("No Left Eye");
        }
        try
        {
            String verifyPriceTotalCart =  driver.findElement(By.xpath("//td[@id='cartTotalTd']")).getText();
            verifyTxtPresent("Cart total: ",cartTotal,verifyPriceTotalCart);
        }
        catch (Throwable e){ }
        String verifyPriceShippingCart =  driver.findElement(By.xpath("//div[contains(@id,'uniform-ShippingViewModel_SelectedShipperCode')]")).getText();
        System.out.println("Shipping: " + verifyPriceShippingCart);
    }
    public void verifyRS(String brand,String patientName,String price,String totalR, String totalL, String rsSubTotal, String rsTax, String rsTotal,String rsTotalAfterRebate,String rsRebate,String rsShipping) {
        Wait(14);
        System.out.println("Page title is: " + driver.getTitle());
        try{   //NI
            String verifyTitleRS =  driver.findElement(By.xpath("//body[@s.channel='Review & Submit']")).getText();
            verifyTxtPresent("Title is: ", "Review & Submit", verifyTitleRS);
        }
        catch (Throwable e){ }
        try{  //RI
            String verifyTitleRS =  driver.findElement(By.xpath("//body[@s.channel='Review & Submit']")).getText();
            verifyTxtPresent("Title is: ", "Review & Submit", verifyTitleRS);
        }
        catch (Throwable e) { }
        //verify brand
        try{ //NI
            String verifyBrandRS =  driver.findElement(By.xpath("//div[@class='review-order-payment-item-description']")).getText();
            verifyTxtPresent("Brand on RS: ", brand, verifyBrandRS);
            verifyTxtPresent("Patient Name in RS: ", patientName, verifyBrandRS);
        }
        catch (Throwable e) { }
        try{ //RI
            String verifyBrandRS =  driver.findElement(By.xpath("//div[@class='ri-name']")).getText();
            verifyTxtPresent("Brand in RS: ", brand, verifyBrandRS);
            verifyTxtPresent("Patient Name in RS: ", patientName, verifyBrandRS);
        }
        catch (Throwable e) { }
        //price
        String verifyPriceBoxRS =  driver.findElement(By.xpath("//div[@parameter='price']")).getText();
        verifyTxtPresent("Per Box Price in RS: ", price, verifyPriceBoxRS);
        try
        {
            String verifyPriceREyeRS = driver.findElement(By.xpath("//div[@class='innerParam RightEyeViewModel.EyePrescriptionViewModel.Total']")).getText();
            verifyTxtPresent("R Eye Price in RS: ",totalR,verifyPriceREyeRS);
        }
        catch (Throwable e)
        {
            System.out.println("No Right Eye");
        }
        try
        {
            String verifyPriceLEyeRS =  driver.findElement(By.xpath("//div[@class='innerParam LeftEyeViewModel.EyePrescriptionViewModel.Total']")).getText();
            verifyTxtPresent("L Eye Price in RS: ",totalL,verifyPriceLEyeRS);
        }
        catch (Throwable e)
        {
            System.out.println("No Left Eye");
        }
        try
        {
            String verifyPriceSubTotalRS =  driver.findElement(By.xpath("//dd[@class='a41-checkout-review-subtotal']")).getText();
            verifyTxtPresent("RS sub-total: ",rsSubTotal,verifyPriceSubTotalRS);
        }
        catch (Throwable e){ }
        try{ //NI
            String verifyTotalRS =  driver.findElement(By.xpath("//dl[@class='a41-checkout-review-totals total']")).getText();
            verifyTxtPresent("Total on RS: ", rsTotal, verifyTotalRS);
        }
        catch (Throwable e) { }
        //try{ //RI
        //    String verifyTotalRS =  driver.findElement(By.xpath("//div[@class='ri-name']")).getText();
        //    verifyTxtPresent("Total on RS: ", rsTotal, verifyTotalRS);
       // }
       // catch (Throwable e) { }
        try{ //NI
            String verifyTotalAfterRebateRS =  driver.findElement(By.xpath("//dl[@class='a41-checkout-review-totals total']")).getText();
            verifyTxtPresent("Total on RS: ", rsTotalAfterRebate, verifyTotalAfterRebateRS);
        }
        catch (Throwable e) { }
        try{ //NI
            String verifyTaxRS =  driver.findElement(By.xpath("//dl[@class='a41-checkout-review-totals a41-checkout-review-tax']")).getText();
            verifyTxtPresent("Tax in RS: ", rsTax, verifyTaxRS);
        }
        catch (Throwable e) {System.out.println("No Tax");}
        //try{ //RI
        //    String verifyTaxRS =  driver.findElement(By.xpath("//div[@class='ri-name']")).getText();
        //    verifyTxtPresent("Tax in RS: ", rsTax, verifyTaxRS);
       // }
       // catch (Throwable e) { }
        try{ //NI
            String verifyRebateRS =  driver.findElement(By.xpath("//div[@class='review-order-payment-item-description']")).getText();
            verifyTxtPresent("Rebate on RS: ", rsRebate, verifyRebateRS);
            System.out.println("rebate text" + verifyRebateRS);
        }
        catch (Throwable e) {}
        try{ //RI
            String verifyRebateRS =  driver.findElement(By.xpath("//div[contains(@class,'a41-checkout-review-details-right-padding')]")).getText();
            verifyTxtPresent("Rebate on RS: ", rsRebate, verifyRebateRS);
        }
        catch (Throwable e) {System.out.println("No Rebate");}
        try{
            String verifyPriceShippingRS =  driver.findElement(By.xpath("//dt[contains(@class,'a41-shipping-time a41-shipping-padding')]")).getText();
            verifyTxtPresent("Shipping on RS: ",rsShipping,verifyPriceShippingRS);
        }
        catch (Throwable e) { }
    }
    //asserts
    public void assertThankYouPage(String ship) {
        Wait(14);
        System.out.println("Page title is: " + driver.getTitle());
        driver.findElement(By.xpath("//h1[contains(.,'Thank you for your order!')]"));
        System.out.println("Thank You page says Thank you for your order! ");
        driver.findElement(By.xpath("//p[contains(.,'A confirmation of this order has been sent to:')]"));
        System.out.println("A confirmation of this order has been sent to:");
        String theFinalPrice = driver.findElement(By.xpath("//dd[contains(@id,'orderTotal')]")).getText();
        System.out.println("Total: " + theFinalPrice);
        try
        {
            String theFinalPriceAfterRebate = driver.findElement(By.xpath("//dd[contains(@style,'color: #0BA14B; font-weight: bold;')]")).getText();
            System.out.println("Total after rebate: " + theFinalPriceAfterRebate);
        }
        catch (Throwable e)
        {
            System.out.println("No Rebate");
        }
        String theOrderNumber = driver.findElement(By.xpath("//td[contains(@id,'orderNumber')]")).getText();
        System.out.println("Order Number: " + theOrderNumber);
        String shippingValidationTY =  driver.findElement(By.xpath("//dt[@class='a41-shipping-time']")).getText();
        System.out.println("Shipping method is:" + shippingValidationTY);
        assertTxtPresent("Shipping Method is: : ", ship, shippingValidationTY);
    }
    public void assertPDP(String brand) {
        Wait(14);
        System.out.println("Page title is: " + driver.getTitle());
        String verifyProdPDP =  driver.findElement(By.xpath("//h1[@class='product-heading']")).getText();
        System.out.println("Brand is:" + verifyProdPDP);
        verifyTxtPresent("Title is: ", brand, verifyProdPDP);
    }
    public void assertTxtPresent(String identifier, String desired, String actual){
        // the pattern we want to search for
        Pattern p = Pattern.compile(desired);
        Matcher m = p.matcher(actual);
        // try to find a match
        if (m.find()){
            System.out.println("VERIFIED " + identifier + "Found " + desired + " within " + actual + "." );
        }
        else {
            System.out.println("FAIL " + identifier + "NOT FOUND " + desired + " within " + actual + "." );
        assert false;
        }
    }
    public void assertCart(String brand,String patientName,String price,String totalR, String totalL, String cartTotal) {
        Wait(14);
        System.out.println("Page title is: " + driver.getTitle());
        try{   //NI
            String verifyTitleCart =  driver.findElement(By.xpath("//p[@class='']")).getText();
            assertTxtPresent("Title is: ", "Please review your cart", verifyTitleCart);
        }
        catch (Throwable e){ }
        try{  //RI
            String verifyTitleCart =  driver.findElement(By.xpath("//p[@class='review-cart-p']")).getText();
            verifyTxtPresent("Title is: ", "Please review your cart", verifyTitleCart);
        }
        catch (Throwable e) { }
        //verify brand
        try{ //NI
            String verifyBrandCart =  driver.findElement(By.xpath("//div[@id='patientNameDiv']")).getText();
            verifyTxtPresent("Brand in Cart: ", brand, verifyBrandCart);
            verifyTxtPresent("Patient Name in Cart: ", patientName, verifyBrandCart);
        }
        catch (Throwable e) { }
        try{ //RI
            String verifyBrandCart =  driver.findElement(By.xpath("//div[@class='ri-name']")).getText();
            verifyTxtPresent("Brand in Cart: ", brand, verifyBrandCart);
            verifyTxtPresent("Patient Name in Cart: ", patientName, verifyBrandCart);
        }
        catch (Throwable e) { }
        //price
        String verifyPriceBoxCart =  driver.findElement(By.xpath("//div[@parameter='price']")).getText();
        verifyTxtPresent("Per Box Price in Cart: ", price, verifyPriceBoxCart);
        try
        {
            String verifyPriceREyeCart = driver.findElement(By.xpath("//div[@class='innerParam RightEyeViewModel.EyePrescriptionViewModel.Total']")).getText();
            verifyTxtPresent("R Eye Price in Cart: ",totalR,verifyPriceREyeCart);
        }
        catch (Throwable e)
        {
            System.out.println("No Right Eye");
        }
        try
        {
            String verifyPriceLEyeCart =  driver.findElement(By.xpath("//div[@class='innerParam LeftEyeViewModel.EyePrescriptionViewModel.Total']")).getText();
            verifyTxtPresent("L Eye Price in Cart: ",totalL,verifyPriceLEyeCart);
        }
        catch (Throwable e)
        {
            System.out.println("No Left Eye");
        }
        try
        {
            String verifyPriceTotalCart =  driver.findElement(By.xpath("//td[@id='cartTotalTd']")).getText();
            verifyTxtPresent("Cart total: ",cartTotal,verifyPriceTotalCart);
        }
        catch (Throwable e){ }
        String verifyPriceShippingCart =  driver.findElement(By.xpath("//div[contains(@id,'uniform-ShippingViewModel_SelectedShipperCode')]")).getText();
        System.out.println("Shipping: " + verifyPriceShippingCart);
    }
}
