package TabletAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeNI1EyeAsphericTest extends TestBase {


    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphone"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void tabletTest(String ffprofile) {
      openWebPage(tabletDevice);
      printTestNumber("SMOKE 44039 NI 1 Eye Only Astigmatism, Expired CC");
      //clickPhoneMainPage_NewButton();
      clickFindBrand();

      //search for lenses
      searchAllBrand("Astigmatism");

    //click on Acuvue Oasys for Astigmatism
    clickPhoneBrand("AcuvueOasysforAstigmatism");

    //Product Detail page Enter Power
    //mobile

      //uncheck Right Eye (use twice to select again)
      checkBoxRightEye();
      //Power
    clickLPower("+++");


    //cyl
    clickLCyl("--");
      //axis
      clickLAxis("11");
    //enter patient name first then last
    typePatientName("PatientFirst", "PatientLast");

    //Add to cart
    clickAddToCart();

    //cart page
      selectShippingCart("e");
      //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
      verifyCart("Acuvue Oasys for Astigmatism","PatientFirst PatientLast","47.99","","191.96","206.95");
    //click continue
    clickCart_Continue();

    //Enter Address Information
    //names
    typeShippingName("shipfirst", "shiplast");
    //country
    clickCountry("united states");
    //address
    typeShippingAddress();
    //city
    typeShippingCity("slc");
    typeShippingState("UT");
    typeShippingZip("84121");
    //phone
    typeShippingPhone();
    typeShippingEmail("test");
    typePassword_newcust("password");
    clickNewAddress_Continue();

    //Find then select Doctor by name and state
    typeDoctorSearch("test");
    typeDoctorStateAndFind("Utah");
    selectDoctor();

    //Enter Billing
    typeCreditCard("4012000077777777");
    typeCreditCardName("Blah");
    pickCreditCardExpDate("02","2013");

    //submit
    clickBottomSubmitButton();
      //exp card error
      verifyExpiredCard();
      //change exp date and resubmit
      pickCreditCardExpDate("02","2016");
      clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage();
    //Close the browser
    driver.quit();
  }
}
