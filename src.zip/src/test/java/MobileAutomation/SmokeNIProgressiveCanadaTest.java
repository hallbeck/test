package MobileAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeNIProgressiveCanadaTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void phoneTest(String ffprofile) {
      openWebPage(mobileDevice);

      //click on interstitial for now
      clickNoThanksButton();
    // click on New to 1800contacts Find your brand
      String testNumber = "44034";
      printTestNumber("SMOKE" + testNumber + "NI MultiFocal Canada CC");
      //clickPhoneMainPage_NewButton();
      clickFindBrand();

      //search for lenses
       searchAllBrand("multifocal");
    //click on brand
    clickPhoneBrand("PureVisionMulti-Focal");

    //Product Detail page
    //Power
    clickRPower("++++++++++++++++");
    clickLPower("----------");

      //ADD
      clickRAdd("2");
      clickLAdd("2");

      //enter patient name first then last
    typePatientName("PatientFirst", "PatientLast");

    //Add to cart
    clickAddToCart();

    //cart page
      //change shipping option
      selectShippingCart("cc");
      //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
      verifyCart("PureVision Multi-Focal","PatientFirst PatientLast","69.99","139.98","139.98","279.96");
    //click continue
    clickCart_Continue();

    //Enter Address Information
    //names
    typeShippingName("shipfirst", "shiplast");
    //country
      clickCountry("CANADA");
      //address
      typeShippingAddress();
      typeIntShippingZip("K1A 0G9");
      //city
      typeShippingCity("Ottawa");
      typeShippingState("O");
    //phone
    typeIntShippingPhone();
    typeShippingEmail("test",testNumber);
    typePassword_newcust("password");
    clickNewAddress_Continue();

    //Find then select Doctor by name and state
   // typeDoctorSearch("test");
   // typeDoctorStateAndFind("Utah");
   // selectDoctor();

    //Enter Billing
    typeCreditCard("4012000077777777");
    typeCreditCardName("Blah");
    pickCreditCardExpDate("03","2015");

    //submit
    clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage("Canada Standard");
    //Close the browser
    driver.quit();
  }
}
