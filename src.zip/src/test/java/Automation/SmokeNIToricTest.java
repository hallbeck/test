package Automation;

import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeNIToricTest extends TestBase {


    //change the Strings below to change the tests
    String testNumber = "44029";
    String typeOfTest = "SMOKE";
    String typeOfCust = "NI";
    String typeOfPayment = "Credit";
    String searchAllBrand = "toric";
    String brandToClickOn = "VertexToricXR";
    String brandVerifyPDP = "Vertex Toric XR";
    String rPower = "++";
    String lPower = "+++";
    String rPowerDesktop = "0.25";
    String lPowerDesktop = "0.75";
    String rBC = "8";
    String lBC = "8";
    String rDia = "11";
    String lDia = "11";
    String rAdd;
    String lAdd;
    String rCyl = "--";
    String lCyl = "--";
    String rAxis = "111";
    String lAxis = "11";
    String PatientFNameCart = "PatientFirst";
    String PatientLNameCart = "PatientLast";
    String ShippingCart = "ss";
    //String FullPatientName = (PatientFNameCart + " " + PatientLNameCart);
    String pricePerBox = "107.99";
    String priceREye = "431.96";
    String priceLEye = "431.96";
    String priceTotal = "863.92";
    String rsTotal = "923.10";
    String rsTotalAfterRebate = "";
    String rsTax = "14.79";
    String rsRebate = "";
    String rsShipping = "FREE" ;
    String shippingFName = "ShipFirst";
    String shippingLName = "ShipLast";
    String country = "united states";
    String state = "utah";
    String city = "slc";
    String zip = "84121";
    String emailPrefix = "test";
    String password = "password";
    String drName = "test";
    String drState = "UT";
    String creditCard = "4012000077777777";
    String ccName = "Blah";
    String ccExpMo = "03";
    String ccExpYear = "2014";
    String shippingVerify = "Expedited";
    String printTestName = typeOfTest + " | " + testNumber + " | " + typeOfCust + " | " + searchAllBrand + " | " + typeOfPayment + " | " + shippingVerify;
    String screenshotTestName =  testNumber + "_" + typeOfTest + "_" + typeOfCust + "_" + searchAllBrand + "_" + typeOfPayment + "_" + shippingVerify;


    @Test (singleThreaded = true)
    public void phoneTest() {
        openWebPage(mobileURL);
        takeScreenshot(screenshotTestName, "Interstitial");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        takeScreenshot(screenshotTestName, "SearchBrand");
        //click on brand
        clickPhoneBrand(brandToClickOn);
        takeScreenshot(screenshotTestName, "PDP1");
        //Product Detail page Enter Power
        clickRPower(rPower);
        clickLPower(lPower);
        clickRCyl(rCyl);
        clickLCyl(lCyl);
        clickRAxis(rAxis);
        clickLAxis(lAxis);
        //enter patient name first then last
        typePatientName(PatientFNameCart, PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP2");
        //Add to cart
        clickAddToCart();
        //cart page
        selectShippingCart(ShippingCart);
        //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName, shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
        clickNewAddress_Continue();
        //Find then select Doctor by name and state
        typeDoctorSearch(drName);
        typeDoctorStateAndFind(drState);
        takeScreenshot(screenshotTestName, "DoctorSearch");
        selectDoctor();
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo,ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        //submit
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
    @Test (singleThreaded = true)
    public void desktopTest() {
        openWebPage(desktopBaseUrl);
        takeScreenshot(screenshotTestName, "HomePage");
        printTestNumber(printTestName);
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        takeScreenshot(screenshotTestName, "SearchBrand");
        //click on brand
        clickPhoneBrand(brandToClickOn);
        takeScreenshot(screenshotTestName, "PDP1");
        //Product Detail page Enter Power
        clickRPower(rPowerDesktop);
        clickLPower(lPowerDesktop);
        clickRCyl(rCyl);
        clickLCyl(lCyl);
        clickRAxis(rAxis);
        clickLAxis(lAxis);
        //enter patient name first then last
        typePatientName(PatientFNameCart, PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP2");
        //Add to cart
        clickAddToCart();
        //cart page
        selectShippingCart(ShippingCart);
        //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName, shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
        clickNewAddress_Continue();
        //Find then select Doctor by name and state
        typeDoctorSearch(drName);
        typeDoctorStateAndFind(drState);
        takeScreenshot(screenshotTestName, "DoctorSearch");
        selectDoctor();
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo,ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        //submit
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        driver.quit();
    }
    @Test (singleThreaded = true)
    public void tabletTest() {
        openWebPage(tabletURL);
        takeScreenshot(screenshotTestName, "Interstitial");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        takeScreenshot(screenshotTestName, "SearchBrand");
        //click on brand
        clickPhoneBrand(brandToClickOn);
        takeScreenshot(screenshotTestName, "PDP1");
        //Product Detail page Enter Power
        clickRPower(rPower);
        clickLPower(lPower);
        clickRCyl(rCyl);
        clickLCyl(lCyl);
        clickRAxis(rAxis);
        clickLAxis(lAxis);
        //enter patient name first then last
        typePatientName(PatientFNameCart, PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP2");
        //Add to cart
        clickAddToCart();
        //cart page
        selectShippingCart(ShippingCart);
        //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName, shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
        clickNewAddress_Continue();
        //Find then select Doctor by name and state
        typeDoctorSearch(drName);
        typeDoctorStateAndFind(drState);
        takeScreenshot(screenshotTestName, "DoctorSearch");
        selectDoctor();
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo,ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        //submit
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
}