package TabletAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRI1EyeAsphericPlusColorTest extends TestBase {


    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphone"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void tabletTest(String ffprofile) {
      openWebPage(tabletDevice);
      printTestNumber("SMOKE 44053 RI 1 Eye Only Astigmatism + new color order, Expired CC");
      //Go Directly to Sign In Page this is a fudge.
      goToSignInPage();
      // Login as returning customer

      typeReturningPhoneEmail("test_1366231393738@invalid.com");
      typeReturningPhonePassword("password");

      clickSignIn();
      clickAddRx();
      clickPhoneBrand("FreshLookColorblends");
      //Product Detail page Enter Power
      clickRPower("---");
      clickLPower("--");
      //color
      clickRColor("A");
      clickLColor("B");


      //number of boxes  6 months = 4 boxes total
      clickRboxes("1");
      clickLboxes("3");


      //enter patient name first then last
      typePatientName("SecondPFirst", "SecondPLast");

      //Add to cart
      clickAddToCart();

      //cart page
      //click continue
      clickCart_Continue();
      selectDoctor();

      //Enter Billing
      typeCreditCard("4012000077777777");
      typeCreditCardName("Blah");
      pickCreditCardExpDate("02","2013");

      //submit
      clickBottomSubmitButton();
      //exp card error
      verifyExpiredCard();
      //change exp date and resubmit
      pickCreditCardExpDate("02","2016");
      clickBottomSubmitButton();
      //ThankYou
      verifyThankYouPage();
      //Close the browser
      driver.quit();
  }
}
