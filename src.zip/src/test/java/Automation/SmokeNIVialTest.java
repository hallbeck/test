package Automation;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeNIVialTest extends TestBase {

//    @DataProvider
//    static Object[][] ffprofile() {
 //       return new Object[][]{
 //               {
//                        "iphoneP"
 //               },
 //       };
 //   }
    //change the Strings below to change the tests
    String testNumber = "44032";
    String typeOfTest = "SMOKE";
    String typeOfCust = "NI";
    String typeOfPayment = "Credit";
    String searchAllBrand = "vial";
    String brandToClickOn = "SoftconEW";
    String brandVerifyPDP = "Softcon EW";
    String rPower = "++++++++++++++++++";
    String lPower = "++++++++++++++";
    String rPowerDesktop = "0.25";
    String lPowerDesktop = "0.75";
    String rBC = "8";
    String lBC = "8";
    String rDia = "11";
    String lDia = "11";
    String rAdd;
    String lAdd;
    String rCyl;
    String lCyl;
    String PatientFNameCart = "PatientFirst";
    String PatientLNameCart = "PatientLast";
    String ShippingCart = "nn";
    //String FullPatientName = (PatientFNameCart + " " + PatientLNameCart);
    String pricePerBox = "59.99";
    String priceREye = "119.98";
    String priceLEye = "119.98";
    String priceTotal = "264.95";
    String rsTotal = "281.39";
    String rsTotalAfterRebate = "";
    String rsTax = "16.44";
    String rsRebate = "";
    String rsShipping = "24.99" ;
    String shippingFName = "ShipFirst";
    String shippingLName = "ShipLast";
    String country = "united states";
    String state = "utah";
    String city = "slc";
    String zip = "84121";
    String emailPrefix = "test";
    String password = "password";
    String drName = "test";
    String drState = "UT";
    String creditCard = "4012000077777777";
    String ccName = "Blah";
    String ccExpMo = "03";
    String ccExpYear = "2014";
    String shippingVerify = "Noon";
    String printTestName = typeOfTest + " | " + testNumber + " | " + typeOfCust + " | " + searchAllBrand + " | " + typeOfPayment + " | " + shippingVerify;
    String screenshotTestName =  testNumber + "_" + typeOfTest + "_" + typeOfCust + "_" + searchAllBrand + "_" + typeOfPayment + "_" + shippingVerify;


    @Test (singleThreaded = true)
  public void phoneTest() {
      openWebPage(mobileURL);
        takeScreenshot(screenshotTestName, "Interstitial");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        takeScreenshot(screenshotTestName, "SearchBrand");
        //click on brand
        clickPhoneBrand(brandToClickOn);
        takeScreenshot(screenshotTestName, "PDP1");
    //Product Detail page
      verifyPDP(brandVerifyPDP);
    clickRPower(rPower);
    clickLPower(lPower);
      clickRBC(rBC);
      clickLBC(lBC);
      clickRDia(rDia);
      clickLDia(lDia);
      //enter patient name first then last
    typePatientName(PatientFNameCart,PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP2");
    //Add to cart
    clickAddToCart();
      //change shipping option
      selectShippingCart(ShippingCart);
    //cart page
        takeScreenshot(screenshotTestName, "Cart");
      verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
    //click continue
    clickCart_Continue();
    //Enter Address Information
    typeShippingName(shippingFName,shippingLName);
    clickCountry(country);
    typeShippingAddress();
    typeShippingCity(city);
    typeShippingState(state);
    typeShippingZip(zip);
    typeShippingPhone();
    typeShippingEmail(emailPrefix,testNumber);
    typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
    clickNewAddress_Continue();
    //Find then select Doctor by name and state
    typeDoctorSearch(drName);
    typeDoctorStateAndFind(drState);
        takeScreenshot(screenshotTestName, "DoctorSearch");
    selectDoctor();
    //Enter Billing
    typeCreditCard(creditCard);
    typeCreditCardName(ccName);
    pickCreditCardExpDate(ccExpMo, ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
    //submit
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage(shippingVerify);
      takeScreenshot(screenshotTestName, "ThankYou");
    //Close the browser
    driver.quit();
  }
    @Test (singleThreaded = true)
    public void desktopTest() {
        openWebPage(desktopBaseUrl);
        takeScreenshot(screenshotTestName, "HomePage");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        takeScreenshot(screenshotTestName, "SearchBrand");
        //click on brand
        clickPhoneBrand(brandToClickOn);
        takeScreenshot(screenshotTestName, "PDP1");
        //Product Detail page
        verifyPDP(brandVerifyPDP);
        clickRPower(rPowerDesktop);
        clickLPower(lPowerDesktop);
        clickRBC(rBC);
        clickLBC(lBC);
        clickRDia(rDia);
        clickLDia(lDia);
        //enter patient name first then last
        typePatientName(PatientFNameCart,PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP2");
        //Add to cart
        clickAddToCart();
        //cart page
        selectShippingCart(ShippingCart);
        //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName,shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
        clickNewAddress_Continue();
        //Find then select Doctor by name and state
        typeDoctorSearch(drName);
        typeDoctorStateAndFind(drState);
        takeScreenshot(screenshotTestName, "DoctorSearch");
        selectDoctor();
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo, ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        //submit
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
    @Test (singleThreaded = true)
    public void tabletTest() {
        openWebPage(tabletURL);
        takeScreenshot(screenshotTestName, "Interstitial");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        takeScreenshot(screenshotTestName, "SearchBrand");
        //click on brand
        clickPhoneBrand(brandToClickOn);
        takeScreenshot(screenshotTestName, "PDP1");
        //Product Detail page
        verifyPDP(brandVerifyPDP);
        clickRPower(rPower);
        clickLPower(lPower);
        clickRBC(rBC);
        clickLBC(lBC);
        clickRDia(rDia);
        clickLDia(lDia);
        //enter patient name first then last
        typePatientName(PatientFNameCart,PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP2");
        //Add to cart
        clickAddToCart();
        //cart page
        selectShippingCart(ShippingCart);
        //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName,shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
        clickNewAddress_Continue();
        //Find then select Doctor by name and state
        typeDoctorSearch(drName);
        typeDoctorStateAndFind(drState);
        takeScreenshot(screenshotTestName, "DoctorSearch");
        selectDoctor();
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo, ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        //submit
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
}
