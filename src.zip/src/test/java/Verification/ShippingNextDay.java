package Verification;

import Automation.TestBase;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class ShippingNextDay extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

    //change the Strings below to change the tests
    String testNumber = "44042";
    String typeOfTest = "VERIFICATION";
    String typeOfCust = "NI";
    String typeOfPayment = "Credit";
    String searchAllBrand = "color";
    String searchAllBrand2 = "Toric";
    String brandToClickOn = "FreshLookColors";
    String brandToClickOn2 = "VertexToricXR";
    String brandVerifyPDP = "FreshLook Colors";
    String brandVerifyPDP2 = "Vertex Toric XR";
    String rPower = "--";
    String lPower = "--";
    String rPower2 = "++";
    String lPower2 = "+++";
    String rPowerDesktop = "0.25";
    String lPowerDesktop = "0.75";
    String rPowerDesktop2 = "0.25";
    String lPowerDesktop2 = "0.75";
    String rBC = "8";
    String lBC = "8";
    String rBC2 = "8";
    String lBC2 = "8";
    String rDia = "11";
    String lDia = "11";
    String rDia2 = "11";
    String lDia2 = "11";
    String rColor = "V";
    String lColor = "B";
    String rColor2 = "11";
    String lColor2 = "11";
    String rAdd;
    String lAdd;
    String rAdd2;
    String lAdd2;
    String rCyl = "";
    String lCyl = "";
    String rCyl2 = "--";
    String lCyl2 = "--";
    String rAxis = "";
    String rAxis2 = "111";
    String lAxis = "";
    String lAxis2 = "11";
    String rBoxes = "1";
    String rBoxes2 = "1";
    String lBoxes = "3";
    String lBoxes2 = "1";
    String PatientFNameCart = "FirstPaFirst";
    String PatientLNameCart = "FirstPaLast";
    String PatientFNameCart2 = "SecondPaFirst";
    String PatientLNameCart2 = "SecondPaLast";
    String ShippingCart = "n";
    //String FullPatientName = (PatientFNameCart + " " + PatientLNameCart);
    String pricePerBox = "49.99";
    String priceREye = "49.99";
    String priceLEye = "149.97";
    String pricePerBox2 = "49.99";
    String priceREye2 = "49.99";
    String priceLEye2 = "149.97";
    String priceTotal = "415.94";
    String shippingFName = "ShipFirst";
    String shippingLName = "ShipLast";
    String country = "united states";
    String state = "utah";
    String city = "slc";
    String zip = "84121";
    String emailPrefix = "test";
    String password = "password";
    String drName = "test";
    String drState = "UT";
    String creditCard = "4012000077777777";
    String ccName = "Blah";
    String ccExpMo = "03";
    String ccExpYear = "2014";
    String shippingVerify = "Next";
    String printTestName = typeOfTest + " | " + testNumber + " | " + typeOfCust + " | " + searchAllBrand + " | " + typeOfPayment + " | " + shippingVerify;
    String screenshotTestName =  testNumber + "_" + typeOfTest + "_" + typeOfCust + "_" + searchAllBrand + "_" + typeOfPayment + "_" + shippingVerify;


    @Test (singleThreaded = true)
  public void phoneTest() {
        openWebPage(mobileURL);
        takeScreenshot(screenshotTestName, "Interstitial");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        takeScreenshot(screenshotTestName, "SearchBrand");
        //click on brand
        clickPhoneBrand(brandToClickOn);
        takeScreenshot(screenshotTestName, "PDP1");
        //Product Detail page
        verifyPDP(brandVerifyPDP);
        clickRPower(rPower);
        clickLPower(lPower);
        clickRColor(rColor);
        clickLColor(lColor);
        clickRboxes(rBoxes);
        clickLboxes(lBoxes);
        //enter patient name first then last
        typePatientName(PatientFNameCart,PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP2");
        //click Add Rx
        clickAddRx();
        //search for lenses
        searchAllBrand(searchAllBrand2);
        //click on brand
        clickPhoneBrand(brandToClickOn2);
        verifyPDP(brandVerifyPDP2);
        clickRPower(rPower2);
        clickLPower(lPower2);
        clickRCyl(rCyl2);
        clickLCyl(lCyl2);
        clickRAxis(rAxis2);
        clickLAxis(lAxis2);
        //enter patient name first then last
        typePatientName(PatientFNameCart2,PatientLNameCart2);
        takeScreenshot(screenshotTestName, "PDP3");
       //Add to cart
        clickAddToCart();
        //cart page
        //change shipping option
        selectShippingCart(ShippingCart);
        //cart page
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName,shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
        clickNewAddress_Continue();
        //Find then select Doctor by name and state
        typeDoctorSearch(drName);
        typeDoctorStateAndFind(drState);
        takeScreenshot(screenshotTestName, "DoctorSearch");
        selectDoctor();
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo, ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        //submit
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
    @Test (singleThreaded = true)
    public void desktopTest() {
        openWebPage(desktopBaseUrl);
        takeScreenshot(screenshotTestName, "HomePage");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        takeScreenshot(screenshotTestName, "SearchBrand");
        //click on brand
        clickPhoneBrand(brandToClickOn);
        takeScreenshot(screenshotTestName, "PDP1");
        //Product Detail page
        verifyPDP(brandVerifyPDP);
        clickRPower(rPowerDesktop);
        clickLPower(lPowerDesktop);
        clickRColor(rColor);
        clickLColor(lColor);
        clickRboxes(rBoxes);
        clickLboxes(lBoxes);
        //enter patient name first then last
        typePatientName(PatientFNameCart,PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP2");
        //click Add Rx
        clickAddRx();
        //search for lenses
        searchAllBrand(searchAllBrand2);
        //click on brand
        clickPhoneBrand(brandToClickOn2);
        verifyPDP(brandVerifyPDP2);
        clickRPower(rPowerDesktop2);
        clickLPower(lPowerDesktop2);
        clickRCyl(rCyl2);
        clickLCyl(lCyl2);
        clickRAxis(rAxis2);
        clickLAxis(lAxis2);
        clickRboxes(rBoxes2);
        clickLboxes(lBoxes2);
        //enter patient name first then last
        typePatientName(PatientFNameCart2,PatientLNameCart2);
        takeScreenshot(screenshotTestName, "PDP3");
        //Add to cart
        clickAddToCart();
        //cart page
        //change shipping option
        selectShippingCart(ShippingCart);
        //cart page
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName,shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
        clickNewAddress_Continue();
        //Find then select Doctor by name and state
        typeDoctorSearch(drName);
        typeDoctorStateAndFind(drState);
        takeScreenshot(screenshotTestName, "DoctorSearch");
        selectDoctor();
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo, ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit");

        //submit
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
    @Test (singleThreaded = true)
    public void tabletTest() {
        openWebPage(tabletURL);
        takeScreenshot(screenshotTestName, "Interstitial");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        takeScreenshot(screenshotTestName, "SearchBrand");
        //click on brand
        clickPhoneBrand(brandToClickOn);
        takeScreenshot(screenshotTestName, "PDP1");
        //Product Detail page
        verifyPDP(brandVerifyPDP);
        clickRPower(rPower);
        clickLPower(lPower);
        clickRColor(rColor);
        clickLColor(lColor);
        clickRboxes(rBoxes);
        clickLboxes(lBoxes);
        //enter patient name first then last
        typePatientName(PatientFNameCart,PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP2");
        //click Add Rx
        clickAddRx();
        //search for lenses
        searchAllBrand(searchAllBrand2);
        //click on brand
        clickPhoneBrand(brandToClickOn2);
        verifyPDP(brandVerifyPDP2);
        clickRPower(rPowerDesktop2);
        clickLPower(lPowerDesktop2);
        clickRCyl(rCyl2);
        clickLCyl(lCyl2);
        clickRAxis(rAxis2);
        clickLAxis(lAxis2);
        clickRboxes(rBoxes2);
        clickLboxes(lBoxes2);
        //enter patient name first then last
        typePatientName(PatientFNameCart2,PatientLNameCart2);
        takeScreenshot(screenshotTestName, "PDP3");
        //Add to cart
        clickAddToCart();
        //cart page
        //change shipping option
        selectShippingCart(ShippingCart);
        //cart page
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName,shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
        clickNewAddress_Continue();
        //Find then select Doctor by name and state
        typeDoctorSearch(drName);
        typeDoctorStateAndFind(drState);
        takeScreenshot(screenshotTestName, "DoctorSearch");
        selectDoctor();
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo, ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit");

        //submit
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
}
