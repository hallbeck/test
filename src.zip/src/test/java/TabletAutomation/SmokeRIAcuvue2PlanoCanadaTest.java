package TabletAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRIAcuvue2PlanoCanadaTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

    @Test(dataProvider = "ffprofile", singleThreaded = true)
    public void tabletTest(String ffprofile) {

        openWebPage(tabletDevice);
        printTestNumber("SMOKE 44052 NI Acuvue2 Color Plano Canada CC");

        // DOES NOT WORK
        // clickReorderPhoneMainPage();
        //Go Directly to Sign In Page this is a fudge.
        goToSignInPage();
        // Login as returning customer

        typeReturningPhoneEmail("test_1366230440984@invalid.com");
        typeReturningPhonePassword("password");

        clickSignIn();
        clickCartEdit();
        //Product Detail page Enter Power
        //mobile
        clickLPower("----");


        //number of boxes  6 months = 4 boxes total
        clickRboxes("3");
        clickLboxes("1");

        //enter patient name first then last
        typePatientName("PatientFirst", "PatientLast");

        //Add to cart
        clickUpdateCart();

        //cart page
        //click continue
        clickCart_Continue();

        //submit
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage();
        //Close the browser
        driver.quit();
    }
}
