package TabletAutomation;

import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRIProgressiveInternationalTest extends TestBase {

    String testNumber = "44049";
    String testNumberDependentOn = "44035";
    String typeOfTest = "SMOKE";
    String typeOfCust = "RI";
    String typeOfPayment = "Credit";
    String searchAllBrand = "vial";
    String brandToClickOn = "VertexToricXR";
    String brandVerifyPDP = "Vertex Toric XR";
    String rPower = "++++++++++++++++++";
    String lPower = "++++++++++++++";
    String rPowerDesktop = "0.50";
    String lPowerDesktop = "1.75";
    String rBC = "8";
    String lBC = "8";
    String rDia = "1";
    String lDia = "1";
    String rBoxes = "1";
    String rBoxes2 = "3";
    String lBoxes = "1";
    String lBoxes2 = "2";
    String rAdd;
    String lAdd;
    String rCyl;
    String lCyl;
    String PatientFNameCart = "PatFirstNew";
    String PatientLNameCart = "PatientLast";
    String ShippingCart = "nn";
    //String FullPatientName = (PatientFNameCart + " " + PatientLNameCart);
    String pricePerBox = "107.99";
    String priceREye = "431.96";
    String priceLEye = "431.96";
    String priceTotal = "863.92";
    String shippingFName = "ShipFirst";
    String shippingLName = "ShipLast";
    String country = "united states";
    String state = "utah";
    String city = "slc";
    String zip = "84121";
    String emailPrefix = "test";
    String emailToUse = "test_1367264308184@invalid.com";
    String password = "password";
    String drName = "test";
    String drState = "UT";
    String creditCard = "4012000077777777";
    String ccName = "Blah";
    String ccExpMo = "03";
    String ccExpYear = "2014";
    String shippingVerify = "Expedited";
    String printTestName = typeOfTest + " | " + testNumber + " | " + typeOfCust + " | " + searchAllBrand + " | " + typeOfPayment + " | " + shippingVerify;
    String screenshotTestName =  testNumber + "_" + typeOfTest + "_" + typeOfCust + "_" + searchAllBrand + "_" + typeOfPayment + "_" + shippingVerify;


  @Test(singleThreaded = true)
  public void tabletTest() {
      openWebPage(tabletDevice);


      // click on New to 1800contacts Find your brand
      printTestNumber("SMOKE 44049 RI Progressive International New Patient CC");

      //Go Directly to Sign In Page this is a fudge.
      goToSignInPage();
      // Login as returning customer

      typeReturningPhoneEmail("test_1366137271618@invalid.com");
      typeReturningPhonePassword("password");

      clickSignIn();
      clickCartEdit();
      //Product Detail page Enter Power
      //mobile
      clickRPower("---");
      clickLPower("--");


      //number of boxes  6 months = 4 boxes total
      clickRboxes("5");
      clickLboxes("2");


      //enter patient name first then last
      typePatientName("PatientFirstnew", "PatientLast");

      //Add to cart
      clickUpdateCart();

      //cart page
      //click continue
      clickCart_Continue();

      //submit
      clickBottomSubmitButton();
      //ThankYou
      verifyThankYouPage();
      //Close the browser
      driver.quit();
  }
}
