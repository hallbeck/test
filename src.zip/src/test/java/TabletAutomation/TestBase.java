package TabletAutomation;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.Select;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Date;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:23 PM
 * To change this template use File | Settings | File Templates.
 */


public class TestBase{
    //change this to whatever browser you want to test on
    String browser = "firefox"; //choices are ie,firefox,chrome,safari         -- SAFARI DOES NOT SELECT RX VALUES WELL. DO NOT USE
    //change this for ff browser only
    String deviceProfile = "ipadP";   //choices are ipadP, ipadL, kindleFireL, kindleFireP - this is for firefox profiles only

    String desktop = "https://www.1800contactstest.com";
    String desktopBaseUrl = desktop;
    String mobileDevice = "https://www.1800contactstest.com/?responsive=yes";
    String mobileBaseUrl = mobileDevice;
    String tabletDevice = "https://www.1800contactstest.com/?responsive=yes";
    String tabletBaseUrl = tabletDevice;



    //profiles locations are stored in C:\Users\<user>\AppData\Roaming\Mozilla\Firefox
    //change this file to point to your personal profiles


    ChromeOptions options = new ChromeOptions();
    DesiredCapabilities capabilities = DesiredCapabilities.chrome();
    //capabilities.setCapability("chrome.switches", "--ignore-certificate-errors");

    String fileName = ("TestOut" + new Date().getTime());
    WebDriver driver = makeDriver(browser,deviceProfile);
    public static WebDriver makeDriver(String browser, String deviceProfile) {
        ProfilesIni allProfiles = new ProfilesIni();
        FirefoxProfile profile = allProfiles.getProfile(deviceProfile);
        WebDriver driver = null;
        if (browser.equals("ie")) {
            driver = new InternetExplorerDriver();
        } else if (browser.equals("firefox")) {
            driver = new FirefoxDriver(profile);
        } else if (browser.equals("chrome")) {
            driver = new ChromeDriver();
        } else if (browser.equals("safari")) {
            driver = new SafariDriver();
        }
        return driver;
    }

    public void openWebPage(String device) {
        //driver.get(device);
        driver.get("https://www.google.com");
        Wait(2);
        setCookie();
        Wait(5);
        driver.get(device);
    }
    public void setCookie(){
        //String key = "fsr.r";
        //String value = "{\"d\":90,\"i\":\"\",\"e\":};expires=Tue,20 Sep 2017 15:23:48 GMT; path=/;";
        //String domain = ".1800contactstest.com";
        String key = "fsr.s";
        //{"v":-1,"rid":"1366734711827_458379","to":2.4,"c":"https://www.1800contactstest.com","pv":4,"lc":{"d0":{"v":4,"s":true}},"cd":0,"sd":0,"cp":{"s_prop2":"NI","s_eVar29\":"Control"},"f":1366734744426,"i":-1,"l":"en"}
        String value = "{\"v\":-2,\"rid\":\"1366734711827_458379\",\"to\":2.4,\"c\":\"/\",\"pv\":4,\"lc\":{\"d90\":{\"v\":4,\"s\":true}},\"cd\":90,\"sd\":90,\"cp\":{\"s_prop2\":\"NI\",\"s_eVar29\\\":\"Control\"},\"f\":1366734744426,\"l\":\"en\",\"i\":-1}";
        String domain = "";
        Cookie cookie = new Cookie.Builder(key, value).domain(domain).path(
                "/").build();
        driver.manage().addCookie(cookie);
        Set<Cookie> allCookies = driver.manage().getCookies();
        for (Cookie loadedCookie : allCookies) {
            System.out.println(String.format("%s -> %s", loadedCookie.getName(), loadedCookie.getValue()));
        }
    }
    public void printToFile(){
        try {
            PrintStream ps = System.out;
            System.setOut(new PrintStream(new FileOutputStream(fileName + ".txt")));
            System.out.println("foo");
            ps.println("bar");
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }


  static {
      //WebDriver driver = new FirefoxDriver();
    //profile.setPreference("general.useragent.override", userAgent);
  }
    public void printPageTitle() {
        System.out.println("Page title is: " + driver.getTitle());
        Wait(2);
  }
    public void printText(String text) {
        System.out.println(text);
        Wait(2);
    }
    public void printTestNumber(String test) {
        System.out.println("Test Covered is: " + test + " " + deviceProfile);
        System.out.println(test);
    }

  public static void Wait(long seconds) {
    try {
      Thread.sleep(seconds * 1000);
      System.out.println("Waiting");
    } catch (Exception e) {
      System.out.println("Sleep exception...its a nightmare");
    }
  }


    public void clickNoThanksButton() {
        printPageTitle();
        Wait(4);
        driver.findElement(By.xpath("//img[contains(@alt,'No Thanks')]")).click();
        System.out.println("Clicked No Thanks");
        Wait(4);
    }
  public void clickMainPage_NewButton() {
      printPageTitle();
      driver.findElement(By.xpath("//a[contains(@id,'NewCustomerStartLink')]")).click();
      System.out.println("Clicked on New customer button");
    Wait(4);
  }

    //reorder checkboxes this uses tabs to click each. two tabs, click tab click
    public void checkReorderCheckboxOne(){
        //go to dashboard cause I can't use lightbox
        driver.get(desktopBaseUrl + "/accounthub");
        Wait(2);
        WebElement eleMyAccount = driver.findElement(By.xpath("//div[contains(@class,'rxSummaryLineItemColumn memberRecentPrescription')]"));
        eleMyAccount.click();
        System.out.println("Clicked on header or something I think");
        Wait(2);
        //tab five times then space
        System.out.println("sending tabs");
        eleMyAccount.sendKeys(Keys.chord(Keys.SHIFT, Keys.TAB),Keys.SPACE);
        Wait(2);
    }
    public void checkReorderCheckboxTwo(){
        driver.get(desktopBaseUrl + "/accounthub");
        Wait(2);
        WebElement eleMyAccount = driver.findElement(By.xpath("//div[contains(.,'Dashboard')]"));
        eleMyAccount.click();
        System.out.println("Clicked on header or something I think");
        Wait(2);
        //tab eleven times then space
        System.out.println("sending tabs");
        eleMyAccount.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.SPACE,Keys.TAB,Keys.SPACE);
        System.out.println("sent tabs");
        Wait(2);
    }

    //continue button from the reorder Lightbox
    public void clickContinueFromReorder(){
        System.out.println("clicking continue");
        driver.findElement(By.xpath("//input[contains(@src,'continue.png')]")).click();
    }
    public void clickReorderTheseRxButton(){
        driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-orangeButton rd-tabletRightButton')]")).click();
    }
    //This worked, then stopped working. Once the buttons and links are redone, uncomment clickFindBrand and rename
    //clickFindBrand to go to lens page cause that's what it does.
    public void clickFindBrand() {
        printPageTitle();
        Wait(4);
        // phone
        driver.findElement(By.xpath("//a[contains(@id,'tablet-find-brand')]")).click();
        //driver.findElement(By.linkText("How to Order")).click();
        System.out.println("Clicked on Find Your Brand footer button");
        Wait(4);
    }
    //This worked, then stopped working. Once the buttons and links are redone, uncomment clickFindBrand and rename
    //clickFindBrand to go to lens page cause that's what it does.
    public void clickTabletFindBrand() {
        printPageTitle();
        Wait(4);
        driver.findElement(By.xpath("//a[contains(@class,'FindBrand-footer-link')]")).click();
        //driver.findElement(By.xpath("//div[contains(.,'Find Your Brand')]")).click();
        //driver.findElement(By.linkText("How to Order")).click();
        System.out.println("Clicked on Find Your Brand footer link");
        Wait(4);
    }
    // DELETE when other fix in
   // public void clickFindBrand() {
   //     printPageTitle();
    //    Wait(2);
    //    driver.get(desktopBaseUrl + "/lenses");
    //    //driver.findElement(By.xpath("//div[contains(.,'Find Your Brand')]")).click();
    //    //driver.findElement(By.linkText("How to Order")).click();
    //    System.out.println("Went to the Product List directly");
    //    Wait(4);
   // }
    public void clickReorderPhoneMainPage() {
        printPageTitle();
        Wait(4);
        driver.findElement(By.xpath("//a[contains(@class,'Account-footer-link')]")).click();
        //driver.findElement(By.xpath("//div[contains(.,'Find Your Brand')]")).click();
        //driver.findElement(By.linkText("How to Order")).click();
        System.out.println("Clicked on My Account footer link");
        Wait(4);
    }
    public void clickPhoneMainPage_NewButton() {
        printPageTitle();
        Wait(4);
        WebElement weNewCust = driver.findElement(By.partialLinkText("New"));
        System.out.println("Found" + weNewCust);
        weNewCust.click();
        System.out.println("Clicked on New customer button");
        System.out.println("Clicked" + weNewCust);
        Wait(4);
    }
       //this worked at one time. use again once it works.
  //public void clickPhoneMainPage_NewButton_GOOD() {
   //   printPageTitle();
   //  WebElement weNewCust = driver.findElement(By.id("tablet-returning-customer"));
   //   weNewCust.click();
   //   System.out.println("Clicked on New customer button");
  //  Wait(4);
 // }
    public void goToSignInPage(){
        driver.get(desktopBaseUrl + "/signin.aspx");
    }
               //SignIn Email Lightbox       DOES NOT WORK with popup
       public void typeReturningPhoneEmail(String email) {
        printPageTitle();
        Wait(4);
           //WebElement findWindow = driver.findElement(By.xpath("//html[contains(@class,'a41-tier2 js no-flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths js no-flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths landscape')]"));
           //System.out.println(findWindow);
           //String windowText = findWindow.getAttribute("value");
           //String newWindowTitle = driver.getTitle();
           //System.out.println(newWindowTitle + windowText);
           //System.out.println("Found the lightbox yippee");
           //Wait(4);
           WebElement emailInput = driver.findElement(By.xpath("//input[(@id='ctl00_contentPlaceHolderContent_SignIn1_tbEmail_tbEmail')]"));
           emailInput.click();
           emailInput.clear();
           System.out.println("clicked and cleared");
           emailInput.sendKeys(email);
        System.out.println("Email used is: " + email);
    }
    //SignIn password Lightbox       DOES NOT WORK on popup
    public void typeReturningPhonePassword(String password) {
        Wait(4);
        WebElement passwordInput = driver.findElement(By.xpath("//input[(@id='ctl00_contentPlaceHolderContent_SignIn1_tbReturningCustomerPassword_tbPass')]"));
        passwordInput.click();
        passwordInput.clear();
        passwordInput.sendKeys(password);
        //driver.findElement(By.xpath("//input[(@id='signInLightBoxPassword')]")).clear();
        //driver.findElement(By.xpath("//input[(@id='signInLightBoxPassword')]")).click();
        //driver.findElement(By.xpath("//input[(@id='signInLightBoxPassword')]")).sendKeys(password);
        System.out.println("Password used is: " + password);
    }

    public void clickSignIn() {
        printPageTitle();
        driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletRightButton rd-orangeButton')]")).click();
        System.out.println("Clicked Sign In");
        Wait(6);
    }

     //this is not working because it is not finding the search button. it has no link associated, just js. SO...
    //once it starts working uncomment searchAllBrand and rename the used searchAllBrand to Go to all Lenses
    public void searchAllBrand(String search) {
        Wait(4);
        System.out.println("Click Search ");
        driver.findElement(By.xpath("//input[contains(@name,'searchTerm')]")).click();
        driver.findElement(By.xpath("//input[contains(@name,'searchTerm')]")).sendKeys(search, Keys.ENTER);
        System.out.println("Searched for brand: " + search);
        //driver.findElement(By.xpath("//button[contains(@type,'submit')]")).click();
                //sendKeys(Keys.ENTER);
        Wait(7);
    }
     // DELETE when other fix in
   // public void searchAllBrand(String search) {
   //     Wait(4);
   //     driver.get(desktopBaseUrl + "/ProductList"");
        //driver.findElement(By.xpath("//div[contains(.,'Find Your Brand')]")).click();
        //driver.findElement(By.linkText("How to Order")).click();
    //    System.out.println("Went to the full Product List directly");
    //    Wait(5);
   // }
      //DOES NOT WORK
    //public void clickHero(String brand) {
    //    System.out.println("Clicked on brand: " + brand);
    //    Wait(2);
    //    printPageTitle();
    //    driver.findElement(By. xpath("//img[contains(@alt,'acuvue')]")).click();
        //String theString = "//img[contains(@alt,'" + brand + "')]";
        //driver.findElement(By.xpath(theString)).click();
     //   System.out.println("Clicked on brand: " + brand);
    //}
     //UNKNOWN if it works
    public void clickSeeAll() {
        driver.findElement(By.xpath("//div[contains(.,'See All')]")).click();
        System.out.println("Clicked See All");
    }
  public void clickBrand(String brand) {
    String theString = "//a[contains(@id,'BrandSelectButton_" + brand + "')]";
    driver.findElement(By.xpath(theString)).click();
      System.out.println("Clicked on brand: " + brand);
  }

    //when search works uncomment this and rename clickPhoneBrand to clickPhoneAllProductBrand
    public void clickPhoneBrand(String brand) {
      String theString = "//a[contains(@id,'" + brand + "')]";
      driver.findElement(By.xpath(theString)).click();
      System.out.println("Clicked on brand: " + brand);
      System.out.println(brand);
      Wait(6);
  }
    // DELETE when other fix in
   // public void clickPhoneBrand(String brand) {
    //    String theString = "//a[contains(@id,'Link-" + brand + "')]";
    //    System.out.println("Clicked on brand: " + theString);
    //    driver.findElement(By.xpath(theString)).click();
     //   System.out.println("Clicked on brand: " + brand);
    //    System.out.println(brand);
    //    Wait(6);
   // }
   //Power + starts at the top and works down so +++ will select 3 from the top of the list
    //- starts at the entry point and goes down.
   public void checkBoxLeftEye() {
       driver.findElement(By.xpath("//input[contains(@class,'LeftEyeCheckBox')]")).click();
   }

    public void checkBoxRightEye() {
        driver.findElement(By.xpath("//input[contains(@class,'RightEyeCheckBox')]")).click();
    }
  public void clickRPower(String power) {
    WebElement wePower = driver.findElement
            (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.SphericalPower')]"));
      wePower.click();
      System.out.println("Power for right eye: " + power);
      wePower.sendKeys(power,Keys.ENTER);
      Wait(1);
  }
    public void clickLPower(String power) {
        WebElement wePower = driver.findElement(By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.SphericalPower')]"));
        wePower.click();
        System.out.println("Power for left eye: " + power);
        wePower.sendKeys(power,Keys.ENTER);
        Wait(1);
    }

  public void clickRBC(String bc) {
    String thePickerString = "//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.BaseCurve')]";
      WebElement weBc = driver.findElement(By.xpath(thePickerString));
      weBc.click();
      System.out.println("BC for right eye: " + bc);
      weBc.sendKeys(bc,Keys.ENTER);
      Wait(1);
  }
    public void clickLBC(String bc) {
        String thePickerString = "//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.BaseCurve')]";
        WebElement weBc = driver.findElement(By.xpath(thePickerString));
        weBc.click();
        System.out.println("BC for left eye: " + bc);
        weBc.sendKeys(bc,Keys.ENTER);
        Wait(1);
    }
    public void clickRDia(String dia) {
        WebElement weDia = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.DiameterLength')]"));
        weDia.click();
        System.out.println("Dia for right eye: " + dia);
        weDia.sendKeys(dia,Keys.ENTER);
        Wait(1);
    }
    public void clickLDia(String dia) {
        WebElement weDia = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.DiameterLength')]"));
        weDia.click();
        System.out.println("Dia for left eye: " + dia);
        weDia.sendKeys(dia,Keys.ENTER);
        Wait(1);
    }

    public void clickRCyl(String cyl) {
        WebElement weCyl = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.CylinderPower')]"));
        weCyl.click();
        System.out.println("Cyl for right eye: " + cyl);
        weCyl.sendKeys(cyl,Keys.ENTER);
        Wait(1);
    }
    public void clickLCyl(String cyl) {
        WebElement weCyl = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.CylinderPower')]"));
        weCyl.click();
        System.out.println("Cyl for left eye: " + cyl);
        weCyl.sendKeys(cyl,Keys.ENTER);
        Wait(1);
    }
    public void clickRAxis(String axis) {
        WebElement weAxis = driver.findElement
                (By.xpath("//select[contains(@name,'PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.AxisDegree')]"));
        weAxis.click();
        System.out.println("Axis for right eye: " + axis);
        weAxis.sendKeys(axis,Keys.ENTER);
        Wait(1);
    }
    public void clickLAxis(String axis) {
        WebElement weAxis = driver.findElement
                (By.xpath("//select[contains(@name,'PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.AxisDegree')]"));
        weAxis.click();
        System.out.println("Axis for left eye: " + axis);
        weAxis.sendKeys(axis,Keys.ENTER);
        Wait(1);
    }
    public void clickRColor(String color) {
        WebElement weColor = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.ColorId')]"));
        weColor.click();
        weColor.sendKeys(color,Keys.ENTER);
        System.out.println("Color for right eye: " + color);
        Wait(1);

    }
    public void clickLColor(String color) {
        WebElement weColor = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.ColorId')]"));
        weColor.click();
        System.out.println("Color for left eye: " + color);
        weColor.sendKeys(color,Keys.ENTER);
        Wait(1);
    }
    public void clickRboxes(String box) {
        WebElement weBox = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.Quantity')]"));
        weBox.click();
        System.out.println("Boxes for right eye: " + box);
        weBox.sendKeys(box,Keys.ENTER);
        System.out.println(box + " boxes Right Eye");
        Wait(1);
    }
    public void clickLboxes(String box) {
        WebElement weBox = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.Quantity')]"));
        weBox.click();
        System.out.println("Boxes for left eye: " + box);
        weBox.sendKeys(box,Keys.ENTER);
        System.out.println(box + " boxes Left Eye");
        Wait(1);
    }

    public void clickRAdd(String add) {
        WebElement weAdd = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.AddPower')]"));
        weAdd.click();
        System.out.println("ADD for Right eye: " + add);
        weAdd.sendKeys(add,Keys.ENTER);
        Wait(1);
    }
    public void clickLAdd(String add) {
        WebElement weAdd = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.AddPower')]"));
        weAdd.click();
        System.out.println("ADD for left eye: " + add);
        weAdd.sendKeys(add,Keys.ENTER);
        Wait(1);
    }
  public void typePatientName(String first, String last) {
    WebElement firstPatientName = driver.findElement(By.xpath("//input[contains(@id,'firstNameInput')]"));
      firstPatientName.clear();
      firstPatientName.sendKeys(first);
      WebElement lastPatientName = driver.findElement(By.xpath("//input[contains(@id,'lastNameInput')]"));
      lastPatientName.clear();
      lastPatientName.sendKeys(last);
      System.out.println("Patient First Name is: " + first);
      System.out.println("Patient First Name is: " + last);
  }

  public void clickAddRx(){
      driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletLeftButton rd-grayButton')]")).click();
      System.out.println("Clicked Add an Rx");
      // works on phone. not on tablet. driver.findElement(By.xpath("//span[contains(.,'Add Another Rx')]")).click();
  }
    // when buttons get fixed, uncomment clickAddToCart and change the name of the one that was in use to pressSubmit
    public void clickUpdateCart() {
        printPageTitle();
        Wait(5);
        driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletRightButton rd-orangeButton')]")).click();
        System.out.println("Clicked Update");
        Wait(5);
    }
  public void clickAddToCart() {
      printPageTitle();
      Wait(5);
      driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletRightButton rd-orangeButton rd-addToCartButton')]")).click();
      System.out.println("Clicked Add To Cart");
      Wait(5);
  }
    public void clickCartEdit(){
        printPageTitle();
        //Edit link is tricky. there is no difference between the links if there are 2 +

        System.out.println("Next Edit the Cart");
        driver.findElement(By.xpath("//a[contains(@class,'a41-cart-edit-link')]")).click();
        System.out.println("Clicked Edit");
        Wait(5);
    }
    //change shipping method on the cart page
    //enter the letter to type
    // s = standard
    // n = next day mail. nn = next day noon.
    // c = canada, cc= can exp.
    // e = expedited,
    // i = international, ii= international exp.
    public void selectShippingCart(String ship) {
        WebElement weShipping = driver.findElement(By.xpath("//select[contains(@id,'SelectedShipperCode')]"));
        weShipping.click();
        System.out.println("Method of shipping: " + ship);
        weShipping.sendKeys(ship);
        Wait(1);
        driver.findElement(By.xpath("//label[contains(.,'Shipping')]")).click();
        Wait(4);
        //try ... driver.findElement(By.linkText("Edit"));
    }
    //change shipping method on the RS page DOES NOT WORK
    //enter the letter to type
    // MAIL = standard
    // USEM = next day mail. FED1 = next day noon.
    // c = canada, cc= can exp.
    // FED2 = expedited,
    // i = international, ii= international exp.
    public void selectShippingRS(String ship) {
        WebElement weShippingRS = driver.findElement(By.xpath("//a[contains(@class,'a41-edit-link popupTrigger')]"));;
        System.out.println("Found Edit");
        weShippingRS.click();
        System.out.println("Clicked on Edit");
        Wait(3);
        String theShippingString = "//input[contains(@id,'" + ship + "')]";
        driver.findElement(By.xpath("//input[contains(@id,'USEM')]")).click();
        driver.findElement(By.xpath(theShippingString)).click();
        System.out.println("Method of shipping: " + ship);
        driver.findElement(By.xpath("//span[contains(.,'Select')]")).click();
        Wait(4);
    }

    public void verifyCart(){
        System.out.println("Someday this will be for verifying Cart contents: ");

    }
  public void clickCart_Continue() {
      printPageTitle();
      Wait(4);
      System.out.println("Find Continue");
      WebElement weCartContinue = driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletRightButton rd-orangeButton rd-continueButton')]"));
      System.out.println("Click Continue");
      weCartContinue.click();
      Wait(10);
  }

  public void typeShippingName(String first, String last) {
      driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.FirstName')]")).clear();
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.FirstName')]")).sendKeys(first);
      System.out.println("Shipping First Name is: " + first);
      driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.LastName')]")).clear();
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.LastName')]")).sendKeys(last);
      System.out.println("Shipping Last Name is: " + last);
  }

  public void clickCountry(String country) {
    driver.findElement(By.xpath("//select[contains(@name,'ShippingAddress.Country')]")).click();
    //String theCountryString = "//option[contains(@value,'" + country + "')]";
      driver.findElement(By.xpath("//select[contains(@name,'ShippingAddress.Country')]")).sendKeys(country,Keys.ENTER);
      Wait(3);
      driver.findElement(By.xpath("//select[contains(@name,'ShippingAddress.Country')]")).sendKeys(country,Keys.ENTER);
      System.out.println("Country is: " + country);
      Wait(3);
  }

  public void typeShippingAddress() {
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.AddressLine1')]")).sendKeys("ship address " + new Date().getTime());
      System.out.println("Shipping Address is: ");
      Wait(3);
  }

  public void typeShippingCity(String city) {
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.City')]")).sendKeys(city);
      System.out.println("City is: " + city);
      Wait(3);
  }

  public void typeShippingState(String state) {
      driver.findElement(By.xpath("//select[contains(@id,'ShippingAddress_StateProvinceOrRegion')]")).sendKeys(state,Keys.ENTER);
      System.out.println("State is: " + state);
  }
    //not used
    public void typeIntShippingState(String state) {
        driver.findElement(By.xpath("//input[contains(@placeholder,'Region *')]")).sendKeys(state,Keys.ENTER);
        System.out.println("Region is: " + state);
        Wait(5);
    }

  public void typeShippingZip(String zip) {
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.ZipOrPostalCode')]")).sendKeys(zip);
      System.out.println("Zip is: " + zip);
  }

    public void typeIntShippingZip(String zip) {
        Wait(4);
        driver.findElement(By.xpath("//input[contains(@id,'ShippingAddress_ZipOrPostalCode')]")).sendKeys(zip);
        System.out.println("PostalCode is: " + zip);
    }

  public void typeShippingPhone() {
      String thePhoneString = "" + new Date().getTime();
      System.out.println("Phone used is: " + thePhoneString);
    driver.findElement(By.xpath("//input[contains(@name,'Phone')]")).sendKeys(thePhoneString);
      Wait(3);
  }
    public void typeIntShippingPhone() {
        String thePhoneString = "" + new Date().getTime();
        System.out.println("Phone used is: " + thePhoneString);
        driver.findElement(By.xpath("//input[contains(@id,'PhoneNumber')]")).clear();
        driver.findElement(By.xpath("//input[contains(@id,'PhoneNumber')]")).sendKeys(thePhoneString);
        Wait(3);
    }

  //email
  public void typeShippingEmail(String email) {
    String theEmailString = email + "_" + new Date().getTime() + "@invalid.com";
    driver.findElement(By.xpath("//input[contains(@name,'EmailAddress')]")).sendKeys(theEmailString);
    System.out.println("Email used is: " + theEmailString);
  }

  //password and confirm password
  public void typePassword_newcust(String password) {
    driver.findElement(By.xpath("//input[contains(@id,'a41-checkout-password')]")).sendKeys(password);
    driver.findElement(By.xpath("//input[contains(@id,'a41-checkout-confirm-password')]")).sendKeys(password);
      System.out.println("Password Entered: " + password);
  }

  public void clickNewAddress_Continue() {
    driver.findElement(By.xpath("//input[contains(@value,'continue')]")).click();
      System.out.println("Clicked Continue on New Address Page");
    Wait(3);
  }

  public void typeDoctorSearch(String doctor) {
    driver.findElement(By.xpath("//input[contains(@name,'DoctorSearchOptionsViewModel.DoctorOrClinic')]")).sendKeys(doctor);
      System.out.println("input dr name for search");
    Wait(2);
  }

  public void typeDoctorStateAndFind(String state) {
    new Select(driver.findElement(By.xpath("//select[contains(@id,'DoctorSearchOptionsViewModel_State')]"))).selectByVisibleText(state);
    Wait(2);
      driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletLeftButton rd-orangeButton  rd-searchButton')]")).click();
      System.out.println("searched for Doctor");
    Wait(2);
  }

  public void typeDoctorPhoneAndFind(String phone) {
    driver.findElement(By.xpath("//input[contains(@id,'a41-search-by-phone')]")).click();
    driver.findElement(By.xpath("//input[contains(@id,'PhoneNumber')]")).sendKeys(phone);
    Wait(2);
      driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletLeftButton rd-orangeButton')]")).click();
      System.out.println("searched for Doctor");
    Wait(2);
  }

  //select doctor  this will just take the first result
  public void selectDoctor() {
      driver.findElement(By.xpath("//a[contains(@id,'SelectDoctorButton2696254')]")).click();
      System.out.println("selected Doctor 2696254");
    Wait(6);
  }

  //review and submit page
  //enter credit card
  public void typeCreditCard(String cardNumber) {
      WebElement weCreditCardField = driver.findElement(By.xpath("//input[contains(@id,'CreditCardNumber')]"));
      Wait(2);
      weCreditCardField.clear();
      System.out.println("CC cleared: ");
      Wait(2);
      weCreditCardField.sendKeys(cardNumber);
      System.out.println("CC Used: " + cardNumber);
  }

  public void typeCreditCardName(String creditName) {
    driver.findElement(By.xpath("//input[contains(@id,'CreditCardName')]")).sendKeys(creditName);
      System.out.println("CC Name Used: " + creditName);
  }

  public void pickCreditCardExpDate(String month, String year) {
      driver.findElement(By.xpath("//select[contains(@id,'CreditCardExpirationMonth')]")).sendKeys(month);
      driver.findElement(By.xpath("//select[contains(@id,'CreditCardExpirationYear')]")).sendKeys(year);
      System.out.println("CC exp date:" + month + " " + year);
  }

  //Place My Order Bottom button
  public void clickBottomSubmitButton() {
      driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletRightButton rd-orangeButton')]")).click();
      System.out.println("Clicked the Place My Order button");
      Wait(30);
  }
    //Place My Order Top button
    public void clickTopSubmitButton() {
        driver.findElement(By.xpath("//div[contains(@class,'rd-button rd-tablet rd-tabletRightButton rd-orangeButton')]")).click();
        System.out.println("Clicked the Place My Order button");
        Wait(30);
    }

    //expired credit card

    public void verifyExpiredCard() {
        //driver.findElement(By.xpath("//img[contains(@src,'/Img/cc/PaymentWait.gif')]"));
        driver.findElement(By.xpath("//ul[contains(@id,'errorMessagesUl')]"));
        System.out.println("Got the Expired Card message");
        System.out.println("Next - Change exp date to be correct");
    }
  //Declined Credit Card error page
  public void verifyDeclinedCard() {
      driver.findElement(By.xpath("//img[contains(@src,'PaymentWait.gif')]"));
      System.out.println("CreditCard Error page");
  }
    public void goToCartURL() {
        System.out.println("Next Go To Cart by URL");
        driver.get(desktopBaseUrl + "/Cart");
        Wait(2);
        driver.findElement(By.xpath("//p[contains(.,'	Please review your cart	')]"));
        System.out.println("You are in the cart... proceed as normal");
        Wait(6);
    }
    //Go to cart 1 item
    public void goToCart1Item() {

        System.out.println("Next Go To Cart");
        //find the search box then back tab and enter (click) for cart
        driver.findElement(By.xpath("//img[contains(@src,'/Img/cc/PaymentWait.gif')]")).click();
        driver.findElement(By.xpath("//img[contains(@src,'/Img/cc/PaymentWait.gif')]")).sendKeys(Keys.chord(Keys.SHIFT,Keys.TAB),Keys.ENTER);
        Wait(2);
        driver.findElement(By.xpath("//p[contains(.,'	Please review your cart	')]"));
        System.out.println("You are in the cart... proceed as normal");
        Wait(6);
    }
    //Go to cart 1 item
    public void goToCart2Items() {
        System.out.println("Next Go To Cart");
        driver.findElement(By.xpath("//a[contains(.,'Cart')]")).click();
        Wait(2);
        driver.findElement(By.xpath("//p[contains(.,'	Please review your cart	')]"));
        System.out.println("You are in the cart... proceed as normal");
        Wait(6);
    }

  //ThankYou page
  public void verifyThankYouPage() {
      Wait(14);
    driver.findElement(By.xpath("//h1[contains(.,'Thank you for your order!')]"));
      System.out.println("Thank You page says Thank you for your order! ");
    driver.findElement(By.xpath("//p[contains(.,'A confirmation of this order has been sent to:')]"));
      System.out.println("A confirmation of this order has been sent to:");
    System.out.println("Page title is: " + driver.getTitle());
      String theOrderNumber = driver.findElement(By.xpath("//td[contains(@id,'orderNumber')]")).getText();
      System.out.println(theOrderNumber + ": Order Number");
  }
    public void verifyTxtPresent(String identifier, String desired, String actual){

        // the pattern we want to search for
        Pattern p = Pattern.compile(desired);
        Matcher m = p.matcher(actual);
        // just try to find a match
        if (m.find())
            System.out.println("VERIFIED " + identifier + "Found " + desired + " within " + actual + "." );
        else
            System.out.println("FAIL " + identifier + "NOT FOUND " + desired + " within " + actual + "." );
    }
    public void verifyCart(String brand,String patientName,String price,String totalR, String totalL, String cartTotal) {
        Wait(14);
        System.out.println("Page title is: " + driver.getTitle());
        //verify "please review your cart"
        String verifyTitleCart =  driver.findElement(By.xpath("//p[@class='']")).getText();
        System.out.println("Title is:" + verifyTitleCart);
        verifyTxtPresent("Title is: ", "Please review your cart", verifyTitleCart);
        System.out.println("Verified text present: Please review your cart");
        //verify brand
        String verifyBrandCart =  driver.findElement(By.xpath("//div[@id='patientNameDiv']")).getText();
        System.out.println("Brand and Patient Name is:" + verifyBrandCart);
        verifyTxtPresent("Brand in Cart: ", brand, verifyBrandCart);
        verifyTxtPresent("Patient Name in Cart: ", patientName, verifyBrandCart);
        String verifyPriceBoxCart =  driver.findElement(By.xpath("//div[@parameter='price']")).getText();
        verifyTxtPresent("Per Box Price in Cart: ", price, verifyPriceBoxCart);
        try
        {
            String verifyPriceREyeCart = driver.findElement(By.xpath("//div[@class='innerParam RightEyeViewModel.EyePrescriptionViewModel.Total']")).getText();
            verifyTxtPresent("R Eye Price in Cart: ", totalR, verifyPriceREyeCart);
        }
        catch (Throwable e)
        {
            System.out.println("No Right Eye");
        }
        try
        {
            String verifyPriceLEyeCart =  driver.findElement(By.xpath("//div[@class='innerParam LeftEyeViewModel.EyePrescriptionViewModel.Total']")).getText();
            verifyTxtPresent("L Eye Price in Cart: ",totalL,verifyPriceLEyeCart);
        }
        catch (Throwable e)
        {
            System.out.println("No Left Eye");
        }
        String verifyPriceTotalCart =  driver.findElement(By.xpath("//td[@id='cartTotalTd']")).getText();
        String verifyPriceShippingCart =  driver.findElement(By.xpath("//div[contains(@id,'uniform-ShippingViewModel_SelectedShipperCode')]")).getText();
        System.out.println("Shipping: " + verifyPriceShippingCart);
        verifyTxtPresent("Cart total: ",cartTotal,verifyPriceTotalCart);
    }
}
