package Automation;

import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeNIProgressiveCanadaTest extends TestBase {

    //change the Strings below to change the tests
    String testNumber = "44034";
    String typeOfTest = "SMOKE";
    String typeOfCust = "NI";
    String typeOfPayment = "Credit";
    String searchAllBrand = "multifocal";
    String brandToClickOn = "PureVisionMulti-Focal";
    String brandVerifyPDP = "PureVision Multi-Focal";
    String rPower = "++++++++++++++++";
    String lPower = "----------";
    String rPowerDesktop = "0.25";
    String lPowerDesktop = "0.75";
    String rBC = "";
    String lBC = "";
    String rDia = "";
    String lDia = "";
    String rAdd = "2";
    String lAdd = "2";
    String rCyl;
    String lCyl;
    String PatientFNameCart = "PatientFirst";
    String PatientLNameCart = "PatientLast";
    String ShippingCart = "cc";
    //String FullPatientName = (PatientFNameCart + " " + PatientLNameCart);
    String pricePerBox = "69.99";
    String priceREye = "139.98";
    String priceLEye = "139.98";
    String priceTotal = "306.95";
    String rsTotal = "306.95";
    String rsTotalAfterRebate = "147.92";
    String rsTax = "";
    String rsRebate = "";
    String rsShipping = "26.99" ;
    String shippingFName = "ShipFirst";
    String shippingLName = "ShipLast";
    String country = "CANADA";
    String state = "O";
    String city = "Ottawa";
    String zip = "K1A 0G9";
    String emailPrefix = "test";
    String password = "password";
    String drName = "test";
    String drState = "UT";
    String creditCard = "4012000077777777";
    String ccName = "Blah";
    String ccExpMo = "03";
    String ccExpYear = "2014";
    String shippingVerify = "Canada Express";
    String printTestName = typeOfTest + " | " + testNumber + " | " + typeOfCust + " | " + searchAllBrand + " | " + typeOfPayment + " | " + shippingVerify;
    String screenshotTestName =  testNumber + "_" + typeOfTest + "_" + typeOfCust + "_" + searchAllBrand + "_" + typeOfPayment + "_" + shippingVerify;


    @Test (singleThreaded = true)
    public void phoneTest() {
        openWebPage(mobileURL);
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //clickPhoneMainPage_NewButton_GOOD();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        //click on brand
        clickPhoneBrand(brandToClickOn);
        //Product Detail page
        verifyPDP(brandVerifyPDP);
        clickRPower(rPower);
        clickLPower(lPower);
        clickRAdd(rAdd);
        clickLAdd(lAdd);

        //enter patient name first then last
        typePatientName(PatientFNameCart,PatientLNameCart);
        //Add to cart
        clickAddToCart();
        //change shipping option
        selectShippingCart(ShippingCart);
        //cart page
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName,shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        clickNewAddress_Continue();
        //Do not have to select Doctor because it is international
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo, ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        //submit
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
    @Test (singleThreaded = true)
    public void desktopTest() {
        openWebPage(desktopBaseUrl);
        printTestNumber(printTestName);
        clickFindBrandDesktop();
        //search for lenses
        searchAllBrand(searchAllBrand);
        //click on brand
        clickBrand(brandToClickOn);
        //Product Detail page
        verifyPDP(brandVerifyPDP);
        clickRPower(rPowerDesktop);
        clickLPower(lPowerDesktop);
        clickRAdd(rAdd);
        clickLAdd(lAdd);
        //enter patient name first then last
        typePatientName(PatientFNameCart,PatientLNameCart);
        //Add to cart
        clickAddToCart();
        //cart page
        selectShippingCart(ShippingCart);
        //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName,shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        clickNewAddress_Continue();
        //FDo not have to select a Doctyor because it is international

        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo, ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        //submit
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }

    @Test (singleThreaded = true)
    public void tabletTest() {
        openWebPage(tabletURL);
        takeScreenshot(screenshotTestName, "Interstitial");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //clickPhoneMainPage_NewButton();
        clickFindBrand();
        //search for lenses
        searchAllBrand(searchAllBrand);
        takeScreenshot(screenshotTestName, "SearchBrand");
        //click on brand
        clickPhoneBrand(brandToClickOn);
        takeScreenshot(screenshotTestName, "PDP1");
        //Product Detail page
        verifyPDP(brandVerifyPDP);
        clickRPower(rPower);
        clickLPower(lPower);
        clickRAdd(rAdd);
        clickLAdd(lAdd);
        //enter patient name first then last
        typePatientName(PatientFNameCart,PatientLNameCart);
        takeScreenshot(screenshotTestName, "PDP2");
        //Add to cart
        clickAddToCart();
        //cart page
        selectShippingCart(ShippingCart);
        //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //click continue
        clickCart_Continue();
        //Enter Address Information
        typeShippingName(shippingFName,shippingLName);
        clickCountry(country);
        typeShippingAddress();
        typeShippingCity(city);
        typeShippingState(state);
        typeShippingZip(zip);
        typeShippingPhone();
        typeShippingEmail(emailPrefix,testNumber);
        typePassword_newcust(password);
        takeScreenshot(screenshotTestName, "NewAddress");
        clickNewAddress_Continue();
        //FDo not have to select Doctor because it is an international order
        //Enter Billing
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMo, ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        //submit
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
}
