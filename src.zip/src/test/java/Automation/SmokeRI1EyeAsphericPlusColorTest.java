package Automation;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRI1EyeAsphericPlusColorTest extends TestBase {

    String testNumber = "44053";
    String testNumberDependentOn = "44039";
    String typeOfTest = "SMOKE";
    String typeOfCust = "RI";
    String typeOfPayment = "Credit";
    String searchAllBrand = "color";
    String searchAllBrand2 = "Astigmatism";
    String brandToClickOn = "FreshLookColorblends";
    String brandToClickOn2 = "AcuvueOasysforAstigmatism";
    String brandVerifyPDP = "FreshLook Colorblends";
    String brandVerifyPDP2 = "Acuvue Oasys for Astigmatism";
    String rPower = "---";
    String lPower = "--";
    String rPower2 = "++";
    String lPower2 = "+++";
    String rPowerDesktop = "0.25";
    String lPowerDesktop = "0.75";
    String rPowerDesktop2 = "0.25";
    String lPowerDesktop2 = "0.75";
    String rBC = "8";
    String lBC = "8";
    String rDia = "1";
    String lDia = "1";
    String rBoxes = "1";
    String rBoxes2 = "3";
    String lBoxes = "3";
    String lBoxes2 = "2";
    String rAdd = "2";
    String lAdd = "2";
    String rAxis = "11";
    String lAxis = "1";
    String rCyl = "--";
    String lCyl = "--";
    String rColor = "A";
    String lColor = "B";
    String PatientFNameCart = "PatOneFirst";
    String PatientLNameCart = "PatientLast";
    String PatientFNameCart2 = "SecondPFirst";
    String PatientLNameCart2 = "SecondPLast";
    String ShippingCart = "c";
    //String FullPatientName = (PatientFNameCart + " " + PatientLNameCart);
    String pricePerBox = "47.99";
    String priceREye = "48.99";
    String priceLEye = "191.96";
    String pricePerBox2 = "";
    String priceREye2 = "";
    String priceLEye2 = "";
    String priceTotal = "387.92";
    String rsTotal = "414.49";
    String rsTotalAfterRebate = "364.49";
    String rsTax = "26.57";
    String rsRebate = "25 Acuvue Rebate";
    String rsShipping = "FREE" ;
    String shippingFName = "ShipFirst";
    String shippingLName = "ShipLast";
    String country = "united states";
    String state = "utah";
    String city = "slc";
    String zip = "84121";
    String emailPrefix = "test";
    String password = "password";
    String drName = "test";
    String drState = "UT";
    String creditCard = "4012000077777777";
    String ccName = "Blah";
    String ccExpMo = "03";
    String ccExpYear = "2014";
    String ccExpMoBad = "02";
    String ccExpYearBad = "2013";
    String shippingVerify = "Standard";
    String printTestName = typeOfTest + " | " + testNumber + " | " + typeOfCust + " | " + searchAllBrand + " | " + typeOfPayment + " | " + shippingVerify;
    String screenshotTestName =  testNumber + "_" + typeOfTest + "_" + typeOfCust + "_" + searchAllBrand + "_" + typeOfPayment + "_" + shippingVerify;

    @Test (singleThreaded = true)
    @Parameters(value="emailToUse")
    public void phoneTest(String emailToUse) {
        openWebPage(mobileURL);
        takeScreenshot(screenshotTestName, "Interstitial");
        clickNoThanksButton();
        printTestNumber(printTestName);
        goToSignInPage();
        typeReturningPhoneEmail(emailToUse);
        typeReturningPhonePassword(password);
        clickSignIn("phone");
        takeScreenshot(screenshotTestName, "Cart1");
        verifyCart(brandVerifyPDP2,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        clickAddRx();
        searchAllBrand(searchAllBrand);
        clickPhoneBrand(brandToClickOn);
        clickRPower(rPower);
        clickLPower(lPower);
        clickRColor(rColor);
        clickLColor(lColor);
        clickRboxes(rBoxes);
        clickLboxes(lBoxes);
        typePatientName(PatientFNameCart2, PatientLNameCart2);
        takeScreenshot(screenshotTestName, "PDP");
        clickAddToCart();
        takeScreenshot(screenshotTestName, "Cart2");
        clickCart_Continue();
        selectDoctor();
        //Enter Billing - exp cc
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMoBad,ccExpYearBad);
        takeScreenshot(screenshotTestName, "ReviewSubmit1");
        clickBottomSubmitButton();
        takeScreenshot(screenshotTestName, "ExpCard");
        verifyExpiredCard();
        //change exp date and resubmit
        pickCreditCardExpDate(ccExpMo,ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit2");
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        driver.quit();
    }
    @Test (singleThreaded = true)
    @Parameters(value="emailToUse")
    public void desktopTest(String emailToUse) {
        openWebPage(desktopBaseUrl);
        takeScreenshot(screenshotTestName, "HomePage");
        clickNoThanksButton();
        printTestNumber(printTestName);
        goToSignInPage();
        typeReturningPhoneEmail(emailToUse);
        typeReturningPhonePassword(password);
        clickSignIn("desktop");
        takeScreenshot(screenshotTestName, "Cart1");
        verifyCart(brandVerifyPDP2,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        clickAddRx();
        searchAllBrand(searchAllBrand);
        clickPhoneBrand(brandToClickOn);
        clickRPower(rPowerDesktop);
        clickLPower(lPowerDesktop);
        clickRColor(rColor);
        clickLColor(lColor);
        clickRboxes(rBoxes);
        clickLboxes(lBoxes);
        typePatientName(PatientFNameCart2, PatientLNameCart2);
        takeScreenshot(screenshotTestName, "PDP");
        clickAddToCart();
        takeScreenshot(screenshotTestName, "Cart2");
        clickCart_Continue();
        selectDoctor();
        //Enter Billing - exp cc
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMoBad,ccExpYearBad);
        takeScreenshot(screenshotTestName, "ReviewSubmit1");
        clickBottomSubmitButton();
        takeScreenshot(screenshotTestName, "ExpCard");
        verifyExpiredCard();
        //change exp date and resubmit
        pickCreditCardExpDate(ccExpMo,ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit2");
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        driver.quit();
    }
    @Test (singleThreaded = true)
    @Parameters(value="emailToUse")
    public void tabletTest(String emailToUse) {
        openWebPage(tabletURL);
        takeScreenshot(screenshotTestName, "Interstitial");
        clickNoThanksButton();
        printTestNumber(printTestName);
        goToSignInPage();
        typeReturningPhoneEmail(emailToUse);
        typeReturningPhonePassword(password);
        clickSignIn("tablet");
        takeScreenshot(screenshotTestName, "Cart1");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        clickAddRx();
        searchAllBrand(searchAllBrand);
        clickPhoneBrand(brandToClickOn);
        clickRPower(rPower);
        clickLPower(lPower);
        clickRColor(rColor);
        clickLColor(lColor);
        clickRboxes(rBoxes);
        clickLboxes(lBoxes);
        typePatientName(PatientFNameCart2, PatientLNameCart2);
        takeScreenshot(screenshotTestName, "PDP");
        clickAddToCart();
        takeScreenshot(screenshotTestName, "Cart2");
        clickCart_Continue();
        selectDoctor();
        //Enter Billing - exp cc
        typeCreditCard(creditCard);
        typeCreditCardName(ccName);
        pickCreditCardExpDate(ccExpMoBad,ccExpYearBad);
        takeScreenshot(screenshotTestName, "ReviewSubmit1");
        clickBottomSubmitButton();
        takeScreenshot(screenshotTestName, "ExpCard");
        verifyExpiredCard();
        //change exp date and resubmit
        pickCreditCardExpDate(ccExpMo,ccExpYear);
        takeScreenshot(screenshotTestName, "ReviewSubmit2");
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        driver.quit();
    }
}
