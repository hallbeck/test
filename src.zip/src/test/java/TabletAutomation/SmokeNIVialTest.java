package TabletAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeNIVialTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void tabletTest(String ffprofile) {
      openWebPage(tabletDevice);

      printTestNumber("SMOKE 44032 NI Vial CC");

      //clickPhoneMainPage_NewButton_GOOD();
     clickFindBrand();

      //search for lenses
      searchAllBrand("vial");

    //click on brand
    // -- uncomment this when the real search works
     clickPhoneBrand("SoftconEW");
    // For the all brands page
    //  clickPhoneBrand("Softcon EW");


    //Product Detail page
    //Power
    clickRPower("++++++++++++++++++");
    clickLPower("++++++++++++++");

      //bc
      clickRBC("8");
      clickLBC("8");

      //dia
      clickRDia("11");
      clickLDia("11");

      //enter patient name first then last
    typePatientName("PatientFirst", "PatientLast");

    //Add to cart
    clickAddToCart();

    //cart page \
      selectShippingCart("nn");
      //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
      verifyCart("Softcon EW","PatientFirst PatientLast","59.99","119.98","119.98","264.95");
      //click continue
    clickCart_Continue();

    //Enter Address Information
    //names
    typeShippingName("shipfirst", "shiplast");

    //country
    clickCountry("united states");
    //address
    typeShippingAddress();
    //city
    typeShippingCity("slc");
    typeShippingState("UT");
    typeShippingZip("84121");
    //phone
    typeShippingPhone();
    typeShippingEmail("test");
    typePassword_newcust("password");
    clickNewAddress_Continue();

    //Find then select Doctor by name and state
    typeDoctorSearch("test");
    typeDoctorStateAndFind("Utah");
    selectDoctor();

    //Enter Billing
    typeCreditCard("4012000077777777");
    typeCreditCardName("Blah");
    pickCreditCardExpDate("03", "2015");

    //submit
    clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage();
    //Close the browser
    driver.quit();
  }
}
