package MobileAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeNIAsphericInternationalTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void phoneTest(String ffprofile) {

      openWebPage(mobileDevice);
      //click on interstitial for now
      clickNoThanksButton();
      String testNumber = "44036";
      printTestNumber("SMOKE" + testNumber + "NI Aspheric International CC");
      //clickPhoneMainPage_NewButton();
      clickFindBrand();

      //search for lenses
       searchAllBrand("Astigmatism");
    //click on brand
    clickPhoneBrand("AirOptixforAstigmatism");

    //Product Detail page
    //Power
    clickRPower("++++++++++++++++");
    clickLPower("----------");

      //cyl
      clickRCyl("--");
      clickLCyl("--");

      //axis
      clickRAxis("11");
      clickLAxis("11");

      //enter patient name first then last
    typePatientName("PatientFirst", "PatientLast");

    //Add to cart
    clickAddToCart();

    //cart page
      //change shipping option
      selectShippingCart("ii");
      //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
      verifyCart("Air Optix for Astigmatism","PatientFirst PatientLast","59.99","119.98","119.98","275.95");
    //click continue
    clickCart_Continue();

    //Enter Address Information
    //names
    typeShippingName("shipfirst", "shiplast");
    //country
    clickCountry("BOLIVIA");
    //address
    typeShippingAddress();
      typeIntShippingZip("K1A 0G9");
    //city
    typeShippingCity("whatever");
    typeIntShippingState("Newberry");
    //phone
    typeIntShippingPhone();
    typeShippingEmail("test",testNumber);
    typePassword_newcust("password");
    clickNewAddress_Continue();

    //Find then select Doctor by name and state
   // typeDoctorSearch("test");
   // typeDoctorStateAndFind("Utah");
   // selectDoctor();

    //Enter Billing
    typeCreditCard("4012000077777777");
    typeCreditCardName("Blah");
    pickCreditCardExpDate("03","2015");

    //submit
    clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage("Int'l Express");
    //Close the browser
    driver.quit();
  }
}
