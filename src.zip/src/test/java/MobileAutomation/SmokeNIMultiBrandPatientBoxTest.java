package MobileAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeNIMultiBrandPatientBoxTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void phoneTest(String ffprofile) {

      openWebPage(mobileDevice);

      //click on interstitial for now
      clickNoThanksButton();

      // click on New to 1800contacts Find your brand
      String testNumber = "44042";
    printTestNumber("SMOKE" + testNumber + "NI Multi Brand Multi patient Change Boxes CC");
    //clickPhoneMainPage_NewButton();
    clickFindBrand();

      //search for lenses
      searchAllBrand("Color");

    //click on brand
    clickPhoneBrand("FreshLookColors");

    //Product Detail page Enter Power
      //uncheck Left Eye (use twice to select again)
    //mobile
    clickRPower("--");
      clickLPower("--");

    //color
    clickRColor("V");
    clickLColor("B");

      //number of boxes
    clickRboxes("1");
      clickLboxes("3");

    //enter patient name first then last
    typePatientName("FirstPaFirst", "FirstPaLast");

      //click Add Rx
      clickAddRx();
      //search for lenses
      searchAllBrand("Toric");

      //click on brand

      clickPhoneBrand("VertexToricXR");

      //Product Detail page Enter Power
      //mobile
      clickRPower("++");
      clickLPower("+++");

      //cyl
      clickRCyl("--");
      clickLCyl("--");

      //axis
      clickRAxis("111");
      clickLAxis("11");

      //number of boxes  6
      clickRboxes("3");
      clickLboxes("2");

      //enter patient name first then last
      typePatientName("SecondPaFirst", "SecondPaLast");

    //Add to cart
    clickAddToCart();

    //cart page
      //change shipping option
      selectShippingCart("n");
      //format (product,patient name first last, price per box, price for R eye (#boxes x price per box),price for L eye (#boxes x price per box), Total - includes shipping )
      verifyCart("FreshLook Colors","FirstPaFirst FirstPaLast","49.99","49.99","149.97","759.90");
    //click continue

    clickCart_Continue();

    //Enter Address Information
    //names
    typeShippingName("shipfirst", "shiplast");

    //country
    clickCountry("USA");
    //address
    typeShippingAddress();
    //city
    typeShippingCity("slc");
    typeShippingState("UT");
    typeShippingZip("84121");
    //phone
    typeShippingPhone();
    typeShippingEmail("test",testNumber);
    typePassword_newcust("password");
    clickNewAddress_Continue();

    //Find then select Doctor by name and state
    typeDoctorSearch("test");
    typeDoctorStateAndFind("Utah");
    selectDoctor();

    //Enter Billing
    typeCreditCard("4012000077777777");
    typeCreditCardName("Blah");
    pickCreditCardExpDate("03","2015");

    //submit
    clickBottomSubmitButton();
    //ThankYou
    verifyThankYouPage("Next");
    //Close the browser
    driver.quit();
  }
}
