package Automation;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRIToricTest extends TestBase {

    String testNumber = "44043";
    String testNumberDependentOn = "44029";
    String typeOfTest = "SMOKE";
    String typeOfCust = "RI";
    String typeOfPayment = "Credit";
    String searchAllBrand = "vial";
    String brandToClickOn = "VertexToricXR";
    String brandVerifyPDP = "Vertex Toric XR";
    String rPower = "++++++++++++++++++";
    String lPower = "++++++++++++++";
    String rPowerDesktop = "0.50";
    String lPowerDesktop = "1.75";
    String rBC = "8";
    String lBC = "8";
    String rDia = "1";
    String lDia = "1";
    String rBoxes = "1";
    String rBoxes2 = "3";
    String lBoxes = "1";
    String lBoxes2 = "2";
    String rAdd;
    String lAdd;
    String rCyl;
    String lCyl;
    String PatientFNameCart = "PatientFirst";
    String PatientLNameCart = "PatientLast";
    String ShippingCart = "nn";
    //String FullPatientName = (PatientFNameCart + " " + PatientLNameCart);
    String pricePerBox = "107.99";
    String priceREye = "431.96";
    String priceLEye = "431.96";
    String priceTotal = "863.92";
    String rsTotal = "230.77";
    String rsTotalAfterRebate = "147.92";
    String rsTax = "14.79";
    String rsRebate = "";
    String rsShipping = "FREE" ;
    String shippingFName = "ShipFirst";
    String shippingLName = "ShipLast";
    String country = "united states";
    String state = "utah";
    String city = "slc";
    String zip = "84121";
    String emailPrefix = "test";
    String password = "password";
    String drName = "test";
    String drState = "UT";
    String creditCard = "4012000077777777";
    String ccName = "Blah";
    String ccExpMo = "03";
    String ccExpYear = "2014";
    String shippingVerify = "Expedited";
    String printTestName = typeOfTest + " | " + testNumber + " | " + typeOfCust + " | " + searchAllBrand + " | " + typeOfPayment + " | " + shippingVerify;
    String screenshotTestName =  testNumber + "_" + typeOfTest + "_" + typeOfCust + "_" + searchAllBrand + "_" + typeOfPayment + "_" + shippingVerify;


    @Test (singleThreaded = true)
    @Parameters(value="emailToUse")
    public void phoneTest(String emailToUse) {
        openWebPage(mobileURL);
        takeScreenshot(screenshotTestName, "Interstitial");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //Go Directly to Sign In Page this is a fudge.
        goToSignInPage();
        // Login as returning customer
        typeReturningPhoneEmail(emailToUse);
        typeReturningPhonePassword(password);
        clickSignIn("phone");
                //validate cart
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //continue through cart
        clickCart_Continue();
        //submit
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
    @Test (singleThreaded = true)
    @Parameters(value="emailToUse")
    public void desktopTest(String emailToUse) {
        openWebPage(desktopBaseUrl);
        takeScreenshot(screenshotTestName, "HomePage");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //Go Directly to Sign In Page this is a fudge.
        goToSignInPage();
        // Login as returning customer
        typeReturningPhoneEmail(emailToUse);
        typeReturningPhonePassword(password);
        clickSignIn("desktop");
        //validate cart
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //continue through cart
        clickCart_Continue();
        //submit
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
    @Test (singleThreaded = true)
    @Parameters(value="emailToUse")
    public void tabletTest(String emailToUse) {
        openWebPage(tabletURL);
        takeScreenshot(screenshotTestName, "Interstitial");
        //click on interstitial for now
        clickNoThanksButton();
        printTestNumber(printTestName);
        //Go Directly to Sign In Page this is a fudge.
        goToSignInPage();
        // Login as returning customer
        typeReturningPhoneEmail(emailToUse);
        typeReturningPhonePassword(password);
        clickSignIn("tablet");
        //validate cart
        takeScreenshot(screenshotTestName, "Cart");
        verifyCart(brandVerifyPDP,PatientFNameCart + " " + PatientLNameCart,pricePerBox,priceREye,priceLEye,priceTotal);
        //continue through cart
        clickCart_Continue();
        //submit
        takeScreenshot(screenshotTestName, "ReviewSubmit");
        verifyRS(brandVerifyPDP, PatientFNameCart, pricePerBox, priceREye, priceLEye, priceTotal, rsTax, rsTotal, rsTotalAfterRebate, rsRebate, rsShipping);
        clickBottomSubmitButton();
        //ThankYou
        verifyThankYouPage(shippingVerify);
        takeScreenshot(screenshotTestName, "ThankYou");
        //Close the browser
        driver.quit();
    }
}
