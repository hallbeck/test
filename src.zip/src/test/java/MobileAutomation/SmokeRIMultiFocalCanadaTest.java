package MobileAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRIMultiFocalCanadaTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void phoneTest(String ffprofile) {
      openWebPage(mobileDevice);

      //click on interstitial for now
      clickNoThanksButton();
    // click on New to 1800contacts Find your brand
      String testNumber = "44048";
      //test_1366905289170@invalid.com
      printTestNumber("SMOKE 44048 RI MultiFocal Canada CC");
      //clickPhoneMainPage_NewButton();
      goToSignInPage();
      // Login as returning customer

      typeReturningPhoneEmail("test_1366905289170@invalid.com");
      typeReturningPhonePassword("password");

      clickSignIn();

      //cart page
      //click continue
      clickCart_Continue();

      //submit
      clickBottomSubmitButton();
      //ThankYou
      verifyThankYouPage("Canada Standard");
    driver.quit();
  }
}
