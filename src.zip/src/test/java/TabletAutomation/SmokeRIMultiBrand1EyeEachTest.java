package TabletAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SmokeRIMultiBrand1EyeEachTest extends TestBase {

    @DataProvider
    static Object[][] ffprofile() {
        return new Object[][]{
                {
                        "iphoneP"
                },
        };
    }

  @Test(dataProvider = "ffprofile", singleThreaded = true)
  public void tabletTest(String ffprofile) {

      // And now use this to visit the home page
      openWebPage(tabletDevice);
      // click on New to 1800contacts Find your brand
    printTestNumber("SMOKE 44054 RI Multi Brand 1 patient 1 eye each CC");

      //Go Directly to Sign In Page this is a fudge.
      goToSignInPage();
      // Login as returning customer

      typeReturningPhoneEmail("test_1366214869752@invalid.com");
      typeReturningPhonePassword("password");

      clickSignIn();
      //cart page
      //click continue
      clickCart_Continue();

      //submit
      clickBottomSubmitButton();
      //ThankYou
      verifyThankYouPage();
      //Close the browser
      driver.quit();
  }
}
