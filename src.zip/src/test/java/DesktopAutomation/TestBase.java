package DesktopAutomation;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.Select;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Date;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Created with IntelliJ IDEA.
 * User: KHALLBEC
 * Date: 3/17/13
 * Time: 6:23 PM
 * To change this template use File | Settings | File Templates.
 */


public class TestBase{
    //change this to whatever browser you want to test on
    String browser = "firefox"; //choices are ie,firefox,chrome,safari         -- SAFARI DOES NOT SELECT RX VALUES WELL. DO NOT USE
    //change this for ff browser only
    String deviceProfile = "desktopFF";   //choices are desktopFF,desktopIE10 - this is for firefox profiles only

    String desktop = "https://www.1800contactstest.com";
    String desktopBaseUrl = desktop;
    String mobileDevice = "https://www.1800contactstest.com/?responsive=yes";
    String mobileBaseUrl = mobileDevice;
    String tabletDevice = "https://www.1800contactstest.com/?responsive=yes";
    String tabletBaseUrl = tabletDevice;


    //profiles locations are stored in C:\Users\<user>\AppData\Roaming\Mozilla\Firefox
    //change this file to point to your personal profiles


    ChromeOptions options = new ChromeOptions();
    DesiredCapabilities capabilities = DesiredCapabilities.chrome();
    //capabilities.setCapability("chrome.switches", "--ignore-certificate-errors");

    String fileName = ("TestOut" + new Date().getTime());
    WebDriver driver = makeDriver(browser,deviceProfile);
    public static WebDriver makeDriver(String browser, String deviceProfile) {
        ProfilesIni allProfiles = new ProfilesIni();
        FirefoxProfile profile = allProfiles.getProfile(deviceProfile);
        WebDriver driver = null;

        if (browser.equals("ie")) {
            driver = new InternetExplorerDriver();
        } else if (browser.equals("firefox")) {
            driver = new FirefoxDriver(profile);
        } else if (browser.equals("chrome")) {
            driver = new ChromeDriver();
        } else if (browser.equals("safari")) {
            driver = new SafariDriver();
        }
        return driver;
    }

    public void openWebPage(String device) {
        //driver.get(device);
        Wait(2);
        driver.get("https://www.google.com");
        Wait(2);
        setCookie();
        Wait(5);
        driver.get(device);
    }
    public void setForseeCookie(){
        // Now set the cookie. This one's valid for the entire domain
        Cookie cookie = new Cookie("fsr.r", "{\"d\":590,\"i\":\"\",\"e\":};expires=Tue,20 Sep 2017 15:23:48 GMT; path=/; domain=.1800contactstest.com");
        driver.manage().addCookie(cookie);

        // Cookie cookie2 = new Cookie("fsr.s", "{\"v\":-1,\"rid\":\"1366228995524_980916\",\"to\":3,\"c\":\"https://www.1800contactstest.com\",\"pv\":13,\"lc\":{\"d0\":{\"v\":13,\"s\":true}},\"cd\":0,\"sd\":0,\"cp\":{\"s_prop2\":\"RI\",\"s_eVar29\":\"Control\"},\"f\":1366225336932,\"i\":-1,\"l\":\"en\"}");
        //driver.manage().addCookie(cookie2);

// And now output all the available cookies for the current URL
        Set<Cookie> allCookies = driver.manage().getCookies();
        for (Cookie loadedCookie : allCookies) {
            System.out.println(String.format("%s -> %s", loadedCookie.getName(), loadedCookie.getValue()));
        }
    }
    public void setCookie(){
        //String key = "fsr.r";
        //String value = "{\"d\":90,\"i\":\"\",\"e\":};expires=Tue,20 Sep 2017 15:23:48 GMT; path=/;";
        //String domain = ".1800contactstest.com";
        String key = "fsr.s";
        //{"v":-1,"rid":"1366734711827_458379","to":2.4,"c":"https://www.1800contactstest.com","pv":4,"lc":{"d0":{"v":4,"s":true}},"cd":0,"sd":0,"cp":{"s_prop2":"NI","s_eVar29\":"Control"},"f":1366734744426,"i":-1,"l":"en"}
        String value = "{\"v\":-2,\"rid\":\"1366734711827_458379\",\"to\":2.4,\"c\":\"/\",\"pv\":4,\"lc\":{\"d90\":{\"v\":4,\"s\":true}},\"cd\":90,\"sd\":90,\"cp\":{\"s_prop2\":\"NI\",\"s_eVar29\\\":\"Control\"},\"f\":1366734744426,\"l\":\"en\",\"i\":-1}";
        String domain = "";
    Cookie cookie = new Cookie.Builder(key, value).domain(domain).path(
            "/").build();
    driver.manage().addCookie(cookie);
        Set<Cookie> allCookies = driver.manage().getCookies();
        for (Cookie loadedCookie : allCookies) {
            System.out.println(String.format("%s -> %s", loadedCookie.getName(), loadedCookie.getValue()));
        }
    }
    public void printToFile(){
        try {
            PrintStream ps = System.out;
            System.setOut(new PrintStream(new FileOutputStream(fileName + ".txt")));
            System.out.println("foo");
            ps.println("bar");
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }


  static {
      //WebDriver driver = new FirefoxDriver();
    //profile.setPreference("general.useragent.override", userAgent);
  }

    public void printPageTitle() {
        System.out.println("Page title is: " + driver.getTitle());
        Wait(2);
  }
    public void printText(String text) {
        System.out.println(text);
        Wait(2);
    }
    public void printTestNumber(String test) {
        System.out.println("Test Covered is: " + test + " " + deviceProfile);
    }

  public static void Wait(long seconds) {
    try {
      Thread.sleep(seconds * 1000);
    } catch (Exception e) {
      System.out.println("Sleep exception...its a nightmare");
    }
  }

  public void clickMainPage_NewButton() {
      printPageTitle();
    driver.findElement(By.xpath("//img[contains(@alt,'New to 1-800 Contacts - Find your contact lens brand')]")).click();
      System.out.println("Clicked on New customer button");
    Wait(4);
  }

    //reorder checkboxes this uses tabs to click each. two tabs, click tab click
   // public void checkReorderCheckboxOne(){
        //go to dashboard cause I can't use lightbox
    //    driver.get("https://www.1800contactstest.com/accounthub");
    //    Wait(2);
    //    WebElement eleMyAccount = driver.findElement(By.xpath("//div[contains(@class,'rxSummaryLineItemColumn memberRecentPrescription')]"));
    //    eleMyAccount.click();
    //    System.out.println("Clicked on header or something I think");
    //    Wait(2);
        //tab five times then space
    //    System.out.println("sending tabs");
    //    eleMyAccount.sendKeys(Keys.chord(Keys.SHIFT, Keys.TAB),Keys.SPACE);
      //  Wait(2);
    //}

  //  public void checkReorderCheckboxTwo(){
        //go to dashboard cause I can't use lightbox
    //    driver.get("https://www.1800contactstest.com/accounthub");
    //    Wait(2);
   // WebElement eleMyAccount = driver.findElement(By.xpath("//div[contains(@class,'rxSummaryLineItemColumn memberRecentPrescription')]"));
   //     eleMyAccount.click();
   //     System.out.println("Clicked on header or something I think");
   //    Wait(2);
   //     //tab five times then space
   //     System.out.println("sending tabs");
     //   eleMyAccount.sendKeys(Keys.chord(Keys.SHIFT, Keys.TAB),Keys.SPACE,Keys.TAB,Keys.SPACE);
   //     Wait(2);
   // }
    public void checkReorderCheckboxOne(){
        //go to dashboard cause I can't use lightbox
        driver.get("https://www.1800contactstest.com/accounthub");
        Wait(2);
        WebElement eleMyAccount = driver.findElement(By.xpath("//a[contains(@id,'dashboardForm')]"));
        eleMyAccount.click();
        System.out.println("Clicked on header or something I think");
        Wait(2);
        //tab five times then space
        System.out.println("sending tabs");
        eleMyAccount.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.SPACE);
        System.out.println("sent tabs");
        Wait(2);
    }

    public void checkReorderCheckboxTwo(){
        //go to dashboard cause I can't use lightbox
        driver.get("https://www.1800contactstest.com/accounthub");
        Wait(2);
        WebElement eleMyAccount = driver.findElement(By.xpath("//a[contains(@id,'dashboardForm')]"));
        eleMyAccount.click();
        System.out.println("Clicked on header or something I think");
        Wait(2);
        //tab five times then space
        System.out.println("sending tabs");
        eleMyAccount.sendKeys(Keys.TAB,Keys.TAB,Keys.TAB,Keys.TAB,Keys.SPACE,Keys.TAB,Keys.SPACE);
        System.out.println("sent tabs");
        Wait(2);
    }

    //continue button from the reorder Lightbox
    public void clickContinueFromReorder(){
        System.out.println("clicking continue");
        driver.findElement(By.xpath("//input[contains(@src,'continue.png')]")).click();
    }
    public void clickReorderTheseRxButton(){
        driver.findElement(By.xpath("//input[contains(@id,'reorderMultipleRx')]")).click();
    }
    //This worked, then stopped working. Once the buttons and links are redone, uncomment clickFindBrand and rename
    //clickFindBrand to go to lens page cause that's what it does.
    public void clickFindBrand() {
        printPageTitle();
        Wait(4);
        // phone
        driver.findElement(By.xpath("//img[contains(@alt,'New to 1-800 Contacts - Find your contact lens brand')]")).click();
        //driver.findElement(By.linkText("How to Order")).click();
        System.out.println("Clicked on Find your brand button");
        Wait(4);
    }
    public void clickPhoneBrand(String brand) {
        String theString = "//a[contains(@id,'" + brand + "')]";
        driver.findElement(By.xpath(theString)).click();
        System.out.println("Clicked on brand: " + brand);
        System.out.println(brand);
        Wait(6);
    }

    public void clickReorderPhoneMainPage() {
        printPageTitle();
        Wait(4);
        driver.findElement(By.xpath("//a[contains(@class,'Account-footer-link')]")).click();
        //driver.findElement(By.xpath("//div[contains(.,'Find Your Brand')]")).click();
        //driver.findElement(By.linkText("How to Order")).click();
        System.out.println("Clicked on My Account footer link");
        Wait(4);
    }

    public void goToSignInPage(){
        driver.get("https://www.1800contactstest.com/signin.aspx");
    }
               //SignIn Email Lightbox       DOES NOT WORK with popup
       public void typeReturningPhoneEmail(String email) {
        printPageTitle();
        Wait(4);
           WebElement emailInput = driver.findElement(By.xpath("//input[(@id='ctl00_contentPlaceHolderContent_SignIn1_tbEmail_tbEmail')]"));
           emailInput.click();
           emailInput.clear();
           System.out.println("clicked and cleared");
           emailInput.sendKeys(email);
        System.out.println("Email used is: " + email);
    }
    //SignIn password Lightbox       DOES NOT WORK on popup
    public void typeReturningPhonePassword(String password) {
        Wait(4);
        WebElement passwordInput = driver.findElement(By.xpath("//input[(@id='ctl00_contentPlaceHolderContent_SignIn1_tbReturningCustomerPassword_tbPass')]"));
        passwordInput.click();
        passwordInput.clear();
        passwordInput.sendKeys(password);
        System.out.println("Password used is: " + password);
    }

    public void clickSignIn() {
        printPageTitle();
        driver.findElement(By.xpath("//input[contains(@name,'btnSignIn')]")).click();
        System.out.println("Clicked Sign In");
        Wait(6);
    }

    public void searchAllBrand(String search) {
        Wait(8);
        driver.findElement(By.xpath("//input[contains(@name,'searchTerm')]")).click();
        driver.findElement(By.xpath("//input[contains(@name,'searchTerm')]")).clear();
        System.out.println("Clicked Search ");
        driver.findElement(By.xpath("//input[contains(@name,'searchTerm')]")).sendKeys(search, Keys.ENTER);
        System.out.println("Searched for brand: " + search);
        Wait(10);
    }

     //UNKNOWN if it works
    public void clickSeeAll() {
        driver.findElement(By.xpath("//div[contains(.,'See All')]")).click();
        System.out.println("Clicked See All");
    }

    //when search works uncomment this and rename clickPhoneBrand to clickPhoneAllProductBrand
    public void clickBrand(String brand) {
       String theString = "//a[contains(@id,'BrandSelectButton_" + brand + "')]";
       driver.findElement(By.xpath(theString)).click();
       System.out.println("Clicked on brand: " + brand);
       Wait(6);
  }


   public void checkBoxLeftEye() {
       driver.findElement(By.xpath("//input[contains(@class,'LeftEyeCheckBox')]")).click();
   }

    public void checkBoxRightEye() {
        driver.findElement(By.xpath("//input[contains(@class,'RightEyeCheckBox')]")).click();
    }
    //Power +down arrow once will choose Plano if available.
    //down arrow will select neg values starting low going higher.
    //right arrow will move to positive values starting low going higher.
    //
    public void clickRPowerFullPath(String power) {
        WebElement wePower = driver.findElement(By.xpath("//select[contains(@id,'ProductPageViewModel_PrescriptionViewModel_RightEyeViewModel_EyePrescriptionViewModel_SphericalPower')]"));
        wePower.click();
        Wait(5);
        System.out.println("Power for right eye: " + power);
        wePower.sendKeys(Keys.ARROW_DOWN,Keys.ARROW_DOWN);
        Wait(5);
    }
    public void clickLPowerFullPath(String power) {
        WebElement wePower = driver.findElement(By.xpath("//select[contains(@id,'ProductPageViewModel_PrescriptionViewModel_LeftEyeViewModel_EyePrescriptionViewModel_SphericalPower')]"));
        wePower.click();
        Wait(5);
        System.out.println("Power for left eye: " + power);
        wePower.sendKeys(Keys.ARROW_DOWN,Keys.ARROW_RIGHT,Keys.ARROW_RIGHT,Keys.ARROW_DOWN,Keys.ARROW_DOWN);
        Wait(5);
    }
  public void clickRPower(String power) {
      Wait(5);
      WebElement wePower = driver.findElement(By.xpath("//input[contains(@id,'RightPowerPicker')]"));
     // <a href="#" val="0.25" id="Right_0.25">+0.25</a>
      wePower.click();
      WebElement wePowerNumber = driver.findElement(By.xpath("//a[contains(@id,'Right_" + power +"')]"));
      //WebElement wePowerNumber = driver.findElement(By.xpath("//a[contains(@id,'Right_0.25')]"));
      wePowerNumber.click();
      Wait(5);
      System.out.println("Power for right eye: " + power);
      //works for all but safari ??? --- wePower.sendKeys(Keys.ARROW_DOWN,Keys.ARROW_DOWN);
      Wait(5);
  }
    public void clickLPower(String power) {
        WebElement wePower = driver.findElement(By.xpath("//input[contains(@id,'LeftPowerPicker')]"));
        wePower.click();
        Wait(5);
        System.out.println("Power for left eye: " + power);
        WebElement wePowerNumber = driver.findElement(By.xpath("//a[contains(@id,'Left_" + power +"')]"));
        wePowerNumber.click();
        Wait(5);
    }
    public void clickRPowerPlano(String power) {
        WebElement wePower = driver.findElement(By.xpath("//input[contains(@id,'RightPowerPicker')]"));
        wePower.click();
        Wait(5);
        System.out.println("Power for right eye: Plano");
        WebElement wePowerNumber = driver.findElement(By.xpath("//a[contains(@id,'Right_" + power +"')]"));
        wePowerNumber.click();
        Wait(5);
    }
    public void clickLPowerPlano(String power) {
        WebElement wePower = driver.findElement(By.xpath("//input[contains(@id,'LeftPowerPicker')]"));
        wePower.click();
        Wait(5);
        System.out.println("Power for left eye: Plano");
        WebElement wePowerNumber = driver.findElement(By.xpath("//a[contains(@id,'Left_" + power +"')]"));
        wePowerNumber.click();
        Wait(5);
    }

  public void clickRBC(String bc) {
      String thePickerString = "//select[contains(@id,'PrescriptionViewModel_RightEyeViewModel_EyePrescriptionViewModel_BaseCurve')]";
      WebElement weBc = driver.findElement(By.xpath(thePickerString));
      weBc.click();
      Wait(5);
    System.out.println("BC for right eye: " + bc);
    weBc.sendKeys(bc);
    Wait(5);
  }
    public void clickLBC(String bc) {
        String thePickerString = "//select[contains(@id,'PrescriptionViewModel_LeftEyeViewModel_EyePrescriptionViewModel_BaseCurve')]";
        WebElement weBc = driver.findElement(By.xpath(thePickerString));
        weBc.click();
        Wait(5);
        System.out.println("BC for left eye: " + bc);
        weBc.sendKeys(bc);
        Wait(5);
    }
    public void clickRDia(String dia) {
        WebElement weDia = driver.findElement
                (By.xpath("//select[contains(@name,'PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.DiameterLength')]"));
        weDia.click();
        Wait(5);
        System.out.println("Dia for right eye: " + dia);
        weDia.sendKeys(dia);
        Wait(5);
    }
    public void clickLDia(String dia) {
        WebElement weDia = driver.findElement
                (By.xpath("//select[contains(@name,'PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.DiameterLength')]"));
        weDia.click();
        Wait(5);
        System.out.println("Dia for left eye: " + dia);
        weDia.sendKeys(dia);
        Wait(5);
    }

    public void clickRCyl(String cyl) {
        WebElement weCyl = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.CylinderPower')]"));
        weCyl.click();
        System.out.println("Cyl for right eye: " + cyl);
        weCyl.sendKeys(cyl);
        Wait(5);
    }
    public void clickLCyl(String cyl) {
        WebElement weCyl = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.CylinderPower')]"));
        weCyl.click();
        System.out.println("Cyl for left eye: " + cyl);
        weCyl.sendKeys(cyl);
        Wait(5);
    }
    public void clickRAxis(String axis) {
        WebElement weAxis = driver.findElement
                (By.xpath("//select[contains(@name,'PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.AxisDegree')]"));
        weAxis.click();
        System.out.println("Axis for right eye: " + axis);
        weAxis.sendKeys(axis);
        Wait(1);
    }
    public void clickLAxis(String axis) {
        WebElement weAxis = driver.findElement
                (By.xpath("//select[contains(@name,'PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.AxisDegree')]"));
        weAxis.click();
        System.out.println("Axis for left eye: " + axis);
        weAxis.sendKeys(axis);
        Wait(1);
    }
    public void clickRColor(String color) {
        WebElement weColor = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.ColorId')]"));
        weColor.click();
        weColor.sendKeys(color);
        System.out.println("Color for right eye: " + color);
        Wait(1);

    }
    public void clickLColor(String color) {
        WebElement weColor = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.ColorId')]"));
        weColor.click();
        System.out.println("Color for left eye: " + color);
        weColor.sendKeys(color);
        Wait(1);
    }
    public void clickRboxes(String box) {
        WebElement weBox = driver.findElement
                (By.xpath("//select[contains(@name,'PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.Quantity')]"));
        weBox.click();
        System.out.println("Boxes for right eye: " + box);
        weBox.sendKeys(box);
        System.out.println(box + " boxes Right Eye");
        Wait(1);
    }
    public void clickLboxes(String box) {
        WebElement weBox = driver.findElement
                (By.xpath("//select[contains(@name,'PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.Quantity')]"));
        weBox.click();
        System.out.println("Boxes for left eye: " + box);
        weBox.sendKeys(box);
        System.out.println(box + " boxes Left Eye");
        Wait(1);
    }

    public void clickRAdd(String add) {
        WebElement weAdd = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.RightEyeViewModel.EyePrescriptionViewModel.AddPower')]"));
        weAdd.click();
        System.out.println("ADD for Right eye: " + add);
        weAdd.sendKeys(add);
        Wait(1);
    }
    public void clickLAdd(String add) {
        WebElement weAdd = driver.findElement
                (By.xpath("//select[contains(@name,'ProductPageViewModel.PrescriptionViewModel.LeftEyeViewModel.EyePrescriptionViewModel.AddPower')]"));
        weAdd.click();
        System.out.println("ADD for left eye: " + add);
        weAdd.sendKeys(add);
        Wait(1);
    }
  public void typePatientName(String first, String last) {
    WebElement firstPatientName = driver.findElement(By.xpath("//input[contains(@id,'firstNameInput')]"));
      firstPatientName.clear();
      firstPatientName.sendKeys(first);
      WebElement lastPatientName = driver.findElement(By.xpath("//input[contains(@id,'lastNameInput')]"));
      lastPatientName.clear();
      lastPatientName.sendKeys(last);
      System.out.println("Patient First Name is: " + first);
      System.out.println("Patient First Name is: " + last);
  }

  public void clickAddRx(){
      driver.findElement(By.xpath("//a[contains(@name,'saveAndAddAnotherBrand')]")).click();
  }
    public void clickAddRxReorder(){
        driver.findElement(By.xpath("//a[contains(.,'Select brand for another person')]")).click();
    }

    public void clickUpdateCart() {
        printPageTitle();
        Wait(5);
        driver.findElement(By.xpath("//input[contains(@value,'Submit')]")).click();
        System.out.println("Clicked Update");
        Wait(5);
    }
  public void clickAddToCart() {
      printPageTitle();
      Wait(5);
      driver.findElement(By.xpath("//input[contains(@type,'submit')]")).click();
      System.out.println("Clicked Add To Cart");
      Wait(5);
  }
    public void clickCartEdit(){
        printPageTitle();
        driver.findElement(By.xpath("//a[contains(@id,'cartEditLink')]")).click();
        System.out.println("Clicked Edit");
        Wait(5);
    }
    //change shipping method on the cart page
    //enter the letter to type
    // s = standard
    // n = next day mail. nn = next day noon.
    // c = canada, cc= can exp.
    // e = expedited,
    // i = international, ii= international exp.
    public void selectShippingCart(String ship) {
        WebElement weShipping = driver.findElement(By.xpath("//select[contains(@id,'SelectedShipperCode')]"));
        weShipping.click();
        System.out.println("Method of shipping: " + ship);
        weShipping.sendKeys(ship);
        Wait(1);
        driver.findElement(By.xpath("//label[contains(.,'Shipping')]")).click();
        Wait(4);
        //try ... driver.findElement(By.linkText("Edit"));
    }
    //change shipping method on the RS page DOES NOT WORK
    //enter the letter to type
    // MAIL = standard
    // USEM = next day mail. FED1 = next day noon.
    // c = canada, cc= can exp.
    // FED2 = expedited,
    // i = international, ii= international exp.
    public void selectShippingRS(String ship) {
        WebElement weShippingRS = driver.findElement(By.xpath("//a[contains(@class,'a41-edit-link popupTrigger')]"));;
        System.out.println("Found Edit");
        weShippingRS.click();
        System.out.println("Clicked on Edit");
        Wait(3);
        String theShippingString = "//input[contains(@id,'" + ship + "')]";
        driver.findElement(By.xpath("//input[contains(@id,'USEM')]")).click();
        driver.findElement(By.xpath(theShippingString)).click();
        System.out.println("Method of shipping: " + ship);
        driver.findElement(By.xpath("//span[contains(.,'Select')]")).click();
        Wait(4);
    }

    public void verifyCart(){
        System.out.println("this is where we will someday verify Cart contents: ");
        //driver.findElement(By.xpath("//span[contains(.,'Softcon EW')]"));
        //String theForPatient = driver.findElement(By.xpath("//span[contains(@class,'patientName')]")).getText();
        //System.out.println("Cart Header:" + theReviewCart);
        //System.out.println("Cart Header:" + theForPatient);
    }
  public void clickCart_Continue() {
      printPageTitle();
      Wait(4);
      System.out.println("Find Continue");
      driver.findElement(By.xpath("//img[contains(@alt,'continue')]"));
      driver.findElement(By.xpath("//img[contains(@alt,'continue')]")).click();
      System.out.println("Click Continue");
      Wait(10);
  }

  public void typeShippingName(String first, String last) {
      driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.FirstName')]")).clear();
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.FirstName')]")).sendKeys(first);
      System.out.println("Shipping First Name is: " + first);
      driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.LastName')]")).clear();
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.LastName')]")).sendKeys(last);
      System.out.println("Shipping Last Name is: " + last);
  }

  public void clickCountry(String country) {
    driver.findElement(By.xpath("//select[contains(@name,'ShippingAddress.Country')]")).click();
    String theCountryString = "//option[contains(@value,'" + country + "')]";
    driver.findElement(By.xpath(theCountryString)).click();
      System.out.println("Country is: " + country);
      Wait(3);
  }

  public void typeShippingAddress() {
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.AddressLine1')]")).sendKeys("ship address " + new Date().getTime());
      System.out.println("Shipping Address is: ");
      Wait(3);
  }

  public void typeShippingCity(String city) {
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.City')]")).sendKeys(city);
      System.out.println("City is: " + city);
      Wait(3);
  }

  public void typeShippingState(String state) {
      driver.findElement(By.xpath("//select[contains(@id,'ShippingAddress_StateProvinceOrRegion')]")).sendKeys(state);
      System.out.println("State is: " + state);
  }
    //not used
    public void typeIntShippingState(String state) {
        driver.findElement(By.xpath("//input[contains(@id,'StateProvinceOrRegion')]")).sendKeys(state);
        System.out.println("Region is: " + state);
        Wait(5);
    }

  public void typeShippingZip(String zip) {
    driver.findElement(By.xpath("//input[contains(@name,'ShippingAddress.ZipOrPostalCode')]")).sendKeys(zip);
      System.out.println("Zip is: " + zip);
  }

    public void typeIntShippingZip(String zip) {
        Wait(4);
        driver.findElement(By.xpath("//input[contains(@id,'ShippingAddress_ZipOrPostalCode')]")).sendKeys(zip);
        System.out.println("PostalCode is: " + zip);
        Wait(4);
    }

  public void typeShippingPhone() {
    String thePhoneString = "" + new Date().getTime();
    System.out.println("Phone used is: " + thePhoneString);
    driver.findElement(By.xpath("//input[contains(@name,'Phone')]")).click();
    driver.findElement(By.xpath("//input[contains(@name,'Phone')]")).clear();
    driver.findElement(By.xpath("//input[contains(@name,'Phone')]")).sendKeys(thePhoneString);
      Wait(5);
  }
    public void typeIntShippingPhone() {
        String thePhoneString = "" + new Date().getTime();
        System.out.println("Phone used is: " + thePhoneString);
        driver.findElement(By.xpath("//input[contains(@id,'PhoneNumber')]")).click();
        driver.findElement(By.xpath("//input[contains(@id,'PhoneNumber')]")).clear();
        driver.findElement(By.xpath("//input[contains(@id,'PhoneNumber')]")).sendKeys(thePhoneString);
        Wait(3);
    }

  //email
  public void typeShippingEmail(String email) {
    String theEmailString = email + "_" + new Date().getTime() + "@invalid.com";
    driver.findElement(By.xpath("//input[contains(@name,'EmailAddress')]")).sendKeys(theEmailString);
    System.out.println("Email used is: " + theEmailString);
      System.out.println(theEmailString + ": Email Used");
  }

  //password and confirm password
  public void typePassword_newcust(String password) {
    driver.findElement(By.xpath("//input[contains(@id,'a41-checkout-password')]")).sendKeys(password);
    driver.findElement(By.xpath("//input[contains(@id,'a41-checkout-password')]")).sendKeys(password);
    driver.findElement(By.xpath("//input[contains(@id,'a41-checkout-confirm-password')]")).sendKeys(password);
      System.out.println("Password Entered: " + password);
      System.out.println(password + ": Password Used");
  }

  public void clickNewAddress_Continue() {
    driver.findElement(By.xpath("//input[contains(@value,'continue')]")).click();
      System.out.println("Clicked Continue on New Address Page");
    Wait(3);
  }

  public void typeDoctorSearch(String doctor) {
    driver.findElement(By.xpath("//input[contains(@name,'DoctorSearchOptionsViewModel.DoctorOrClinic')]")).sendKeys(doctor);
      System.out.println("input dr name for search");
    Wait(2);
  }

  public void typeDoctorStateAndFind(String state) {
    new Select(driver.findElement(By.xpath("//select[contains(@id,'DoctorSearchOptionsViewModel_State')]"))).selectByVisibleText(state);
    Wait(2);
      driver.findElement(By.xpath("//img[contains(@alt,'search')]")).click();
      System.out.println("searched for Doctor");
    Wait(2);
  }

  public void typeDoctorPhoneAndFind(String phone) {
    driver.findElement(By.xpath("//input[contains(@id,'a41-search-by-phone')]")).click();
    driver.findElement(By.xpath("//input[contains(@id,'PhoneNumber')]")).sendKeys(phone);
    Wait(2);
    driver.findElement(By.xpath("//img[contains(@alt,'search')]"));
      System.out.println("searched for Doctor");
    Wait(2);
  }

  //select doctor  this will just take the first result
  public void selectDoctor() {
      driver.findElement(By.xpath("//a[contains(@id,'SelectDoctorButton2696254')]")).click();
      System.out.println("selected Doctor 2696254");
    Wait(6);
  }

  //review and submit page
  //enter credit card
  public void typeCreditCard(String cardNumber) {
      WebElement weCreditCardField = driver.findElement(By.xpath("//input[contains(@id,'CreditCardNumber')]"));
      Wait(2);
      weCreditCardField.clear();
      Wait(2);
      System.out.println("CC cleared: ");
      Wait(2);
      weCreditCardField.sendKeys(cardNumber);
      System.out.println("CC Used: " + cardNumber);
  }

  public void typeCreditCardName(String creditName) {
    driver.findElement(By.xpath("//input[contains(@id,'CreditCardName')]")).sendKeys(creditName);
      System.out.println("CC Name Used: " + creditName);
  }

  public void pickCreditCardExpDate(String month, String year) {
      driver.findElement(By.xpath("//select[contains(@id,'CreditCardExpirationMonth')]")).sendKeys(month);
      driver.findElement(By.xpath("//select[contains(@id,'CreditCardExpirationYear')]")).sendKeys(year);
      System.out.println("CC exp date:" + month + " " + year);
  }

  //Place My Order Bottom button
  public void clickTopSubmitButton() {
      driver.findElement(By.xpath("//input[contains(@id,'PlaceMyOrderButton')]")).click();
      System.out.println("Clicked the Top Submit button");
      Wait(3);
      System.out.println("Waiting");
      Wait(10);
      System.out.println("Waiting");
      Wait(10);
      System.out.println("Waiting");
      Wait(10);
  }
    public void clickBottomSubmitButton() {
        driver.findElement(By.xpath("//input[contains(@id,'ReviewAndSubmit_BottomButton')]")).click();
        System.out.println("Clicked the Bottom Submit button");
        Wait(3);
        System.out.println("Waiting");
        Wait(10);
        System.out.println("Waiting");
        Wait(10);
        System.out.println("Waiting");
        Wait(10);
    }


    //expired credit card

    public void verifyExpiredCard() {
        //driver.findElement(By.xpath("//img[contains(@src,'/Img/cc/PaymentWait.gif')]"));
        driver.findElement(By.xpath("//ul[contains(@id,'errorMessagesUl')]"));
        System.out.println("Got the Expired Card message");
        System.out.println("Next - Change exp date to be correct");
    }
  //Declined Credit Card error page
  public void verifyDeclinedCard() {
      driver.findElement(By.xpath("//img[contains(@src,'/Img/cc/PaymentWait.gif')]"));
      System.out.println("CreditCard Error page");
  }
    //Go to cart 1 item
    public void goToCart() {
        System.out.println("Next Go To Cart");
        driver.findElement(By.xpath("//a[contains(@title,'View Cart')]")).click();
        Wait(2);
        driver.findElement(By.xpath("//p[contains(.,'	Please review your cart	')]"));
        System.out.println("You are in the cart... proceed as normal");
        Wait(6);
    }
    //Go to cart 1 item
    public void goToCart2Items() {
        System.out.println("Next Go To Cart");
        driver.findElement(By.xpath("//a[contains(.,'Cart2')]")).click();
        Wait(2);
        driver.findElement(By.xpath("//p[contains(.,'	Please review your cart	')]"));
        System.out.println("You are in the cart... proceed as normal");
        Wait(6);
    }

  //ThankYou page
  public void verifyThankYouPage() {
      Wait(14);
    driver.findElement(By.xpath("//h1[contains(.,'Thank you for your order!')]"));
      System.out.println("Thank You page says Thank you for your order! ");
    driver.findElement(By.xpath("//p[contains(.,'A confirmation of this order has been sent to:')]"));
      System.out.println("A confirmation of this order has been sent to:");
    System.out.println("Page title is: " + driver.getTitle());
      String theOrderNumber = driver.findElement(By.xpath("//td[contains(@id,'orderNumber')]")).getText();
      System.out.println(theOrderNumber + ": Order Number");
  }
    public void verifyTxtPresent(String identifier, String desired, String actual){

        // the pattern we want to search for
        Pattern p = Pattern.compile(desired);
        Matcher m = p.matcher(actual);
        // just try to find a match
        if (m.find())
            System.out.println("VERIFIED " + identifier + "Found " + desired + " within " + actual + "." );
        else
            System.out.println("FAIL " + identifier + "NOT FOUND " + desired + " within " + actual + "." );
    }
    public void verifyCart(String brand,String patientName,String price,String totalR, String totalL, String cartTotal) {
        Wait(14);
        System.out.println("Page title is: " + driver.getTitle());
        //verify "please review your cart"
        String verifyTitleCart =  driver.findElement(By.xpath("//p[@class='']")).getText();
        System.out.println("Title is:" + verifyTitleCart);
        verifyTxtPresent("Title is: ", "Please review your cart", verifyTitleCart);
        System.out.println("Verified text present: Please review your cart");
        //verify brand
        String verifyBrandCart =  driver.findElement(By.xpath("//div[@id='patientNameDiv']")).getText();
        System.out.println("Brand and Patient Name is:" + verifyBrandCart);
        verifyTxtPresent("Brand in Cart: ", brand, verifyBrandCart);
        verifyTxtPresent("Patient Name in Cart: ", patientName, verifyBrandCart);
        String verifyPriceBoxCart =  driver.findElement(By.xpath("//div[@parameter='price']")).getText();
        verifyTxtPresent("Per Box Price in Cart: ", price, verifyPriceBoxCart);
        try
        {
            String verifyPriceREyeCart = driver.findElement(By.xpath("//div[@class='innerParam RightEyeViewModel.EyePrescriptionViewModel.Total']")).getText();
            verifyTxtPresent("R Eye Price in Cart: ",totalR,verifyPriceREyeCart);
        }
        catch (Throwable e)
        {
            System.out.println("No Right Eye");
        }
        try
        {
            String verifyPriceLEyeCart =  driver.findElement(By.xpath("//div[@class='innerParam LeftEyeViewModel.EyePrescriptionViewModel.Total']")).getText();
            verifyTxtPresent("L Eye Price in Cart: ",totalL,verifyPriceLEyeCart);
        }
        catch (Throwable e)
        {
            System.out.println("No Left Eye");
        }
        String verifyPriceTotalCart =  driver.findElement(By.xpath("//td[@id='cartTotalTd']")).getText();
        String verifyPriceShippingCart =  driver.findElement(By.xpath("//div[contains(@id,'uniform-ShippingViewModel_SelectedShipperCode')]")).getText();
        System.out.println("Shipping: " + verifyPriceShippingCart);
        verifyTxtPresent("Cart total: ",cartTotal,verifyPriceTotalCart);
    }
}
